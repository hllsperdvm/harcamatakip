        // Firebase Compat (yerel file:// ile çalışır; modül gerekmez)
        if (typeof firebase === 'undefined') {
            alert('Firebase yüklenemedi. İnternet bağlantınızı kontrol edin ve sayfayı yenileyin.');
            throw new Error('Firebase SDK yüklenmedi');
        }
        const firebaseConfig = {
            apiKey: "AIzaSyDFTQa5FV8kKBqICWAg_vst8AnLdIrfBVw",
            authDomain: "harcama-takibi-1c48b.firebaseapp.com",
            projectId: "harcama-takibi-1c48b",
            storageBucket: "harcama-takibi-1c48b.firebasestorage.app",
            messagingSenderId: "1051789650081",
            appId: "1:1051789650081:web:3c7d4bc099eb7b5f0f68e0"
        };

        firebase.initializeApp(firebaseConfig);
        const db = firebase.firestore();
        const auth = firebase.auth();
        try { auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL); } catch (_) {}


        // Auth e-posta eşlemesi (Console'da oluşturulan kullanıcılar)
        // Sabit aylık gelir — UI'da gösterilmez; AI/yerel öneride kullanılır
        const HOUSEHOLD_MONTHLY_INCOME = 110000;

        const AUTH_EMAIL_BY_NAME = {
            Bekir: 'bekir@yuvam.app',
            Duygu: 'duygu@yuvam.app'
        };
        const NAME_BY_AUTH_EMAIL = {
            'bekir@yuvam.app': 'Bekir',
            'duygu@yuvam.app': 'Duygu'
        };

        // --- Genel UI yardımcıları ---
        function showToast(message, type) {
            type = type || 'info';
            let host = document.getElementById('toastHost');
            if (!host) {
                host = document.createElement('div');
                host.id = 'toastHost';
                host.className = 'toast-host';
                document.body.appendChild(host);
            }
            const el = document.createElement('div');
            el.className = 'toast-item toast-' + type;
            el.textContent = message;
            host.appendChild(el);
            setTimeout(() => {
                el.classList.add('toast-out');
                setTimeout(() => el.remove(), 300);
            }, type === 'error' ? 5000 : 3200);
        }

        function friendlyFirebaseError(err) {
            const code = (err && err.code) ? String(err.code) : '';
            const msg = (err && err.message) ? String(err.message) : String(err || 'Bilinmeyen hata');
            if (code.includes('permission-denied') || /permission|insufficient/i.test(msg)) {
                return 'Firebase izin hatası: Bu işlem için güvenlik kurallarında (Rules) yazma/okuma izni yok. Console → Firestore → Rules bölümünü kontrol edin.';
            }
            if (code.includes('unavailable') || /network|offline|Failed to fetch/i.test(msg)) {
                return 'Bağlantı hatası: İnterneti kontrol edip sayfayı yenileyin.';
            }
            if (code.includes('not-found')) {
                return 'Kayıt bulunamadı veya silinmiş olabilir.';
            }
            if (code.indexOf('auth/') === 0) {
                return 'Kimlik doğrulama: ' + msg;
            }
            return 'İşlem başarısız: ' + msg;
        }

        async function withErrorHandling(actionLabel, fn) {
            try {
                return await fn();
            } catch (err) {
                console.error(actionLabel, err);
                const text = friendlyFirebaseError(err);
                showToast((actionLabel ? actionLabel + ': ' : '') + text, 'error');
                throw err;
            }
        }


        // Kullanıcı hesapları: Bekir = admin, Duygu = normal
        // Kimlik: Firebase Auth. Rol: Firestore users/{uid}
        let openrouterApiKey = ''; // Firestore settings/apiKeys.openrouter — koda yazılmaz

        let currentUser = null; // { name, role }
        let onboardingPending = false;


        function visibilityFromSelect(val) {
            if (val === 'Bekir') return { visibleTo: ['Bekir'], adminOnly: false };
            if (val === 'Duygu') return { visibleTo: ['Duygu'], adminOnly: false };
            if (val === 'admin') return { visibleTo: ['Bekir'], adminOnly: true };
            return { visibleTo: ['Bekir', 'Duygu'], adminOnly: false };
        }

        function selectFromVisibility(tab) {
            if (tab.adminOnly) return 'admin';
            const v = tab.visibleTo;
            if (Array.isArray(v) && v.length === 1 && v[0] === 'Bekir') return 'Bekir';
            if (Array.isArray(v) && v.length === 1 && v[0] === 'Duygu') return 'Duygu';
            return 'both';
        }

        const DEFAULT_TABS = [
            { id: 'home', emoji: '🏠', label: 'Ana Sayfa', visible: true, core: true, adminOnly: false },
            { id: 'calendar', emoji: '📅', label: 'Takvim', visible: true, core: true, adminOnly: false },
            { id: 'tasks', emoji: '✅', label: 'Görevler', visible: true, core: true, adminOnly: false },
            { id: 'shopping', emoji: '🛒', label: 'Alışveriş', visible: true, core: true, adminOnly: false },
            { id: 'expense', emoji: '💰', label: 'Bütçe Takip', visible: true, core: true, adminOnly: false },
            { id: 'vehicle', emoji: '🚗', label: 'Araç', visible: true, core: true, adminOnly: false },
            { id: 'stats', emoji: '📊', label: 'Raporlar', visible: true, core: true, adminOnly: false },
            { id: 'notes', emoji: '📝', label: 'Notlar', visible: true, core: true, adminOnly: false },
            { id: 'settings', emoji: '⚙️', label: 'Ayarlar', visible: true, core: true, adminOnly: true },
            { id: 'trash', emoji: '🗑️', label: 'Çöp Kutusu', visible: true, core: true, adminOnly: true }
        ];

        // Mobil alt menü: Ana · Bütçe · Görevler · Takvim · Daha
        const MOBILE_NAV_PRIMARY = ['home', 'expense', 'tasks', 'calendar'];

        let familyCalendar = [];
        let familyTasks = [];
        let familyShopping = [];
        let goldHoldings = [];
        let goldPricePerGram = null; // 24 satış (değerleme)
        let goldPricePerGram22 = null; // 22 satış
        let goldQuotes = { buy24: null, sell24: null, buy22: null, sell22: null };

        let tabsConfig = DEFAULT_TABS.map(t => ({ ...t }));

        try {
            if (typeof Chart !== 'undefined' && Chart.defaults && Chart.defaults.elements && Chart.defaults.elements.point) {
                Chart.defaults.elements.point.radius = 8;
                Chart.defaults.elements.point.hoverRadius = 12;
                Chart.defaults.elements.point.hitRadius = 28;
            }
        } catch (_) {}

        window.handlePasswordKeyPress = function(event) {
            if (event.key === 'Enter') checkPassword();
        };

        window.checkPassword = async function() {
            try {
                const userName = (document.getElementById('loginUser') || {}).value;
                const input = (document.getElementById('sifreInput') || {}).value;
                if (!userName) {
                    alert('Lütfen kullanıcı seçin.');
                    return;
                }
                if (!input) {
                    alert('Lütfen şifre girin.');
                    return;
                }
                const email = AUTH_EMAIL_BY_NAME[userName];
                if (!email) {
                    alert('Geçersiz kullanıcı.');
                    return;
                }

                let cred;
                try {
                    cred = await auth.signInWithEmailAndPassword(email, input);
                } catch (authErr) {
                    const code = (authErr && authErr.code) || '';
                    if (code === 'auth/wrong-password' || code === 'auth/invalid-credential' || code === 'auth/invalid-login-credentials') {
                        alert('Şifre hatalı. Firebase Console → Authentication → Users içindeki şifreyi kullanın.');
                        return;
                    }
                    if (code === 'auth/user-not-found') {
                        alert('Kullanıcı bulunamadı. Console → Authentication → Users kontrol edin.');
                        return;
                    }
                    if (code === 'auth/too-many-requests') {
                        alert('Çok fazla deneme. Bir süre sonra tekrar deneyin.');
                        return;
                    }
                    alert('Giriş hatası: ' + (authErr.message || authErr));
                    return;
                }

                const fbUser = cred.user;
                const profile = await loadUserProfile(fbUser);
                await enterAppAsUser(profile);
            } catch (err) {
                console.error(err);
                alert('Giriş hatası: ' + (err && err.message ? err.message : err));
            }
        };

        function loadUserProfileFast(fbUser) {
            const email = ((fbUser && fbUser.email) || '').toLowerCase();
            let name = NAME_BY_AUTH_EMAIL[email] || NAME_BY_AUTH_EMAIL[(fbUser && fbUser.email) || ''] || '';
            if (!name) {
                name = email.indexOf('bekir') >= 0 ? 'Bekir' : (email.indexOf('duygu') >= 0 ? 'Duygu' : ((fbUser && fbUser.email) || 'Kullanıcı'));
            }
            const role = name === 'Bekir' ? 'admin' : 'user';
            return {
                name: name,
                role: role,
                uid: fbUser.uid,
                email: fbUser.email || email
            };
        }

        async function loadUserProfile(fbUser) {
            // Hızlı yol: e-posta eşlemesi (Firestore beklemeden)
            const profile = loadUserProfileFast(fbUser);
            // Arka planda Firestore rol/ad güncelle (UI'yı bloklamaz)
            try {
                db.collection('users').doc(fbUser.uid).get().then(function(snap) {
                    if (!snap.exists) return;
                    const d = snap.data() || {};
                    if (currentUser && currentUser.uid === fbUser.uid) {
                        if (d.name) currentUser.name = d.name;
                        if (d.role) currentUser.role = d.role;
                        const label = document.getElementById('loggedInUserLabel') || document.getElementById('currentUserLabel');
                        if (label && currentUser) {
                            label.textContent = currentUser.role === 'admin'
                                ? (currentUser.name + ' · Admin')
                                : currentUser.name;
                        }
                        if (typeof applyRoleAndTabs === 'function') applyRoleAndTabs();
                    }
                }).catch(function() {});
            } catch (e) {
                console.warn('users profil:', e);
            }
            return profile;
        }

        async function enterAppAsUser(profile, opts) {
            opts = opts || {};
            currentUser = profile;
            try { sessionStorage.setItem('yuvam_user', JSON.stringify(currentUser)); } catch (_) {}
            // Kullanıcıya özel tema
            try { if (typeof loadThemeFromStorage === 'function') loadThemeFromStorage(); } catch (_) {}
            const loginEl = document.getElementById('errorContainer') || document.getElementById('loginScreen');
            const appEl = document.getElementById('appContainer') || document.getElementById('app');
            if (loginEl) {
                loginEl.classList.add('hidden');
                loginEl.style.display = 'none';
            }
            if (appEl) {
                appEl.classList.remove('hidden');
                appEl.style.display = '';
            }
            try {
                document.body.classList.add('yuvam-app-open');
                document.documentElement.classList.add('yuvam-app-open');
            } catch (_) {}
            try { if (typeof showAppSkeleton === 'function') showAppSkeleton(); } catch (_) {}
            const label = document.getElementById('loggedInUserLabel') || document.getElementById('currentUserLabel');
            if (label) {
                label.textContent = currentUser.role === 'admin'
                    ? (currentUser.name + ' · Admin')
                    : currentUser.name;
            }
            applyRoleAndTabs();
            if (typeof applyDashboardCards === 'function') applyDashboardCards();
            try { if (typeof updateAdminLayoutButtons === 'function') updateAdminLayoutButtons(); } catch (_) {}
            // Once UI acilsin; senkron ve loglari ertele (mobil otomatik girisi hizlandirir)
            var uidEnter = currentUser && currentUser.uid;
            setTimeout(function() {
                if (!currentUser || currentUser.uid !== uidEnter) return;
                try { initRealtimeSync(); } catch (e) { console.error('sync', e); showToast('Veri bağlantısı kurulamadı', 'error'); }
                try {
                    if (!opts.silent) {
                        logActivity('Giriş', 'Oturum açıldı', currentUser.role === 'admin' ? 'Admin girişi' : 'Kullanıcı girişi');
                    }
                } catch (_) {}
                if (typeof maybeShowOnboarding === 'function') maybeShowOnboarding();
                if (typeof refreshAppNotifications === 'function') refreshAppNotifications();
            }, 0);
            if (!opts || !opts.silent) {
                showToast('Hoş geldin, ' + currentUser.name, 'success');
            }
        }


        // ========== BİLDİRİMLER (site içi) ==========
        function daysUntilYMD(ymd) {
            const d = parseYMD(ymd);
            if (!d) return null;
            const t = parseYMD(todayDateStr());
            if (!t) return null;
            const ms = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(t.getFullYear(), t.getMonth(), t.getDate());
            return Math.round(ms / 86400000);
        }

        function getNotifSeenKeys() {
            try {
                return new Set(JSON.parse(localStorage.getItem('yuvam_notif_seen') || '[]'));
            } catch (_) {
                return new Set();
            }
        }

        function markNotifsSeen(items) {
            try {
                const seen = getNotifSeenKeys();
                (items || []).forEach(function(n) {
                    if (n && n.key) seen.add(n.key);
                });
                // Listeyi şişirmemek için son 300 anahtar
                const arr = Array.from(seen);
                const trimmed = arr.length > 300 ? arr.slice(arr.length - 300) : arr;
                localStorage.setItem('yuvam_notif_seen', JSON.stringify(trimmed));
            } catch (_) {}
        }

        function collectAppNotifications() {
            const items = [];
            const today = todayDateStr();
            const seen = new Set();
            const startDay = Number((periodConfig && periodConfig.startDay) || 29);

            function pushNotif(key, sev, icon, title, msg, category) {
                if (seen.has(key)) return;
                seen.add(key);
                items.push({ key: key, severity: sev, icon: icon, title: title, message: msg, category: category || 'general' });
            }

            // Dönem başlangıç günü (varsayılan 29): kart borcu girilmediyse
            try {
                const now = new Date();
                if (now.getDate() === startDay) {
                    [['Bekir', bekirDebt], ['Duygu', duyguDebt]].forEach(function(pair) {
                        const name = pair[0];
                        const debt = pair[1];
                        const hasActive = debt && !debt.paid && Number(debt.amount) > 0;
                        if (!hasActive) {
                            pushNotif('kk-enter-' + name + '-' + today, 'warning', '💳', 'Kart borcunu gir', name + ' için bu dönem kart borcu henüz girilmedi');
                        }
                    });
                }
            } catch (_) {}

            [['Bekir', bekirDebt], ['Duygu', duyguDebt]].forEach(function(pair) {
                const name = pair[0];
                const debt = pair[1];
                if (!debt || debt.paid || !(Number(debt.amount) > 0)) return;
                const due = debt.dueDate ? String(debt.dueDate).slice(0, 10) : '';
                const amt = (Number(debt.amount) || 0).toLocaleString('tr-TR') + ' TL';
                if (!due) {
                    pushNotif('kk-nodue-' + name, 'warning', '💳', name + ' kredi kartı borcu', amt + ' · son ödeme tarihi yok');
                    return;
                }
                const days = daysUntilYMD(due);
                if (days == null) return;
                if (days < 0) {
                    pushNotif('kk-over-' + name, 'critical', '💳', name + ' kart ödemesi gecikti', Math.abs(days) + ' gün gecikme · ' + amt);
                } else if (days === 0) {
                    pushNotif('kk-today-' + name, 'critical', '💳', name + ' kart son ödeme günü', 'Bugün · ' + amt);
                } else if (days <= 3) {
                    pushNotif('kk-soon-' + name, 'warning', '💳', name + ' kart son ödemesine ' + days + ' gün', amt + ' · ' + formatDateTR(due));
                } else if (days <= 7) {
                    pushNotif('kk-week-' + name, 'info', '💳', name + ' kart ödemesine ' + days + ' gün', amt + ' · ' + formatDateTR(due));
                }
            });

            const list = (typeof getProcessedExpenses === 'function') ? getProcessedExpenses() : (expenses || []);
            list.forEach(function(e) {
                if (!e || e.installmentLabel === 'Gelir') return;
                const d = String(e.date || '').slice(0, 10);
                if (!d) return;
                const days = daysUntilYMD(d);
                if (days == null || days < 0 || days > 7) return;
                const desc = (e.description && e.description !== '-') ? e.description : (e.category || 'Harcama');
                const sub = (e.billSubtype ? e.billSubtype + ' · ' : '') + (e.category || '');
                const amt = (Number(e.displayAmount) || Number(e.amount) || 0).toLocaleString('tr-TR') + ' TL';
                const key = 'exp-' + d + '-' + (e.id || desc);
                if (days === 0) {
                    pushNotif(key, 'critical', '📌', 'Bugün: ' + desc, sub + ' · ' + amt + (e.person ? ' · ' + e.person : ''));
                } else if (days <= 3) {
                    pushNotif(key, 'warning', '📅', days + ' gün sonra: ' + desc, formatDateTR(d) + ' · ' + amt);
                } else {
                    pushNotif(key, 'info', '🗓️', days + ' gün sonra: ' + desc, formatDateTR(d) + ' · ' + amt);
                }
            });

            try {
                for (let i = 0; i < localStorage.length; i++) {
                    const k = localStorage.key(i);
                    if (!k || k.indexOf('yuvam_todo_') !== 0) continue;
                    let arr = [];
                    try { arr = JSON.parse(localStorage.getItem(k) || '[]'); } catch (_) { continue; }
                    (arr || []).forEach(function(it, idx) {
                        if (!it || it.done || !it.due) return;
                        const d = String(it.due).slice(0, 10);
                        const days = daysUntilYMD(d);
                        if (days == null || days < 0 || days > 7) return;
                        const text = it.text || 'Görev';
                        const key = 'todo-' + k + '-' + idx + '-' + d;
                        if (days === 0) pushNotif(key, 'critical', '✅', 'Bugün görev: ' + text, formatDateTR(d));
                        else if (days <= 3) pushNotif(key, 'warning', '✅', days + ' gün sonra görev: ' + text, formatDateTR(d));
                        else pushNotif(key, 'info', '✅', days + ' gün sonra görev: ' + text, formatDateTR(d));
                    });
                }
            } catch (_) {}

            try {
                (window._todoNotifCache || []).forEach(function(it) {
                    if (!it || !it.due) return;
                    const d = String(it.due).slice(0, 10);
                    const days = daysUntilYMD(d);
                    if (days == null || days < 0 || days > 7) return;
                    const text = it.text || 'Görev';
                    const key = 'todo-fb-' + (it.id || d + text);
                    if (days === 0) pushNotif(key, 'critical', '✅', 'Bugün görev: ' + text, formatDateTR(d));
                    else if (days <= 3) pushNotif(key, 'warning', '✅', days + ' gün sonra görev: ' + text, formatDateTR(d));
                    else pushNotif(key, 'info', '✅', days + ' gün sonra görev: ' + text, formatDateTR(d));
                });
            } catch (_) {}

            // Aile takvimi (yıllık doğum günü / yıldönümü dahil)
            try {
                (familyCalendar || []).forEach(function(ev) {
                    if (!ev || !ev.date) return;
                    const d = (typeof eventEffectiveDate === 'function') ? eventEffectiveDate(ev) : String(ev.date).slice(0, 10);
                    const days = daysUntilYMD(d);
                    if (days == null || days < 0 || days > 14) return;
                    const title = ev.title || 'Etkinlik';
                    const icon = (typeof calTypeIcon === 'function') ? calTypeIcon(ev.type) : '📅';
                    const typeLab = (typeof calTypeLabel === 'function') ? calTypeLabel(ev.type) : '';
                    const key = 'fcal-' + (ev.id || d + title) + '-' + d;
                    if (days === 0) pushNotif(key, 'critical', icon, 'Bugün: ' + title, typeLab + ' · ' + formatDateTR(d));
                    else if (days <= 3) pushNotif(key, 'warning', icon, days + ' gün: ' + title, typeLab + ' · ' + formatDateTR(d));
                    else pushNotif(key, 'info', icon, days + ' gün: ' + title, typeLab + ' · ' + formatDateTR(d));
                });
            } catch (_) {}


            // Aile görevleri
            try {
                (familyTasks || []).forEach(function(t) {
                    if (!t || t.done || !t.due) return;
                    const d = String(t.due).slice(0, 10);
                    const days = daysUntilYMD(d);
                    if (days == null || days < 0 || days > 7) return;
                    const text = t.text || 'Görev';
                    const key = 'ftask-' + (t.id || d + text);
                    if (days === 0) pushNotif(key, 'critical', '✅', 'Bugün görev: ' + text, formatDateTR(d));
                    else if (days <= 3) pushNotif(key, 'warning', '✅', days + ' gün görev: ' + text, formatDateTR(d));
                    else pushNotif(key, 'info', '✅', days + ' gün görev: ' + text, formatDateTR(d));
                });
            } catch (_) {}

            try {
                (activityLog || []).slice(0, 30).forEach(function(row) {
                    if (!row) return;
                    const action = String(row.action || '');
                    // Sadece harcama eklendi / silindi
                    if (action !== 'Harcama eklendi' && action !== 'Harcama silindi') return;
                    const who = row.user || row.userName || 'Birisi';
                    const detail = row.detail ? String(row.detail) : '';
                    const at = row.at ? String(row.at).slice(0, 16).replace('T', ' ') : '';
                    const key = 'act-' + (row.id || (who + action + at));
                    pushNotif(key, 'info', '👤', who + ' kişisi · ' + action, (detail || '') + (at ? (detail ? ' · ' : '') + at : ''), 'activity');
                });
            } catch (_) {}

            const rank = { critical: 0, warning: 1, info: 2 };
            items.sort(function(a, b) { return (rank[a.severity] || 9) - (rank[b.severity] || 9); });
            return items;
        }

        function renderNotifItemsHtml(items) {
            return (items || []).map(function(n) {
                return '<div class="notif-item sev-' + n.severity + '">' +
                    '<span class="notif-icon">' + n.icon + '</span>' +
                    '<div><p class="notif-title">' + escapeHtml(n.title) + '</p>' +
                    '<p class="notif-msg">' + escapeHtml(n.message) + '</p></div></div>';
            }).join('');
        }

        window.refreshAppNotifications = function() {
            const badge = document.getElementById('notifBadge');
            const body = document.getElementById('notifPanelBody');
            let items = [];
            try { items = collectAppNotifications(); } catch (e) { console.warn('notif', e); }
            window._lastNotifItems = items;
            const seen = getNotifSeenKeys();
            const unread = items.filter(function(n) { return !seen.has(n.key); });
            if (badge) {
                if (unread.length) {
                    badge.textContent = unread.length > 9 ? '9+' : String(unread.length);
                    badge.classList.remove('hidden');
                } else {
                    badge.classList.add('hidden');
                }
            }
            if (!body) return;
            if (!items.length) {
                body.innerHTML = yuvamEmptyState('👍', 'Bildirim yok', 'Yakın vadede uyarı bulunmuyor', null, null);
                return;
            }
            const top = items.slice(0, 5);
            let html = renderNotifItemsHtml(top);
            if (items.length > 5) {
                html += '<button type="button" onclick="openNotifAllModal()" class="w-full mt-1 py-2.5 rounded-xl text-xs font-black text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-100">Daha fazla göster</button>';
            }
            body.innerHTML = html;
        };

        window.openNotifAllModal = function() {
            try {
                if (typeof refreshAppNotifications === 'function') refreshAppNotifications();
            } catch (_) {}
            const modal = document.getElementById('notifAllModal');
            const body = document.getElementById('notifAllBody');
            let items = [];
            try {
                items = (window._lastNotifItems && window._lastNotifItems.length)
                    ? window._lastNotifItems
                    : (typeof collectAppNotifications === 'function' ? collectAppNotifications() : []);
            } catch (_) { items = []; }
            items = (items || []).slice(0, 20);
            if (body) {
                body.innerHTML = items.length
                    ? renderNotifItemsHtml(items)
                    : '<p class="text-xs text-slate-400 font-semibold p-4 text-center">Bildirim yok</p>';
            }
            if (modal) {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                modal.style.display = 'flex';
            }
            try { closeNotifPanel(true); } catch (_) {}
        };

        window.openHomeAllNotifs = function() {
            openNotifAllModal();
        };

        window.closeNotifAllModal = function() {
            const modal = document.getElementById('notifAllModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
                modal.style.display = 'none';
            }
            markNotifsSeen(window._lastNotifItems || []);
            refreshAppNotifications();
        };

        window.toggleNotifPanel = function(ev) {
            if (ev) ev.stopPropagation();
            const panel = document.getElementById('notifPanel');
            if (!panel) return;
            if (panel.classList.contains('hidden')) {
                panel.classList.remove('hidden');
                refreshAppNotifications();
            } else {
                closeNotifPanel();
            }
        };

        window.closeNotifPanel = function(skipSeen) {
            const panel = document.getElementById('notifPanel');
            if (panel) panel.classList.add('hidden');
            if (!skipSeen) {
                markNotifsSeen(window._lastNotifItems || []);
                refreshAppNotifications();
            }
        };

        document.addEventListener('click', function(e) {
            const panel = document.getElementById('notifPanel');
            const btn = document.getElementById('notifBtn');
            if (!panel || panel.classList.contains('hidden')) return;
            if (panel.contains(e.target) || (btn && btn.contains(e.target))) return;
            closeNotifPanel();
        });

        window.toggleMobilePreview = function() {
            const on = document.documentElement.classList.toggle('force-mobile-preview');
            try { localStorage.setItem('yuvam_force_mobile', on ? '1' : '0'); } catch (_) {}
            const lab = document.getElementById('mobilePreviewBtnLabel');
            if (lab) lab.textContent = on ? '💻 Web' : '📱 Mobil';
            // kart/tabloyu yenile
            try { renderTable(); } catch (_) {}
            showToast(on ? 'Mobil önizleme açık' : 'Web görünümü', 'info');
        };

        (function restoreMobilePreviewFlag() {
            try {
                if (localStorage.getItem('yuvam_force_mobile') === '1') {
                    document.documentElement.classList.add('force-mobile-preview');
                    const lab = document.getElementById('mobilePreviewBtnLabel');
                    if (lab) lab.textContent = '💻 Web';
                }
            } catch (_) {}
        })();

        window.logout = function() {
            const name = currentUser ? currentUser.name : 'Sistem';
            try { logActivity('Çıkış', 'Oturum kapatıldı', name + ' çıkış yaptı', name); } catch (_) {}
            currentUser = null;
            try { sessionStorage.removeItem('yuvam_user'); } catch (_) {}
            try { auth.signOut(); } catch (_) {}
            // realtime flag
            try { syncInitialized = false; } catch (_) {}
            const appEl = document.getElementById('appContainer') || document.getElementById('app');
            const loginEl = document.getElementById('errorContainer') || document.getElementById('loginScreen');
            if (appEl) {
                appEl.classList.add('hidden');
                appEl.style.display = 'none';
            }
            try {
                document.body.classList.remove('yuvam-app-open');
                document.documentElement.classList.remove('yuvam-app-open');
                try { hideAppSkeleton(); } catch (_) {}
                _skeletonHiddenOnce = false;
                closeMobileMoreSheet();
            } catch (_) {}
            if (loginEl) {
                loginEl.classList.remove('hidden');
                loginEl.style.display = '';
            }
            const sifre = document.getElementById('sifreInput');
            if (sifre) sifre.value = '';
            const lu = document.getElementById('loginUser');
            if (lu) lu.value = '';
            showToast('Çıkış yapıldı', 'info');
        };


        function isAdmin() {
            return currentUser && currentUser.role === 'admin';
        }

        async function logActivity(actionType, action, detail, userOverride) {
            try {
                const entry = {
                    user: userOverride || ((currentUser && currentUser.name) ? currentUser.name : 'Sistem'),
                    role: (currentUser && currentUser.role) ? currentUser.role : '-',
                    actionType: actionType || 'Diğer',
                    action: action || '-',
                    detail: detail || '',
                    at: new Date().toISOString()
                };
                await db.collection('activityLog').add(entry);
            } catch (err) {
                console.warn('Aktivite kaydı yazılamadı:', err);
            }
        }


        function getVisibleTabs() {
            return tabsConfig.filter(t => {
                if (!t.visible) return false;
                if (t.adminOnly && !isAdmin()) return false;
                if (Array.isArray(t.visibleTo) && t.visibleTo.length) {
                    if (!currentUser || !t.visibleTo.includes(currentUser.name)) return false;
                }
                return true;
            });
        }

        function applyRoleAndTabs() {
            document.querySelectorAll('.admin-only-btn').forEach(function(el) {
                el.classList.toggle('hidden', !isAdmin());
            });
            const visible = getVisibleTabs();
            // Mümkünse Ana Sayfa ile aç
            const homeTab = visible.find(t => t.id === 'home');
            if (lastActiveTabId && visible.some(t => t.id === lastActiveTabId)) {
                renderTabBar();
                if (typeof updateMobileBottomNav === 'function') updateMobileBottomNav(lastActiveTabId);
                return;
            }
            renderTabBar();
            if (homeTab) switchTab('home');
            else if (visible.length) switchTab(visible[0].id);
        }

        let lastActiveTabId = null;

        window.renderTabBar = function() {
            const bar = document.getElementById('tabBar');
            if (!bar) return;
            let visible = getVisibleTabs();
            // Ana Sayfa görsel sırada en başta
            const hi = visible.findIndex(t => t.id === 'home');
            if (hi > 0) {
                const h = visible.splice(hi, 1)[0];
                visible.unshift(h);
            }
            const activeId = lastActiveTabId && visible.some(t => t.id === lastActiveTabId)
                ? lastActiveTabId
                : ((visible.find(t => t.id === 'home') || visible[0] || {}).id);
            const openTaskN = (typeof countOpenFamilyTasks === 'function') ? countOpenFamilyTasks() : 0;
            bar.innerHTML = visible.map((t) => {
                const active = t.id === activeId;
                const cls = active
                    ? 'tab-active yuvam-tab-btn'
                    : 'tab-inactive yuvam-tab-btn hover:bg-white/80';
                const lab = t.label || t.id;
                let badge = '';
                if (t.id === 'tasks' && openTaskN > 0) {
                    badge = '<span class="tab-count-badge">' + (openTaskN > 9 ? '9+' : openTaskN) + '</span>';
                }
                return `<button type="button" data-tab-id="${escapeHtml(t.id)}" title="${escapeHtml(lab)}" onclick="switchTab('${escapeHtml(t.id)}')" class="${cls}"><span class="yuvam-tab-emoji relative">${escapeHtml(t.emoji || '📌')}${badge}</span><span class="yuvam-tab-text">${escapeHtml(lab)}</span></button>`;
            }).join('');
            if (typeof updateTaskNavBadges === 'function') updateTaskNavBadges();
        };

        window.countOpenFamilyTasks = function() {
            return (familyTasks || []).filter(function(t) { return t && !t.done; }).length;
        };

        window.updateTaskNavBadges = function() {
            const n = countOpenFamilyTasks();
            const m = document.getElementById('mnavTasksBadge');
            if (m) {
                if (n > 0) {
                    m.textContent = n > 9 ? '9+' : String(n);
                    m.classList.remove('hidden');
                } else {
                    m.classList.add('hidden');
                }
            }
            // Üst menü rozeti renderTabBar ile gelir; burada sadece mobil
        };

        function capitalizeTab(name) {
            if (!name) return '';
            return name.charAt(0).toUpperCase() + name.slice(1);
        }


        // State ve Değişkenler
        let expenses = [], notes = [], deletedExpenses = [];
        let categories = ["Gıda", "Araç", "Faturalar", "Eğlence", "Sağlık", "Eğitim", "Diğer", "Kredi Kartı Borcu"];
        let categorySubtypes = {
            'Faturalar': ['Elektrik', 'Su', 'Doğalgaz', 'Telefon', 'İnternet', 'Abonelik'],
            'Araç': ['Yakıt', 'Vergi', 'Bakım']
        };
        const DEFAULT_CATEGORY_SUBTYPES = {
            'Faturalar': ['Elektrik', 'Su', 'Doğalgaz', 'Telefon', 'İnternet', 'Abonelik'],
            'Araç': ['Yakıt', 'Vergi', 'Bakım']
        };
        let paymentTypes = ["Nakit", "Kredi Kartı"];
        let bekirDebt = { amount: 0, paid: false, dueDate: '' };
        let duyguDebt = { amount: 0, paid: false, dueDate: '' };
        let cardStatements = [];
        let activityLog = [];
        let activityFilter = { user: "Tümü", action: "Tümü", start: "", end: "" };
        let ibans = [];
        
        let sortColumn = 'date', sortDirection = 'desc';
        let currentPersonFilter = 'Tümü', currentCategoryFilter = 'Tümü', currentPaymentFilter = 'Tümü';
        let currentSearchFilter = '';
        let currentStartDateFilter = '', currentEndDateFilter = '';
        let currentShowInstallments = false;

        let expenseChart = null, weeklyTrendChart = null, monthlyTrendChart = null;
        let syncInitialized = false;
        let periodConfig = { startDay: 29, endDay: 28 };
        let monthlyBudgetTarget = 0; // TL, 0 = kapalı
        // Ana sayfa / özet kart görünürlüğü
        let dashboardCards = {
            total: true, bekir: true, duygu: true, debt: true,
            homeToday: true, homePeriod: true, homeNotif: true, homeGold: true, homeQuickAdd: true, homeUpcoming: true,
            homeBudget: true, homeTasks: true, homeBriefing: true
        };
        let appTheme = 'light';
        let monthCompareChart = null, categoryTrendChart = null;
        const AMOUNT_MIN = 0.01;
        const AMOUNT_MAX = 999999;

        let displayLimit = 10;
        let renderTimeout = null;

        function escapeHtml(str) {
            if (str == null) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function isStatsTabActive() {
            const el = document.getElementById('tabContentStats');
            return el && !el.classList.contains('hidden');
        }

        // ========== 29–28 EKSTRE DÖNEMİ ==========
        // Dönem: ayın 29'undan sonraki ayın 28'ine.
        // periodKey = kapanış ayı (YYYY-MM), örn. 29 Tem–28 Ağu → "2026-08"

        function parseYMD(dateStr) {
            if (!dateStr) return null;
            const parts = String(dateStr).split('-').map(Number);
            if (parts.length < 3 || parts.some(isNaN)) return null;
            return new Date(parts[0], parts[1] - 1, parts[2]);
        }

        function formatYMD(d) {
            return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        }

        function getStatementPeriodForDate(dateInput) {
            const date = dateInput instanceof Date
                ? new Date(dateInput.getFullYear(), dateInput.getMonth(), dateInput.getDate())
                : parseYMD(dateInput);
            if (!date || isNaN(date.getTime())) return null;

            const startDay = Math.min(31, Math.max(1, Number((periodConfig && periodConfig.startDay) || 29)));
            const endDay = Math.min(31, Math.max(1, Number((periodConfig && periodConfig.endDay) || 28)));
            // startDay > endDay olmalı (klasik 29–28). startDay 1 ve endDay 31 benzeri için: ay başı–ayı sonu yaklaşımı
            const year = date.getFullYear();
            const month = date.getMonth();
            const day = date.getDate();

            let startDate, endDate;
            if (startDay > endDay) {
                // örn. 29 → sonraki ay 28
                if (day >= startDay) {
                    startDate = new Date(year, month, startDay);
                    endDate = new Date(year, month + 1, endDay, 23, 59, 59);
                } else {
                    startDate = new Date(year, month - 1, startDay);
                    endDate = new Date(year, month, endDay, 23, 59, 59);
                }
            } else {
                // aynı ay içinde (nadir): startDay..endDay
                if (day >= startDay && day <= endDay) {
                    startDate = new Date(year, month, startDay);
                    endDate = new Date(year, month, endDay, 23, 59, 59);
                } else if (day < startDay) {
                    startDate = new Date(year, month - 1, startDay);
                    endDate = new Date(year, month - 1, endDay, 23, 59, 59);
                } else {
                    startDate = new Date(year, month, startDay);
                    endDate = new Date(year, month, endDay, 23, 59, 59);
                }
            }

            const periodKey = `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, '0')}`;
            const label = `${String(startDate.getDate()).padStart(2, '0')}.${String(startDate.getMonth() + 1).padStart(2, '0')}.${startDate.getFullYear()} – ${String(endDate.getDate()).padStart(2, '0')}.${String(endDate.getMonth() + 1).padStart(2, '0')}.${endDate.getFullYear()}`;
            return { startDate, endDate, periodKey, label };
        }

        function getCurrentPeriod() {
            return getStatementPeriodForDate(new Date()).periodKey;
        }

        function getCurrentStatementPeriod() {
            return getStatementPeriodForDate(new Date());
        }

        function getPeriodKeyForDateStr(dateStr) {
            const p = getStatementPeriodForDate(dateStr);
            return p ? p.periodKey : (dateStr ? String(dateStr).substring(0, 7) : '');
        }

        function shiftDateByMonths(dateStr, monthsToAdd) {
            const d = parseYMD(dateStr);
            if (!d) return dateStr;
            const day = d.getDate();
            const target = new Date(d.getFullYear(), d.getMonth() + monthsToAdd, 1);
            const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
            target.setDate(Math.min(day, lastDay));
            return formatYMD(target);
        }

        function formatPeriodLabel(periodKey) {
            if (!periodKey) return '-';
            const [y, m] = periodKey.split('-').map(Number);
            const end = new Date(y, m - 1, 28);
            const start = new Date(y, m - 2, 29);
            const months = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
            return `${String(start.getDate()).padStart(2, '0')} ${months[start.getMonth()]} – ${String(end.getDate()).padStart(2, '0')} ${months[end.getMonth()]} ${end.getFullYear()}`;
        }

        function getPreviousPeriodKeys(count) {
            const current = getCurrentPeriod();
            const [y, m] = current.split('-').map(Number);
            const keys = [];
            for (let i = count - 1; i >= 0; i--) {
                const d = new Date(y, m - 1 - i, 1);
                keys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
            }
            return keys;
        }

        let _skeletonHiddenOnce = false;
        let _gateProgress = 0;
        let _gateTickTimer = null;
        let _gateHideTimer = null;

        function setGateProgress(p) {
            _gateProgress = Math.max(0, Math.min(100, Number(p) || 0));
            const stage = document.getElementById('gateLoaderStage');
            if (stage) stage.style.setProperty('--p', _gateProgress + '%');
        }

        function bumpGateProgress(toAtLeast, step) {
            if (_skeletonHiddenOnce) return;
            const target = Math.min(92, Math.max(_gateProgress + (step || 8), toAtLeast || 0));
            if (target > _gateProgress) setGateProgress(target);
        }

        window.showAppSkeleton = function() {
            const el = document.getElementById('appSkeleton');
            if (!el) return;
            _skeletonHiddenOnce = false;
            if (_gateHideTimer) { clearTimeout(_gateHideTimer); _gateHideTimer = null; }
            setGateProgress(0);
            el.classList.remove('hidden');
            el.style.display = 'flex';
            el.setAttribute('aria-hidden', 'false');
            if (_gateTickTimer) clearInterval(_gateTickTimer);
            // Yükleme süresince yavaş ilerleme (gerçek veri gelince bump + hide 100 yapar)
            _gateTickTimer = setInterval(function() {
                if (_skeletonHiddenOnce) {
                    clearInterval(_gateTickTimer);
                    _gateTickTimer = null;
                    return;
                }
                if (_gateProgress < 88) {
                    // yavaşlayan artış
                    const add = _gateProgress < 40 ? 2.2 : (_gateProgress < 70 ? 1.1 : 0.45);
                    setGateProgress(_gateProgress + add);
                }
            }, 120);
        };

        window.hideAppSkeleton = function() {
            const el = document.getElementById('appSkeleton');
            if (_gateTickTimer) { clearInterval(_gateTickTimer); _gateTickTimer = null; }
            setGateProgress(100);
            _skeletonHiddenOnce = true;
            if (!el) return;
            if (_gateHideTimer) clearTimeout(_gateHideTimer);
            // ışıltı %100 görünsün diye kısa bekleme
            _gateHideTimer = setTimeout(function() {
                el.classList.add('hidden');
                el.style.display = 'none';
                el.setAttribute('aria-hidden', 'true');
                setGateProgress(0);
            }, 280);
        };

        function scheduleRenderApp() {
            clearTimeout(renderTimeout);
            try { bumpGateProgress(_gateProgress + 12, 10); } catch (_) {}
            renderTimeout = setTimeout(() => {
                renderApp();
                if (isStatsTabActive()) updateStatsPanel();
                try { hideAppSkeleton(); } catch (_) {}
            }, 80);
        }

        function renderApp() {
            renderBudgetInfo();
            renderTable();
            renderCurrentStatements();
            const vt = document.getElementById('tabContentVehicle');
            if (vt && !vt.classList.contains('hidden') && typeof renderVehicleTab === 'function') {
                renderVehicleTab();
            }
        }

        function loadDeletedExpenses() {
            try {
                const stored = localStorage.getItem('deletedExpenses');
                deletedExpenses = stored ? JSON.parse(stored) : [];
            } catch {
                deletedExpenses = [];
            }
        }

        // Sekme Değiştirme
        window.switchTab = function(tabName) {
            lastActiveTabId = tabName;
            const coreIds = ["home", "calendar", "tasks", "shopping", "expense", "vehicle", "stats", "notes", "settings", "trash"];
            const isCustom = String(tabName).startsWith('custom_');

            // Hide all core contents + custom
            coreIds.forEach(name => {
                const el = document.getElementById(`tabContent${capitalizeTab(name)}`);
                if (el) el.classList.add('hidden');
            });
            const customEl = document.getElementById('tabContentCustom');
            if (customEl) customEl.classList.add('hidden');

            // Update tab button styles
            const bar = document.getElementById('tabBar');
            if (bar) {
                bar.querySelectorAll('button[data-tab-id]').forEach(btn => {
                    const active = btn.getAttribute('data-tab-id') === tabName;
                    btn.classList.toggle('tab-active', active);
                    btn.classList.toggle('tab-inactive', !active);
                });
            }

            if (isCustom) {
                const tab = tabsConfig.find(t => t.id === tabName);
                if (customEl) {
                    customEl.classList.remove('hidden');
                    if (tab) renderCustomTabPage(tab);
                }
                return;
            }

            if (tabName === 'reports') {
                switchTab('stats');
                return;
            }
            if (tabName === 'calculator') {
                switchTab('expense');
                return;
            }
            if (tabName === 'settings' && !isAdmin()) {
                switchTab('expense');
                return;
            }
            if (tabName === 'trash' && !isAdmin()) {
                switchTab('expense');
                return;
            }

            const content = document.getElementById(`tabContent${capitalizeTab(tabName)}`);
            if (content) content.classList.remove('hidden');
            try { if (typeof applyPageLayout === 'function') applyPageLayout(String(tabName || '').toLowerCase()); } catch (_l) {}

            if (tabName === 'expense') {
                if (typeof refreshGoldPrice === 'function') refreshGoldPrice(false);
                if (typeof renderGoldHoldings === 'function') renderGoldHoldings();
                if (typeof applyPageLayout === 'function') applyPageLayout('expense');
            }
            if (tabName === 'stats') {
                updateStatsPanel();
                renderMonthlyReports();
                if (typeof renderBillsChart === 'function') renderBillsChart();
                if (typeof renderCardStatements === 'function') {
                    renderCardStatements('bekir');
                    renderCardStatements('duygu');
                }
                if (expenseChart) expenseChart.resize();
            } else if (tabName === 'vehicle') {
                renderVehicleTab();
            } else if (tabName === 'home') {
                if (typeof renderHomeTab === 'function') renderHomeTab();
            } else if (tabName === 'calendar') {
                if (typeof renderCalendarTab === 'function') renderCalendarTab();
            } else if (tabName === 'tasks') {
                if (typeof renderTasksTab === 'function') renderTasksTab();
            } else if (tabName === 'shopping') {
                if (typeof renderShoppingTab === 'function') renderShoppingTab();
            } else if (tabName === 'trash') {
                renderTrash();
            } else if (tabName === 'notes') {
                renderIbans();
            } else if (tabName === 'settings') {
                renderCategoriesList();
                renderTabsList();
                applyPeriodConfigToForm();
                applyDashboardCards();
                if (typeof setAppTheme === 'function') setAppTheme(appTheme);
            }
            if (typeof updateMobileBottomNav === 'function') updateMobileBottomNav(tabName);
        };

        window.renderHomeTab = function() {
            try {
                const greet = document.getElementById('homeGreeting');
                const name = (currentUser && currentUser.name) ? currentUser.name : '';
                const hour = new Date().getHours();
                const hi = hour < 12 ? 'Günaydın' : (hour < 18 ? 'İyi günler' : 'İyi akşamlar');
                if (greet) greet.textContent = hi + (name ? ', ' + name : '');

                try { if (typeof loadDailyAyah === 'function') loadDailyAyah(false); } catch (_) {}

                const dateEl = document.getElementById('homeTodayDate');
                if (dateEl) {
                    dateEl.textContent = new Date().toLocaleDateString('tr-TR', {
                        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
                    });
                }

                const period = (typeof getCurrentPeriod === 'function') ? getCurrentPeriod() : '';
                const badge = document.getElementById('homePeriodBadge');
                if (badge) badge.textContent = period ? ('Dönem: ' + period) : 'Dönem: —';

                let periodSum = 0, todaySum = 0, todayCount = 0, periodCash = 0, periodCard = 0;
                const today = (typeof todayDateStr === 'function') ? todayDateStr() : '';
                try {
                    const list = (typeof getProcessedExpenses === 'function') ? getProcessedExpenses() : [];
                    list.forEach(function(e) {
                        if (!e || e.installmentLabel === 'Gelir') return;
                        const amt = Number(e.displayAmount) || 0;
                        if (e.effectiveMonth === period) {
                            periodSum += amt;
                            if (typeof isCashPayment === 'function' && isCashPayment(e.paymentType)) periodCash += amt;
                            else if (typeof isCreditPayment === 'function' && isCreditPayment(e.paymentType)) periodCard += amt;
                            else {
                                const pt = String(e.paymentType || '').toLowerCase();
                                if (pt.indexOf('nakit') >= 0) periodCash += amt;
                                else periodCard += amt;
                            }
                        }
                        if (String(e.date || '').slice(0, 10) === today) {
                            todaySum += amt;
                            todayCount += 1;
                        }
                    });
                } catch (_) {}

                const elPeriod = document.getElementById('homePeriodSpend');
                if (elPeriod) elPeriod.textContent = Math.round(periodSum).toLocaleString('tr-TR') + ' TL';
                const elPC = document.getElementById('homePeriodCash');
                const elPK = document.getElementById('homePeriodCard');
                if (elPC) elPC.textContent = Math.round(periodCash).toLocaleString('tr-TR') + ' TL';
                if (elPK) elPK.textContent = Math.round(periodCard).toLocaleString('tr-TR') + ' TL';
                const elToday = document.getElementById('homeTodaySpend');
                if (elToday) elToday.textContent = Math.round(todaySum).toLocaleString('tr-TR') + ' TL';
                const elTodayN = document.getElementById('homeTodayCount');
                if (elTodayN) elTodayN.textContent = todayCount + ' kayıt';

                let notifCount = 0;
                try {
                    notifCount = (typeof collectAppNotifications === 'function') ? collectAppNotifications().length : 0;
                } catch (_) {}
                const elN = document.getElementById('homeNotifCount');
                if (elN) elN.textContent = String(notifCount);

                // Bütçe hedefi kartı
                try {
                    const target = Number(monthlyBudgetTarget) || 0;
                    const lab = document.getElementById('homeBudgetLabel');
                    const bar = document.getElementById('homeBudgetBar');
                    if (lab) {
                        if (target > 0) {
                            const pct = Math.min(999, Math.round(periodSum / target * 100));
                            lab.textContent = Math.round(periodSum).toLocaleString('tr-TR') + ' / ' + target.toLocaleString('tr-TR') + ' TL · %' + pct;
                        } else {
                            lab.textContent = 'Hedef tanımlı değil (Ayarlar)';
                        }
                    }
                    if (bar) {
                        const pctW = target > 0 ? Math.min(100, (periodSum / target) * 100) : 0;
                        bar.style.width = pctW + '%';
                        bar.className = 'h-full rounded-full transition-all ' + (pctW >= 100 ? 'bg-rose-500' : pctW >= 80 ? 'bg-amber-500' : 'bg-sky-500');
                    }
                } catch (_) {}

                try { if (typeof renderHomeLocalBriefing === 'function') renderHomeLocalBriefing(periodSum, todaySum); } catch (_) {}

                // Ana sayfa görev listesi (sadece görüntüleme)
                try {
                    const htList = document.getElementById('homeTasksList');
                    if (htList) {
                        const open = (familyTasks || []).filter(function(t) { return !t.done; });
                        const done = (familyTasks || []).filter(function(t) { return t.done; }).slice(0, 3);
                        const show = open.concat(done).slice(0, 8);
                        const allT = familyTasks || [];
                        const openN = allT.filter(function(t) { return !t.done; }).length;
                        const doneN = allT.filter(function(t) { return t.done; }).length;
                        const totalN = openN + doneN;
                        const progWrap = document.getElementById('homeTasksProgress');
                        const progArc = document.getElementById('homeTasksProgressArc');
                        const progLbl = document.getElementById('homeTasksProgressLabel');
                        if (progWrap && totalN > 0) {
                            progWrap.classList.remove('hidden');
                            const pct = Math.round((doneN / totalN) * 100);
                            if (progArc) progArc.setAttribute('stroke-dasharray', pct + ', 100');
                            if (progLbl) progLbl.textContent = doneN + '/' + totalN;
                        } else if (progWrap) {
                            progWrap.classList.add('hidden');
                        }
                        if (!show.length) {
                            htList.innerHTML = yuvamEmptyState('✅', 'Açık görev yok', 'Eklemek için Görevler sekmesine gidin', 'Görevler', "switchTab('tasks')");
                        } else {
                            htList.innerHTML = show.map(function(t) {
                                const due = t.due ? formatDateTR(t.due) : '';
                                const who = t.assignee && t.assignee !== 'Herkes' ? t.assignee : '';
                                const sub = [due, who].filter(Boolean).join(' · ');
                                return '<div class="flex gap-2 items-start p-2.5 rounded-xl bg-slate-50 border border-slate-100">' +
                                    '<span class="text-sm shrink-0">' + (t.done ? '☑️' : '⬜') + '</span>' +
                                    '<div class="min-w-0"><p class="text-sm font-bold text-slate-800 ' + (t.done ? 'line-through opacity-60' : '') + '">' + escapeHtml(t.text || '-') + '</p>' +
                                    (sub ? '<p class="text-[10px] text-slate-400 font-semibold">' + escapeHtml(sub) + '</p>' : '') +
                                    '</div></div>';
                            }).join('');
                        }
                    }
                } catch (_) {}

                if (typeof applyDashboardCards === 'function') applyDashboardCards();
                try { if (typeof updateAdminLayoutButtons === 'function') updateAdminLayoutButtons(); } catch (_) {}
                try {
                    if (typeof refreshGoldPrice === 'function') refreshGoldPrice(false);
                    if (typeof updateHomeGoldCard === 'function') updateHomeGoldCard();
                    else if (typeof renderGoldHoldings === 'function') renderGoldHoldings();
                } catch (_) {}
                try { if (typeof applyPageLayout === 'function') applyPageLayout('home'); } catch (_) {}

                // Yaklaşan bildirim özeti (max 4)
                const listEl = document.getElementById('homeUpcomingList');
                if (listEl) {
                    let items = [];
                    try {
                        items = (typeof collectAppNotifications === 'function')
                            ? collectAppNotifications().filter(function(n) { return n && n.category !== 'activity'; }).slice(0, 4)
                            : [];
                    } catch (_) {}
                    if (!items.length) {
                        listEl.innerHTML = yuvamEmptyState('👍', 'Yakın uyarı yok', 'Takvim ve ödemeler burada görünür', null, null);
                    } else {
                        listEl.innerHTML = items.map(function(n) {
                            return '<div class="flex gap-2 items-start p-3 rounded-xl bg-slate-50 border border-slate-100">' +
                                '<span class="text-lg shrink-0">' + (n.icon || '🔔') + '</span>' +
                                '<div class="min-w-0"><p class="text-sm font-bold text-slate-800 truncate">' + escapeHtml(n.title || '') + '</p>' +
                                '<p class="text-[11px] text-slate-500 font-semibold">' + escapeHtml(n.message || '') + '</p></div></div>';
                        }).join('');
                    }
                }

            } catch (err) {
                console.warn('renderHomeTab', err);
            }
        };

        window.updateMobileBottomNav = function(activeId) {
            const nav = document.getElementById('mobileBottomNav');
            if (!nav) return;
            const moreIds = ['shopping', 'stats', 'settings', 'trash', 'vehicle', 'notes'];
            nav.querySelectorAll('[data-mnav]').forEach(function(btn) {
                const id = btn.getAttribute('data-mnav');
                const on = id === activeId || (id === 'more' && moreIds.indexOf(activeId) >= 0);
                btn.classList.toggle('mnav-active', !!on);
            });
            if (typeof updateTaskNavBadges === 'function') updateTaskNavBadges();
        };

        // ——— Günün ayeti (ücretsiz API, her seferinde değişir) ———
        let _ayahTimer = null;
        let _lastAyahText = '';

        const SURAH_NAMES_TR = [
            '', 'Fatiha', 'Bakara', 'Al-i Imran', 'Nisa', 'Maide', 'Enam', 'Araf', 'Enfal', 'Tevbe',
            'Yunus', 'Hud', 'Yusuf', 'Rad', 'Ibrahim', 'Hicr', 'Nahl', 'Isra', 'Kehf', 'Meryem',
            'Taha', 'Enbiya', 'Hac', 'Muminun', 'Nur', 'Furkan', 'Suara', 'Neml', 'Kasas', 'Ankebut',
            'Rum', 'Lokman', 'Secde', 'Ahzab', 'Sebe', 'Fatir', 'Yasin', 'Saffat', 'Sad', 'Zumer',
            'Mumin', 'Fussilet', 'Sura', 'Zuhruf', 'Duhan', 'Casiye', 'Ahkaf', 'Muhammed', 'Fetih', 'Hucurat',
            'Kaf', 'Zariyat', 'Tur', 'Necm', 'Kamer', 'Rahman', 'Vakia', 'Hadid', 'Mucadele', 'Hasr',
            'Mumtahine', 'Saff', 'Cuma', 'Munafikun', 'Tegabun', 'Talak', 'Tahrim', 'Mulk', 'Kalem', 'Hakka',
            'Mearic', 'Nuh', 'Cin', 'Muzzemmil', 'Muddessir', 'Kiyame', 'Insan', 'Murselat', 'Nebe', 'Naziat',
            'Abese', 'Tekvir', 'Infitar', 'Mutaffifin', 'Insikak', 'Buruc', 'Tarik', 'Ala', 'Gasiye', 'Fecr',
            'Beled', 'Sems', 'Leyl', 'Duha', 'Insirah', 'Tin', 'Alak', 'Kadr', 'Beyyine', 'Zilzal',
            'Adiyat', 'Karia', 'Tekasur', 'Asr', 'Humeze', 'Fil', 'Kureys', 'Maun', 'Kevser', 'Kafirun',
            'Nasr', 'Tebbet', 'Ihlas', 'Felak', 'Nas'
        ];

        async function fetchDailyAyah() {
            // 1–6236 arası rastgele ayet, Diyanet Türkçe meal
            const n = 1 + Math.floor(Math.random() * 6236);
            const r = await fetch('https://api.alquran.cloud/v1/ayah/' + n + '/tr.diyanet', { cache: 'no-store' });
            if (!r.ok) throw new Error('ayah http');
            const j = await r.json();
            if (!j || j.code !== 200 || !j.data) throw new Error('ayah data');
            const d = j.data;
            const text = String(d.text || '').trim();
            if (!text) throw new Error('empty ayah');
            const surahNo = (d.surah && d.surah.number) ? Number(d.surah.number) : 0;
            const surahTr = (SURAH_NAMES_TR[surahNo]) ? SURAH_NAMES_TR[surahNo] : (d.surah && d.surah.englishName ? d.surah.englishName : '');
            const num = d.numberInSurah || '';
            const ref = surahTr
                ? (surahTr + (num ? (', ' + num) : ''))
                : ('Ayet ' + n);
            return { text: text, ref: ref };
        }

        window.loadDailyAyah = async function(force) {
            const el = document.getElementById('homeDailyAyah');
            if (!el) return;
            if (force || el.dataset.loaded !== '1') {
                el.textContent = 'Günün ayeti yükleniyor…';
            }
            try {
                let item = null;
                let tries = 0;
                while (tries < 4) {
                    tries++;
                    item = await fetchDailyAyah();
                    if (item.text && item.text !== _lastAyahText) break;
                }
                _lastAyahText = item.text;
                let body = item.text.replace(/\s+/g, ' ').trim();
                if (body.length > 300) body = body.slice(0, 297) + '…';
                el.textContent = 'Günün ayeti (' + item.ref + '): ' + body;
                el.dataset.loaded = '1';
                try {
                    sessionStorage.setItem('yuvam_ayah_cache', JSON.stringify({ t: Date.now(), ref: item.ref, text: body }));
                } catch (_) {}
            } catch (e) {
                try {
                    const raw = sessionStorage.getItem('yuvam_ayah_cache');
                    if (raw) {
                        const o = JSON.parse(raw);
                        if (o && o.text) {
                            el.textContent = 'Günün ayeti' + (o.ref ? (' (' + o.ref + ')') : '') + ': ' + o.text;
                            return;
                        }
                    }
                } catch (_) {}
                el.textContent = 'Günün ayeti yüklenemedi · dokunarak tekrar deneyin';
            }
            if (_ayahTimer) clearInterval(_ayahTimer);
            _ayahTimer = setInterval(function() {
                try {
                    const home = document.getElementById('tabContentHome');
                    if (home && !home.classList.contains('hidden')) loadDailyAyah(true);
                } catch (_) {}
            }, 180000);
        };

        // ——— Aile: Takvim / Görev / Alışveriş ———
        function familyRow(main, sub, actionsHtml) {
            return '<div class="flex justify-between gap-3 items-start p-3 rounded-xl bg-slate-50 border border-slate-100">' +
                '<div class="min-w-0 flex-1">' +
                '<p class="text-sm font-bold text-slate-800">' + main + '</p>' +
                (sub ? '<p class="text-[11px] text-slate-500 font-semibold mt-0.5">' + sub + '</p>' : '') +
                '</div><div class="flex gap-1 shrink-0">' + (actionsHtml || '') + '</div></div>';
        }

        window.yuvamEmptyState = function(icon, title, sub, btnLabel, btnOnclick) {
            let html = '<div class="yuvam-empty">' +
                '<span class="yuvam-empty-ico">' + (icon || '📭') + '</span>' +
                '<p class="yuvam-empty-title">' + escapeHtml(title || 'Henüz kayıt yok') + '</p>' +
                (sub ? '<p class="yuvam-empty-sub">' + escapeHtml(sub) + '</p>' : '');
            if (btnLabel && btnOnclick) {
                html += '<button type="button" class="yuvam-empty-btn" onclick="' + btnOnclick + '">' + escapeHtml(btnLabel) + '</button>';
            }
            html += '</div>';
            return html;
        };

        function calTypeLabel(type) {
            const m = { event: 'Etkinlik', birthday: 'Doğum günü', anniversary: 'Yıldönümü', appointment: 'Randevu', other: 'Diğer' };
            return m[type] || 'Etkinlik';
        }
        function calTypeIcon(type) {
            const m = { event: '📅', birthday: '🎂', anniversary: '💍', appointment: '🩺', other: '📌' };
            return m[type] || '📅';
        }
        function taskRepeatLabel(r) {
            if (r === 'weekly') return 'Her hafta';
            if (r === 'monthly') return 'Her ay';
            return '';
        }
        function addDaysYMD(ymd, days) {
            const p = parseYMD(ymd) || new Date();
            p.setDate(p.getDate() + days);
            return formatYMD(p);
        }
        function addMonthsYMD(ymd, months) {
            const p = parseYMD(ymd) || new Date();
            const d = p.getDate();
            p.setMonth(p.getMonth() + months);
            if (p.getDate() < d) p.setDate(0);
            return formatYMD(p);
        }
        /** Yıllık tekrar: bugünden sonraki ilk gün (MM-DD) */
        function nextYearlyOccurrence(baseYmd) {
            const base = String(baseYmd || '').slice(0, 10);
            if (base.length < 10) return base;
            const md = base.slice(5); // MM-DD
            const today = todayDateStr();
            const y = parseInt(today.slice(0, 4), 10);
            let cand = y + '-' + md;
            if (cand < today) cand = (y + 1) + '-' + md;
            return cand;
        }
        function eventEffectiveDate(ev) {
            if (!ev || !ev.date) return '';
            if (ev.repeat === 'yearly' || ev.type === 'birthday' || ev.type === 'anniversary') {
                return nextYearlyOccurrence(ev.date);
            }
            return String(ev.date).slice(0, 10);
        }

        // ——— Altın yatırımları (goldprice.dev · 24 ayar TRY/gram) ———
        function formatGoldTL(n) {
            const v = Number(n);
            if (!isFinite(v)) return '—';
            return v.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₺';
        }

        function currentGoldPriceForKarat(karat) {
            const k = Number(karat) || 24;
            if (k === 22) {
                if (goldQuotes.sell22 != null) return goldQuotes.sell22;
                if (goldPricePerGram22 != null) return goldPricePerGram22;
                if (goldQuotes.sell24 != null) return goldQuotes.sell24 * (22 / 24);
                if (goldPricePerGram != null) return goldPricePerGram * (22 / 24);
                return null;
            }
            if (goldQuotes.sell24 != null) return goldQuotes.sell24;
            return goldPricePerGram;
        }

        function updateGoldPriceUI() {
            const fmt = function(v) { return v != null && isFinite(v) ? formatGoldTL(v) : '—'; };
            const elB24 = document.getElementById('goldBuy24');
            const elS24 = document.getElementById('goldSell24');
            const elB22 = document.getElementById('goldBuy22');
            const elS22 = document.getElementById('goldSell22');
            if (elB24) elB24.textContent = fmt(goldQuotes.buy24);
            if (elS24) elS24.textContent = fmt(goldQuotes.sell24);
            if (elB22) elB22.textContent = fmt(goldQuotes.buy22);
            if (elS22) elS22.textContent = fmt(goldQuotes.sell22);
        }

        function computeGoldPortfolio() {
            let totalCost = 0, totalValue = 0, totalGrams = 0, hasPriced = false;
            (goldHoldings || []).forEach(function(h) {
                const g = Number(h.grams) || 0;
                const bp = Number(h.buyPrice) || 0;
                const karat = Number(h.karat) || 24;
                const price = currentGoldPriceForKarat(karat);
                totalCost += g * bp;
                totalGrams += g;
                if (price != null) {
                    totalValue += g * price;
                    hasPriced = true;
                }
            });
            return {
                totalCost: totalCost,
                totalValue: totalValue,
                totalGrams: totalGrams,
                pnl: hasPriced ? (totalValue - totalCost) : null,
                hasPriced: hasPriced
            };
        }

        function updateHomeGoldCard() {
            const el = document.getElementById('homeGoldPnL');
            const netEl = document.getElementById('homeGoldNet');
            const sub = document.getElementById('homeGoldSub');
            if (!el) return;
            const p = computeGoldPortfolio();
            if (!(goldHoldings || []).length) {
                el.textContent = 'Kayıt yok';
                el.className = 'text-xl font-black text-slate-400';
                if (netEl) { netEl.textContent = ''; netEl.className = 'text-lg font-black text-slate-400'; }
                if (sub) sub.textContent = 'Bütçe Takip · altın ekle';
                return;
            }
            if (!p.hasPriced) {
                el.textContent = 'Fiyat bekleniyor';
                el.className = 'text-xl font-black text-slate-500';
                if (netEl) {
                    netEl.textContent = 'Net ' + formatGoldTL(p.totalCost);
                    netEl.className = 'text-lg font-black text-slate-600';
                }
                if (sub) sub.textContent = (p.totalGrams || 0) + ' g · maliyet';
                return;
            }
            const pnl = p.pnl;
            const pct = p.totalCost > 0 ? (pnl / p.totalCost * 100) : 0;
            el.textContent = (pnl >= 0 ? '+' : '') + Math.round(pnl).toLocaleString('tr-TR') + ' TL';
            el.className = 'text-xl font-black ' + (pnl >= 0 ? 'text-emerald-600' : 'text-rose-600');
            if (netEl) {
                netEl.textContent = 'Net ' + Math.round(p.totalValue).toLocaleString('tr-TR') + ' TL';
                netEl.className = 'text-lg font-black text-slate-800';
            }
            if (sub) {
                sub.textContent = (pnl >= 0 ? '+' : '') + pct.toFixed(1) + '% · ' +
                    (p.totalGrams || 0) + ' g · maliyet ' + formatGoldTL(p.totalCost);
            }
        }

        window.renderGoldHoldings = function() {
            const list = document.getElementById('goldHoldingsList');
            if (!list) {
                updateHomeGoldCard();
                return;
            }
            const port = computeGoldPortfolio();
            if (!(goldHoldings || []).length) {
                list.innerHTML = '<p class="text-center text-xs text-slate-400 font-semibold py-3">Henüz altın kaydı yok</p>';
            } else {
                const sorted = goldHoldings.slice().sort(function(a, b) {
                    return String(b.buyDate || '').localeCompare(String(a.buyDate || ''));
                });
                list.innerHTML = sorted.map(function(h) {
                    const g = Number(h.grams) || 0;
                    const bp = Number(h.buyPrice) || 0;
                    const karat = Number(h.karat) || 24;
                    const price = currentGoldPriceForKarat(karat);
                    const cost = g * bp;
                    const val = (price != null) ? g * price : null;
                    const pnl = (val != null) ? val - cost : null;
                    const pnlCls = pnl == null ? 'text-slate-500' : (pnl >= 0 ? 'text-emerald-600' : 'text-rose-600');
                    const pnlTxt = pnl == null ? 'Fiyat bekleniyor' : ((pnl >= 0 ? '+' : '') + formatGoldTL(pnl));
                    const karatBadge = '<span class="inline-block text-[10px] font-black px-1.5 py-0.5 rounded-md ' +
                        (karat === 22 ? 'bg-orange-100 text-orange-800' : 'bg-amber-100 text-amber-900') + '">' + karat + ' ayar</span>';
                    return '<div class="p-2.5 rounded-xl border border-slate-100 bg-slate-50/80">' +
                        '<div class="flex justify-between gap-2 items-start">' +
                        '<div class="min-w-0">' +
                        '<p class="text-xs font-black text-slate-800 flex flex-wrap items-center gap-1.5">' + karatBadge + ' ' + g + ' g · alış ' + formatGoldTL(bp) + '/g</p>' +
                        '<p class="text-[10px] text-slate-500 font-semibold">' + escapeHtml(h.buyDate || '') +
                        (h.note ? (' · ' + escapeHtml(h.note)) : '') + '</p>' +
                        '<p class="text-[10px] font-bold text-slate-600 mt-0.5">Maliyet ' + formatGoldTL(cost) +
                        (val != null ? (' · Değer ' + formatGoldTL(val)) : '') + '</p>' +
                        '<p class="text-xs font-black ' + pnlCls + '">' + pnlTxt + '</p>' +
                        '</div>' +
                        '<button type="button" onclick="deleteGoldHolding(\'' + escapeHtml(h.id) + '\')" class="text-[10px] font-bold text-rose-600 px-2 py-1 rounded-lg hover:bg-rose-50 shrink-0">Sil</button>' +
                        '</div></div>';
                }).join('');
            }
            const elCost = document.getElementById('goldSumCost');
            const elVal = document.getElementById('goldSumValue');
            const elPnL = document.getElementById('goldSumPnL');
            if (elCost) elCost.textContent = formatGoldTL(port.totalCost) + (port.totalGrams ? (' · ' + port.totalGrams + ' g') : '');
            if (elVal) elVal.textContent = port.hasPriced ? formatGoldTL(port.totalValue) : '—';
            if (elPnL) {
                if (!port.hasPriced) {
                    elPnL.textContent = '—';
                    elPnL.className = 'font-black text-slate-500';
                } else {
                    const pnl = port.pnl;
                    const pct = port.totalCost > 0 ? (pnl / port.totalCost * 100) : 0;
                    elPnL.textContent = (pnl >= 0 ? '+' : '') + formatGoldTL(pnl) + ' (' + (pct >= 0 ? '+' : '') + pct.toFixed(1) + '%)';
                    elPnL.className = 'font-black ' + (pnl >= 0 ? 'text-emerald-600' : 'text-rose-600');
                }
            }
            const prev = document.getElementById('goldSumPnLPreview');
            if (prev) {
                if (!(goldHoldings || []).length) prev.textContent = 'Kayıt yok';
                else if (!port.hasPriced) prev.textContent = 'Fiyat bekleniyor';
                else {
                    const pnl = port.pnl;
                    prev.textContent = (pnl >= 0 ? '+' : '') + Math.round(pnl).toLocaleString('tr-TR') + ' TL';
                    prev.className = 'font-bold ' + (pnl >= 0 ? 'text-emerald-600' : 'text-rose-600');
                }
            }
            updateHomeGoldCard();
        };

        window.refreshGoldPrice = async function(force) {
            const elMeta = document.getElementById('goldPriceMeta');
            try {
                if (!force && goldQuotes.sell24 != null) {
                    updateGoldPriceUI();
                    renderGoldHoldings();
                    return;
                }
                if (elMeta) elMeta.textContent = 'Fiyat çekiliyor…';

                let buy24 = null, sell24 = null, buy22 = null, sell22 = null;
                let source = '';
                let change = null;

                try {
                    const res = await fetch('https://finans.truncgil.com/v4/today.json', { cache: 'no-store' });
                    if (!res.ok) throw new Error('truncgil ' + res.status);
                    const data = await res.json();
                    const has = data.HAS || data.GRAMHASALTIN || data.GramAltin || data['Gram Altın'];
                    if (has) {
                        buy24 = parseFloat(has.Buying);
                        sell24 = parseFloat(has.Selling);
                        if (!(buy24 > 0)) buy24 = sell24;
                        if (!(sell24 > 0)) sell24 = buy24;
                        if (has.Change != null && has.Change !== '') change = has.Change;
                        source = 'Truncgil' + (data.Update_Date ? (' · ' + data.Update_Date) : '');
                    }
                    const a22 = data['22AYARALTIN'] || data['22AYAR'] || data.AYAR22;
                    if (a22) {
                        buy22 = parseFloat(a22.Buying);
                        sell22 = parseFloat(a22.Selling);
                        if (!(buy22 > 0)) buy22 = sell22;
                        if (!(sell22 > 0)) sell22 = buy22;
                    }
                } catch (_) {}

                if (!(sell24 > 0)) {
                    try {
                        const res2 = await fetch('https://api.goldprice.dev/v1/carat?currency=TRY', { cache: 'no-store' });
                        if (res2.ok) {
                            const data2 = await res2.json();
                            const g24 = parseFloat(data2.price_gram_24k);
                            const g22 = parseFloat(data2.price_gram_22k);
                            if (g24 > 0) { sell24 = g24; buy24 = g24; source = source || 'goldprice.dev'; }
                            if (g22 > 0) { sell22 = g22; buy22 = g22; }
                        }
                    } catch (_) {}
                }

                if (!(sell24 > 0)) throw new Error('Fiyat alınamadı');
                if (!(buy24 > 0)) buy24 = sell24;
                if (!(sell22 > 0)) sell22 = sell24 * (22 / 24);
                if (!(buy22 > 0)) buy22 = buy24 * (22 / 24);

                goldQuotes = { buy24: buy24, sell24: sell24, buy22: buy22, sell22: sell22 };
                goldPricePerGram = sell24;
                goldPricePerGram22 = sell22;
                updateGoldPriceUI();
                if (elMeta) {
                    let meta = source || 'Güncel';
                    if (change != null && change !== '') meta += ' · ' + change + '%';
                    elMeta.textContent = meta;
                }
                try {
                    localStorage.setItem('yuvam_gold_price', JSON.stringify({
                        quotes: goldQuotes, p: sell24, p22: sell22, at: Date.now(), source: source
                    }));
                } catch (_) {}
                renderGoldHoldings();
            } catch (e) {
                try {
                    const raw = localStorage.getItem('yuvam_gold_price');
                    if (raw) {
                        const o = JSON.parse(raw);
                        if (o.quotes && o.quotes.sell24 > 0) {
                            goldQuotes = o.quotes;
                            goldPricePerGram = o.quotes.sell24;
                            goldPricePerGram22 = o.quotes.sell22;
                        } else if (o.p > 0) {
                            goldPricePerGram = o.p;
                            goldPricePerGram22 = o.p22 > 0 ? o.p22 : o.p * (22 / 24);
                            goldQuotes = {
                                buy24: o.p, sell24: o.p,
                                buy22: goldPricePerGram22, sell22: goldPricePerGram22
                            };
                        }
                        updateGoldPriceUI();
                        if (elMeta) elMeta.textContent = 'Önbellek · elle de girebilirsiniz';
                        renderGoldHoldings();
                        return;
                    }
                } catch (_) {}
                if (elMeta) elMeta.textContent = 'API yok — elle 24A satış ₺/g girin';
            }
        };


        window.toggleGoldPanel = function() {
            const body = document.getElementById('goldPanelBody');
            const chev = document.getElementById('goldToggleChevron');
            if (!body) return;
            const open = body.classList.contains('hidden');
            body.classList.toggle('hidden', !open);
            if (chev) chev.style.transform = open ? 'rotate(180deg)' : '';
            if (open) {
                try {
                    if (typeof refreshGoldPrice === 'function') refreshGoldPrice(false);
                    if (typeof renderGoldHoldings === 'function') renderGoldHoldings();
                } catch (_) {}
            }
        };

        window.applyManualGoldPrice = function() {
            const inp = document.getElementById('goldManualPrice');
            const p = parseFloat(inp && inp.value);
            if (!isFinite(p) || p <= 0) {
                if (typeof showToast === 'function') showToast('Geçerli bir 24 ayar satış fiyatı girin', 'error');
                return;
            }
            const p22 = p * (22 / 24);
            goldQuotes = { buy24: p, sell24: p, buy22: p22, sell22: p22 };
            goldPricePerGram = p;
            goldPricePerGram22 = p22;
            try {
                localStorage.setItem('yuvam_gold_price', JSON.stringify({
                    quotes: goldQuotes, p: p, p22: p22, at: Date.now()
                }));
            } catch (_) {}
            updateGoldPriceUI();
            const elMeta = document.getElementById('goldPriceMeta');
            if (elMeta) elMeta.textContent = 'Elle girildi';
            renderGoldHoldings();
            if (typeof showToast === 'function') showToast('Fiyat güncellendi', 'success');
        };

        const GOLD_LS_KEY = 'yuvam_gold_holdings_v1';

        function loadGoldHoldingsLocal() {
            try {
                const raw = localStorage.getItem(GOLD_LS_KEY);
                if (!raw) return [];
                const arr = JSON.parse(raw);
                return Array.isArray(arr) ? arr : [];
            } catch (_) { return []; }
        }

        function saveGoldHoldingsLocal(list) {
            try { localStorage.setItem(GOLD_LS_KEY, JSON.stringify(list || [])); } catch (_) {}
        }

        async function persistGoldHoldings(list) {
            goldHoldings = list || [];
            saveGoldHoldingsLocal(goldHoldings);
            // settings koleksiyonu zaten izinli — tek doküman
            try {
                await db.collection('settings').doc('goldHoldings').set({
                    list: goldHoldings,
                    updatedAt: new Date().toISOString()
                }, { merge: true });
            } catch (e) {
                console.warn('gold settings write', e);
                // local yeterli
            }
            renderGoldHoldings();
        }

        window.addGoldHolding = async function(e) {
            e.preventDefault();
            if (!currentUser) {
                if (typeof showToast === 'function') showToast('Önce giriş yapın', 'error');
                return;
            }
            const karat = parseInt((document.getElementById('goldKarat') || {}).value, 10) || 24;
            const grams = parseFloat((document.getElementById('goldGrams') || {}).value);
            const buyPrice = parseFloat((document.getElementById('goldBuyPrice') || {}).value);
            const buyDate = ((document.getElementById('goldBuyDate') || {}).value || '').trim();
            const note = ((document.getElementById('goldNote') || {}).value || '').trim();
            if (!isFinite(grams) || grams <= 0 || !isFinite(buyPrice) || buyPrice <= 0 || !buyDate) {
                if (typeof showToast === 'function') showToast('Gram, alış fiyatı ve tarih zorunlu', 'error');
                return;
            }
            try {
                const row = {
                    id: 'g_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
                    karat: (karat === 22 ? 22 : 24),
                    grams: grams,
                    buyPrice: buyPrice,
                    buyDate: buyDate,
                    note: note,
                    createdAt: new Date().toISOString(),
                    createdBy: currentUser.name || currentUser.uid || ''
                };
                const next = (goldHoldings || []).concat([row]);
                await persistGoldHoldings(next);
                const g = document.getElementById('goldGrams');
                const bp = document.getElementById('goldBuyPrice');
                const n = document.getElementById('goldNote');
                if (g) g.value = '';
                if (bp) bp.value = '';
                if (n) n.value = '';
                if (typeof showToast === 'function') showToast('Altın kaydı eklendi', 'success');
            } catch (err) {
                console.error(err);
                if (typeof showToast === 'function') showToast('Kayıt eklenemedi: ' + (err.message || err), 'error');
            }
        };

        window.deleteGoldHolding = async function(id) {
            if (!id || !confirm('Bu altın kaydı silinsin mi?')) return;
            try {
                const next = (goldHoldings || []).filter(function(h) { return h.id !== id; });
                await persistGoldHoldings(next);
                if (typeof showToast === 'function') showToast('Silindi', 'success');
            } catch (err) {
                if (typeof showToast === 'function') showToast('Silinemedi', 'error');
            }
        };

        // Sayfa açılışında fiyatı arka planda dene
        setTimeout(function() {
            try { if (currentUser && typeof refreshGoldPrice === 'function') refreshGoldPrice(true); } catch (_) {}
        }, 2000);

        window.renderCalendarTab = function() {
            const list = document.getElementById('familyCalendarList');
            if (!list) return;
            const sorted = (familyCalendar || []).slice().sort(function(a, b) {
                return eventEffectiveDate(a).localeCompare(eventEffectiveDate(b));
            });
            if (!sorted.length) {
                list.innerHTML = yuvamEmptyState('📅', 'Takvim boş', 'Randevu, doğum günü veya hatırlatma ekleyin', null, null);
                return;
            }
            list.innerHTML = sorted.map(function(ev) {
                const eff = eventEffectiveDate(ev);
                const days = daysUntilYMD(eff);
                const badge = days == null ? '' : (days < 0 ? 'geçti' : (days === 0 ? 'bugün' : days + ' gün'));
                const typeLab = calTypeLabel(ev.type);
                const rep = (ev.repeat === 'yearly' || ev.type === 'birthday' || ev.type === 'anniversary') ? ' · her yıl' : '';
                const sub = calTypeIcon(ev.type) + ' ' + typeLab + ' · ' + formatDateTR(eff) + (badge ? ' · ' + badge : '') + rep + (ev.by ? ' · ' + ev.by : '');
                const editBtn = '<button type="button" onclick="familyEditCalendar(\'' + escapeHtml(ev.id) + '\')" class="text-xs font-bold text-sky-600 px-2 py-1 rounded-lg hover:bg-sky-50">Düzenle</button>';
                const delBtn = '<button type="button" onclick="familyDelete(\'familyCalendar\',\'' + escapeHtml(ev.id) + '\')" class="text-xs font-bold text-rose-600 px-2 py-1 rounded-lg hover:bg-rose-50">Sil</button>';
                return familyRow(escapeHtml(ev.title || '-'), escapeHtml(sub), editBtn + delBtn);
            }).join('');
            const dInp = document.getElementById('famCalDate');
            if (dInp && !dInp.value) dInp.value = todayDateStr();
        };

        window.familyEditCalendar = function(id) {
            const ev = (familyCalendar || []).find(function(x) { return x.id === id; });
            if (!ev) return;
            const eid = document.getElementById('famCalEditId');
            if (eid) eid.value = id;
            const t = document.getElementById('famCalTitle');
            if (t) t.value = ev.title || '';
            const d = document.getElementById('famCalDate');
            if (d) d.value = String(ev.date || '').slice(0, 10);
            const ty = document.getElementById('famCalType');
            if (ty) ty.value = ev.type || 'event';
            const r = document.getElementById('famCalRepeat');
            if (r) r.value = ev.repeat || 'none';
            const btn = document.getElementById('famCalSubmitBtn');
            if (btn) btn.textContent = 'Güncelle';
            const c = document.getElementById('famCalCancelEdit');
            if (c) c.classList.remove('hidden');
            if (t) t.focus();
        };

        window.familyCancelCalEdit = function() {
            const eid = document.getElementById('famCalEditId');
            if (eid) eid.value = '';
            const t = document.getElementById('famCalTitle');
            if (t) t.value = '';
            const btn = document.getElementById('famCalSubmitBtn');
            if (btn) btn.textContent = 'Ekle';
            const c = document.getElementById('famCalCancelEdit');
            if (c) c.classList.add('hidden');
        };

        window.familyAddCalendar = async function(e) {
            e.preventDefault();
            const title = ((document.getElementById('famCalTitle') || {}).value || '').trim();
            const date = (document.getElementById('famCalDate') || {}).value;
            if (!title || !date) return;
            let type = (document.getElementById('famCalType') || {}).value || 'event';
            let repeat = (document.getElementById('famCalRepeat') || {}).value || 'none';
            if (type === 'birthday' || type === 'anniversary') repeat = 'yearly';
            const editId = ((document.getElementById('famCalEditId') || {}).value || '').trim();
            try {
                if (editId) {
                    await db.collection('familyCalendar').doc(editId).update({
                        title: title,
                        date: date,
                        type: type,
                        repeat: repeat,
                        updatedAt: new Date().toISOString(),
                        updatedBy: (currentUser && currentUser.name) || ''
                    });
                    showToast('Etkinlik güncellendi', 'success');
                    familyCancelCalEdit();
                } else {
                    await db.collection('familyCalendar').add({
                        title: title,
                        date: date,
                        type: type,
                        repeat: repeat,
                        by: (currentUser && currentUser.name) || '',
                        createdAt: new Date().toISOString()
                    });
                    document.getElementById('famCalTitle').value = '';
                    showToast('Takvime eklendi', 'success');
                }
            } catch (err) { showToast(friendlyFirebaseError(err), 'error'); }
        };

        window.renderTasksTab = function() {
            const list = document.getElementById('familyTasksList');
            if (!list) return;
            const open = (familyTasks || []).filter(function(t) { return !t.done; });
            const done = (familyTasks || []).filter(function(t) { return t.done; });
            const sorted = open.concat(done).sort(function(a, b) {
                return String(a.due || '9999').localeCompare(String(b.due || '9999'));
            });
            if (!sorted.length) {
                list.innerHTML = yuvamEmptyState('✅', 'Görev yok', 'Aile görevlerini ekleyin; ana sayfada da görünür', null, null);
                return;
            }
            list.innerHTML = sorted.map(function(t) {
                const due = t.due ? formatDateTR(t.due) : 'Tarihsiz';
                const who = t.assignee && t.assignee !== 'Herkes' ? t.assignee : 'Herkes';
                const rep = taskRepeatLabel(t.repeat);
                const main = (t.done ? '<span class="line-through opacity-60">' : '') + escapeHtml(t.text || '-') + (t.done ? '</span>' : '');
                const sub = due + ' · ' + who + (rep ? ' · 🔁 ' + rep : '') + (t.by ? ' · ekleyen: ' + t.by : '');
                const editB = '<button type="button" onclick="familyEditTask(\'' + escapeHtml(t.id) + '\')" class="text-xs font-bold text-sky-600 px-2 py-1 rounded-lg hover:bg-sky-50">Düzenle</button>';
                const tog = '<button type="button" onclick="familyToggleTask(\'' + escapeHtml(t.id) + '\',' + (t.done ? 'false' : 'true') + ')" class="text-xs font-bold px-2 py-1 rounded-lg ' +
                    (t.done ? 'text-slate-500 bg-slate-100' : 'text-emerald-700 bg-emerald-50') + '">' + (t.done ? 'Geri al' : 'Tamam') + '</button>';
                const del = '<button type="button" onclick="familyDelete(\'familyTasks\',\'' + escapeHtml(t.id) + '\')" class="text-xs font-bold text-rose-600 px-2 py-1 rounded-lg hover:bg-rose-50">Sil</button>';
                return familyRow(main, escapeHtml(sub), editB + tog + del);
            }).join('');
        };

        window.familyEditTask = function(id) {
            const t = (familyTasks || []).find(function(x) { return x.id === id; });
            if (!t) return;
            const eid = document.getElementById('famTaskEditId');
            if (eid) eid.value = id;
            const tx = document.getElementById('famTaskText');
            if (tx) tx.value = t.text || '';
            const due = document.getElementById('famTaskDue');
            if (due) due.value = t.due ? String(t.due).slice(0, 10) : '';
            const asg = document.getElementById('famTaskAssignee');
            if (asg) asg.value = t.assignee || 'Herkes';
            const rep = document.getElementById('famTaskRepeat');
            if (rep) rep.value = t.repeat || 'none';
            const btn = document.getElementById('famTaskSubmitBtn');
            if (btn) btn.textContent = 'Güncelle';
            const c = document.getElementById('famTaskCancelEdit');
            if (c) c.classList.remove('hidden');
            if (tx) tx.focus();
        };

        window.familyCancelTaskEdit = function() {
            const eid = document.getElementById('famTaskEditId');
            if (eid) eid.value = '';
            const tx = document.getElementById('famTaskText');
            if (tx) tx.value = '';
            const due = document.getElementById('famTaskDue');
            if (due) due.value = '';
            const btn = document.getElementById('famTaskSubmitBtn');
            if (btn) btn.textContent = 'Ekle';
            const c = document.getElementById('famTaskCancelEdit');
            if (c) c.classList.add('hidden');
        };

        window.familyAddTask = async function(e) {
            e.preventDefault();
            const text = ((document.getElementById('famTaskText') || {}).value || '').trim();
            if (!text) return;
            const due = (document.getElementById('famTaskDue') || {}).value || '';
            const assignee = (document.getElementById('famTaskAssignee') || {}).value || 'Herkes';
            const repeat = (document.getElementById('famTaskRepeat') || {}).value || 'none';
            const editId = ((document.getElementById('famTaskEditId') || {}).value || '').trim();
            try {
                if (editId) {
                    await db.collection('familyTasks').doc(editId).update({
                        text: text,
                        due: due,
                        assignee: assignee,
                        repeat: repeat,
                        updatedAt: new Date().toISOString(),
                        updatedBy: (currentUser && currentUser.name) || ''
                    });
                    showToast('Görev güncellendi', 'success');
                    familyCancelTaskEdit();
                } else {
                    await db.collection('familyTasks').add({
                        text: text,
                        due: due,
                        assignee: assignee,
                        repeat: repeat,
                        done: false,
                        by: (currentUser && currentUser.name) || '',
                        createdAt: new Date().toISOString()
                    });
                    document.getElementById('famTaskText').value = '';
                    showToast(repeat !== 'none' ? 'Tekrarlayan görev eklendi' : 'Görev eklendi', 'success');
                }
            } catch (err) { showToast(friendlyFirebaseError(err), 'error'); }
        };

        window.familyToggleTask = async function(id, done) {
            if (!id) return;
            try {
                const t = (familyTasks || []).find(function(x) { return x.id === id; });
                if (done && t && (t.repeat === 'weekly' || t.repeat === 'monthly')) {
                    const base = t.due || todayDateStr();
                    const next = t.repeat === 'weekly' ? addDaysYMD(base, 7) : addMonthsYMD(base, 1);
                    await db.collection('familyTasks').doc(id).update({
                        done: false,
                        due: next,
                        lastCompletedAt: new Date().toISOString()
                    });
                    showToast('Tamam · sonraki: ' + formatDateTR(next), 'success');
                } else {
                    await db.collection('familyTasks').doc(id).update({ done: !!done });
                }
            } catch (err) { showToast(friendlyFirebaseError(err), 'error'); }
        };

        window.renderShoppingTab = function() {
            const list = document.getElementById('familyShopList');
            if (!list) return;
            const open = (familyShopping || []).filter(function(x) { return !x.bought; });
            const bought = (familyShopping || []).filter(function(x) { return x.bought; });
            const sorted = open.concat(bought);
            const openN = open.length;
            const sumEl = document.getElementById('familyShopSummary');
            if (sumEl) sumEl.textContent = openN + ' ürün alınacak' + (bought.length ? ' · ' + bought.length + ' alındı' : '');
            if (!sorted.length) {
                list.innerHTML = yuvamEmptyState('🛒', 'Alışveriş listesi boş', 'Market veya ev ihtiyaçlarını ekleyin', null, null);
                return;
            }
            list.innerHTML = sorted.map(function(x) {
                const main = (x.bought ? '<span class="line-through opacity-50">' : '') + escapeHtml(x.name || '-') + (x.bought ? '</span>' : '');
                const qty = x.qty ? String(x.qty) : '';
                const sub = [qty, x.category, x.by].filter(Boolean).join(' · ');
                const tog = '<button type="button" onclick="familyToggleShop(\'' + escapeHtml(x.id) + '\',' + (x.bought ? 'false' : 'true') + ')" class="text-xs font-bold px-2 py-1 rounded-lg ' +
                    (x.bought ? 'text-slate-500 bg-slate-100' : 'text-sky-700 bg-sky-50') + '">' + (x.bought ? 'Geri' : 'Alındı') + '</button>';
                const del = '<button type="button" onclick="familyDelete(\'familyShopping\',\'' + escapeHtml(x.id) + '\')" class="text-xs font-bold text-rose-600 px-2 py-1 rounded-lg hover:bg-rose-50">Sil</button>';
                return familyRow(main, escapeHtml(sub || '—'), tog + del);
            }).join('');
        };

        window.familyAddShop = async function(e) {
            e.preventDefault();
            const name = ((document.getElementById('famShopName') || {}).value || '').trim();
            if (!name) return;
            const qty = ((document.getElementById('famShopQty') || {}).value || '').trim();
            const category = (document.getElementById('famShopCat') || {}).value || 'Market';
            try {
                await db.collection('familyShopping').add({
                    name: name,
                    qty: qty,
                    category: category,
                    bought: false,
                    by: (currentUser && currentUser.name) || '',
                    createdAt: new Date().toISOString()
                });
                document.getElementById('famShopName').value = '';
                document.getElementById('famShopQty').value = '';
                showToast('Listeye eklendi', 'success');
            } catch (err) { showToast(friendlyFirebaseError(err), 'error'); }
        };

        window.familyToggleShop = async function(id, bought) {
            if (!id) return;
            try {
                await db.collection('familyShopping').doc(id).update({ bought: !!bought });
            } catch (err) { showToast(friendlyFirebaseError(err), 'error'); }
        };

        window.familyDelete = async function(col, id) {
            if (!col || !id) return;
            if (!confirm('Silinsin mi?')) return;
            try {
                await db.collection(col).doc(id).delete();
                showToast('Silindi', 'info');
            } catch (err) { showToast(friendlyFirebaseError(err), 'error'); }
        };

        window.familyClearBoughtShop = async function() {
            const bought = (familyShopping || []).filter(function(x) { return x.bought; });
            if (!bought.length) { showToast('Alınan ürün yok', 'info'); return; }
            if (!confirm(bought.length + ' alınan ürün listeden silinsin mi?')) return;
            try {
                await Promise.all(bought.map(function(x) { return db.collection('familyShopping').doc(x.id).delete(); }));
                showToast('Temizlendi', 'success');
            } catch (err) { showToast(friendlyFirebaseError(err), 'error'); }
        };

        window.openMobileMoreSheet = function() {
            const sheet = document.getElementById('mobileMoreSheet');
            if (!sheet) return;
            sheet.classList.remove('hidden');
            sheet.style.display = 'flex';
        };

        window.closeMobileMoreSheet = function() {
            const sheet = document.getElementById('mobileMoreSheet');
            if (!sheet) return;
            sheet.classList.add('hidden');
            sheet.style.display = 'none';
        };

        window.mobileNavGo = function(tabId) {
            if (tabId === 'more') {
                const sheet = document.getElementById('mobileMoreSheet');
                if (sheet && !sheet.classList.contains('hidden')) {
                    closeMobileMoreSheet();
                } else {
                    openMobileMoreSheet();
                }
                return;
            }
            closeMobileMoreSheet();
            switchTab(tabId);
        };

        // Ana sayfa + finans kart görünürlüğü (Ayarlar)
        const DASH_CARD_KEYS = [
            'total', 'bekir', 'duygu', 'debt',
            'homeToday', 'homePeriod', 'homeNotif', 'homeGold', 'homeQuickAdd', 'homeUpcoming', 'homeBudget', 'homeTasks', 'homeBriefing'
        ];



        // ——— Sayfa düzeni (kalıcı: localStorage + Firebase) ———
        let layoutEditPage = null;
        let pageLayoutsCloud = {}; // settings/pageLayouts

        function currentLayoutPageId() {
            const tabs = document.querySelectorAll('[id^="tabContent"]');
            for (let i = 0; i < tabs.length; i++) {
                const el = tabs[i];
                if (el.classList && !el.classList.contains('hidden')) {
                    return el.id.replace(/^tabContent/, '').toLowerCase();
                }
            }
            if (typeof currentTab !== 'undefined' && currentTab) return String(currentTab).toLowerCase();
            return 'home';
        }

        function layoutContainer(page) {
            if (!page) return null;
            const id = 'tabContent' + page.charAt(0).toUpperCase() + page.slice(1);
            let el = document.getElementById(id);
            if (el) return el;
            const all = document.querySelectorAll('[id^="tabContent"]');
            for (let i = 0; i < all.length; i++) {
                if (all[i].id.toLowerCase() === ('tabcontent' + page).toLowerCase()) return all[i];
            }
            return null;
        }

        function hashStr(s) {
            let h = 0;
            for (let i = 0; i < s.length; i++) h = ((h << 5) - h) + s.charCodeAt(i) | 0;
            return h;
        }

        function ensureLayoutBlocks(root, page) {
            if (!root) return;
            let n = 0;
            Array.prototype.forEach.call(root.children, function(ch) {
                if (!ch || ch.nodeType !== 1) return;
                if (ch.getAttribute('data-layout-fixed') === '1') return;
                if (ch.classList && ch.classList.contains('home-hero')) {
                    ch.setAttribute('data-layout-fixed', '1');
                    return;
                }
                if (ch.id === 'homeHeroBanner') {
                    ch.setAttribute('data-layout-fixed', '1');
                    return;
                }
                const text = (ch.textContent || '').trim();
                if (!text || text.length < 2) return;
                if (ch.getAttribute('data-layout-block')) return;
                // stabil kimlik: mevcut sabit id varsa onu kullan
                const stable = ch.getAttribute('data-home-card') || ch.id || '';
                n += 1;
                const id = stable
                    ? String(stable)
                    : (page + '_b' + n + '_' + Math.abs(hashStr((ch.className || '') + text.slice(0, 32))).toString(36).slice(0, 6));
                ch.setAttribute('data-layout-block', id);
            });
        }

        function getLayoutOrder(page) {
            // Önce bulut, sonra local
            if (pageLayoutsCloud && Array.isArray(pageLayoutsCloud[page]) && pageLayoutsCloud[page].length) {
                return pageLayoutsCloud[page].slice();
            }
            try {
                const raw = localStorage.getItem('yuvam_layout_' + page);
                if (raw) {
                    const arr = JSON.parse(raw);
                    if (Array.isArray(arr) && arr.length) return arr;
                }
            } catch (_) {}
            return [];
        }

        function saveLayoutOrder(page, order) {
            try { localStorage.setItem('yuvam_layout_' + page, JSON.stringify(order)); } catch (_) {}
            pageLayoutsCloud[page] = order.slice();
            try {
                if (typeof db !== 'undefined' && db) {
                    const payload = {};
                    payload[page] = order;
                    payload.updatedAt = new Date().toISOString();
                    db.collection('settings').doc('pageLayouts').set(payload, { merge: true }).catch(function() {});
                }
            } catch (_) {}
        }

        function collectLayoutBlocks(root) {
            const list = [];
            Array.prototype.forEach.call(root.children, function(ch) {
                if (!ch.getAttribute) return;
                if (ch.getAttribute('data-layout-fixed') === '1') return;
                const id = ch.getAttribute('data-layout-block');
                if (id) list.push({ id: id, el: ch });
            });
            return list;
        }

        window.applyPageLayout = function(page) {
            page = (page || currentLayoutPageId() || 'home').toLowerCase();
            const root = layoutContainer(page);
            if (!root) return;

            // Hero / sabitler her zaman EN ÜSTE
            const fixedNodes = [];
            Array.prototype.forEach.call(root.children, function(ch) {
                if (!ch.getAttribute) return;
                if (ch.getAttribute('data-layout-fixed') === '1' || (ch.classList && ch.classList.contains('home-hero')) || ch.id === 'homeHeroBanner') {
                    ch.setAttribute('data-layout-fixed', '1');
                    // asla layout-block olmasın
                    ch.removeAttribute('data-layout-block');
                    fixedNodes.push(ch);
                }
            });

            ensureLayoutBlocks(root, page);
            const blocks = collectLayoutBlocks(root);
            const byId = {};
            blocks.forEach(function(b) { byId[b.id] = b.el; });

            let order = getLayoutOrder(page).filter(function(id) { return !!byId[id]; });
            blocks.forEach(function(b) {
                if (order.indexOf(b.id) < 0) order.push(b.id);
            });

            // DOM: önce sabitler, sonra sıra
            fixedNodes.forEach(function(ch) { root.appendChild(ch); });
            order.forEach(function(id) {
                if (byId[id]) root.appendChild(byId[id]);
            });
            // order'ı local+cloud'a yazma her apply'da şişmesin; sadece move'da kaydet
            // ama ilk keşfedilen eksik id'leri de kalıcı yap
            if (order.length) {
                try { localStorage.setItem('yuvam_layout_' + page, JSON.stringify(order)); } catch (_) {}
            }

            blocks.forEach(function(b) {
                const el = b.el;
                let bar = null;
                for (let i = 0; i < el.children.length; i++) {
                    if (el.children[i].classList && el.children[i].classList.contains('layout-edit-bar')) {
                        bar = el.children[i];
                        break;
                    }
                }
                if (layoutEditPage === page) {
                    if (!bar) {
                        bar = document.createElement('div');
                        bar.className = 'layout-edit-bar';
                        bar.innerHTML = '<span class="layout-edit-label">Taşı</span>' +
                            '<button type="button" class="layout-btn" data-dir="up">↑</button>' +
                            '<button type="button" class="layout-btn" data-dir="down">↓</button>';
                        el.insertBefore(bar, el.firstChild);
                        bar.addEventListener('click', function(ev) {
                            ev.preventDefault();
                            ev.stopPropagation();
                            const btn = ev.target.closest('[data-dir]');
                            if (!btn) return;
                            moveLayoutBlock(page, b.id, btn.getAttribute('data-dir'));
                        });
                    }
                    bar.style.display = 'flex';
                    el.classList.add('layout-edit-on');
                    const pos = window.getComputedStyle(el).position;
                    if (!pos || pos === 'static') el.style.position = 'relative';
                } else {
                    if (bar) bar.style.display = 'none';
                    el.classList.remove('layout-edit-on');
                }
            });
        };

        function moveLayoutBlock(page, id, dir) {
            const root = layoutContainer(page);
            if (!root) return;
            ensureLayoutBlocks(root, page);
            const blocks = collectLayoutBlocks(root);
            let order = getLayoutOrder(page).filter(function(x) {
                return blocks.some(function(b) { return b.id === x; });
            });
            blocks.forEach(function(b) {
                if (order.indexOf(b.id) < 0) order.push(b.id);
            });
            const i = order.indexOf(id);
            if (i < 0) return;
            const j = dir === 'up' ? i - 1 : i + 1;
            if (j < 0 || j >= order.length) return;
            const t = order[i];
            order[i] = order[j];
            order[j] = t;
            saveLayoutOrder(page, order);
            applyPageLayout(page);
            if (typeof showToast === 'function') showToast('Sıra kaydedildi (cihaz + bulut)', 'success');
        }


        // Duygu: açık/koyu + ocean/warm/forest döngüsü
        const USER_THEME_CYCLE = [
            { theme: 'light', palette: 'ocean', icon: '🌊', label: 'Ocean · Açık' },
            { theme: 'dark', palette: 'ocean', icon: '🌊', label: 'Ocean · Koyu' },
            { theme: 'light', palette: 'warm', icon: '🏠', label: 'Warm · Açık' },
            { theme: 'dark', palette: 'warm', icon: '🏠', label: 'Warm · Koyu' },
            { theme: 'light', palette: 'forest', icon: '🌲', label: 'Forest · Açık' },
            { theme: 'dark', palette: 'forest', icon: '🌲', label: 'Forest · Koyu' }
        ];

        function currentUserThemeIndex() {
            const t = (typeof appTheme !== 'undefined' && appTheme === 'dark') ? 'dark' : 'light';
            const p = (typeof themePalette !== 'undefined' && themePalette) ? themePalette : 'ocean';
            for (let i = 0; i < USER_THEME_CYCLE.length; i++) {
                if (USER_THEME_CYCLE[i].theme === t && USER_THEME_CYCLE[i].palette === p) return i;
            }
            return 0;
        }

        window.toggleUserTheme = function() {
            try {
                const i = currentUserThemeIndex();
                const next = USER_THEME_CYCLE[(i + 1) % USER_THEME_CYCLE.length];
                if (typeof setThemePalette === 'function') setThemePalette(next.palette);
                if (typeof setAppTheme === 'function') setAppTheme(next.theme);
                const icon = document.getElementById('userThemeBtnIcon');
                if (icon) icon.textContent = next.icon;
                if (typeof showToast === 'function') showToast(next.label, 'info');
            } catch (e) { console.warn(e); }
        };

        window.updateUserThemeBtn = function() {
            const btn = document.getElementById('userThemeBtn');
            if (!btn) return;
            const show = currentUser && typeof isAdmin === 'function' && !isAdmin();
            btn.classList.toggle('hidden', !show);
            const icon = document.getElementById('userThemeBtnIcon');
            if (icon) {
                const cur = USER_THEME_CYCLE[currentUserThemeIndex()];
                icon.textContent = cur ? cur.icon : '🌊';
            }
        };

        window.updateAdminLayoutButtons = function() {
            const admin = typeof isAdmin === 'function' && isAdmin();
            ['layoutEditBtn', 'homeLayoutEditBtn'].forEach(function(id) {
                const b = document.getElementById(id);
                if (!b) return;
                if (admin) b.classList.remove('hidden');
                else {
                    b.classList.add('hidden');
                    if (layoutEditPage) layoutEditPage = null;
                }
            });
            try { if (typeof updateUserThemeBtn === 'function') updateUserThemeBtn(); } catch (_) {}
        };

        window.toggleLayoutEdit = function(page) {
            try {
                if (typeof isAdmin === 'function' && !isAdmin()) {
                    if (typeof showToast === 'function') showToast('Sayfa düzeni sadece admin için', 'error');
                    return;
                }
                page = (page || currentLayoutPageId() || 'home').toLowerCase();
                layoutEditPage = (layoutEditPage === page) ? null : page;
                applyPageLayout(page);
                const on = layoutEditPage === page;
                if (typeof showToast === 'function') {
                    showToast(on ? 'Düzen açık — ↑ ↓ ile taşıyın (kalıcı kaydedilir)' : 'Düzen kapandı', 'info');
                }
                const btn = document.getElementById('layoutEditBtn');
                if (btn) {
                    btn.classList.toggle('ring-2', on);
                    btn.classList.toggle('ring-indigo-400', on);
                    btn.textContent = on ? '✓ Düzen' : '📐 Düzen';
                }
            } catch (err) {
                console.error(err);
                alert('Düzen hatası: ' + (err.message || err));
            }
        };

        window.toggleLayoutEditCurrent = function() {
            toggleLayoutEdit(currentLayoutPageId());
        };

        window.applyDashboardCards = function() {
            const dc = dashboardCards || {};
            document.querySelectorAll('[data-dash-card]').forEach(function(el) {
                const k = el.getAttribute('data-dash-card');
                const on = dc[k] !== false;
                el.classList.toggle('hidden', !on);
            });
            document.querySelectorAll('[data-home-card]').forEach(function(el) {
                const k = el.getAttribute('data-home-card');
                const on = dc[k] !== false;
                el.classList.toggle('hidden', !on);
            });
            DASH_CARD_KEYS.forEach(function(k) {
                const cb = document.getElementById('cardVis_' + k);
                if (cb) cb.checked = dc[k] !== false;
            });
        };

        window.saveDashboardCards = async function() {
            if (!isAdmin()) { showToast('Sadece admin', 'error'); return; }
            const next = Object.assign({}, dashboardCards);
            DASH_CARD_KEYS.forEach(function(k) {
                const cb = document.getElementById('cardVis_' + k);
                if (cb) next[k] = !!cb.checked;
            });
            dashboardCards = next;
            try {
                await db.collection('settings').doc('uiPrefs').set({ dashboardCards: next }, { merge: true });
                applyDashboardCards();
                showToast('Kart görünürlüğü kaydedildi', 'success');
            } catch (err) {
                showToast(friendlyFirebaseError(err), 'error');
            }
        };

        // Modal Yönetimi
        window.openExpenseModal = () => {
            const editId = document.getElementById('editId').value;
            if (!editId) {
                resetForm();
            }
            document.getElementById('expenseModal').classList.remove('hidden');
            document.getElementById('expenseModal').classList.add('flex');
        };
        window.closeExpenseModal = () => {
            document.getElementById('expenseModal').classList.add('hidden');
            document.getElementById('expenseModal').classList.remove('flex');
        };
        function getAutoCardDueDate() {
            const p = (typeof getCurrentStatementPeriod === 'function') ? getCurrentStatementPeriod() : null;
            if (p && p.endDate) return formatYMD(p.endDate);
            // yedek: ayın 28'i
            const d = new Date();
            const end = new Date(d.getFullYear(), d.getMonth(), 28);
            if (d.getDate() > 28) end.setMonth(end.getMonth() + 1);
            return formatYMD(end);
        }

        window.openCardDebtModal = (person) => {
            const modal = document.getElementById('cardDebtModal');
            if (!modal) {
                alert('Borç penceresi yüklenemedi. Ctrl+F5 ile yenileyin.');
                return;
            }
            const key = (person === 'bekir' || person === 'Bekir') ? 'bekir'
                : (person === 'duygu' || person === 'Duygu') ? 'duygu' : '';
            const sel = document.getElementById('cardDebtPerson');
            if (sel && key) sel.value = key;
            else if (sel && !sel.value) sel.value = 'bekir';

            const who = (sel && sel.value) ? sel.value : 'bekir';
            const title = document.getElementById('cardDebtModalTitle');
            if (title) title.innerText = (who === 'bekir' ? 'Bekir' : 'Duygu') + ' — Kart borcu';

            const amt = document.getElementById('cardDebtAmount');
            if (amt) amt.value = '';

            const due = getAutoCardDueDate();
            const hint = document.getElementById('cardDebtDueHint');
            if (hint) {
                const p = getCurrentStatementPeriod();
                hint.textContent = 'Son ödeme: ' + formatDateTR(due) + (p && p.label ? ' · Dönem: ' + p.label : '');
            }

            modal.classList.remove('hidden');
            modal.classList.add('flex');
        };
        window.closeCardDebtModal = () => {
            const modal = document.getElementById('cardDebtModal');
            if (!modal) return;
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        };

        function resetForm() {
            document.getElementById('editId').value = '';
            document.getElementById('amount').value = '';
            document.getElementById('installmentCount').value = '1';
            document.getElementById('installmentCount').disabled = false;
            const rec = document.getElementById('isRecurring');
            if (rec) rec.checked = false;
            const rmw = document.getElementById('recurringMonthsWrap');
            if (rmw) rmw.classList.add('hidden');
            const rms = document.getElementById('recurringMonths');
            if (rms) rms.value = '12';
            document.getElementById('person').value = 'Bekir';
            document.getElementById('description').value = '';
            document.getElementById('date').valueAsDate = new Date();
            document.getElementById('formTitle').innerText = "Harcama Kaydı";
            const vs = document.getElementById('vehicleSubtype');
            if (vs) vs.value = 'Yakıt';
            ['fuelKm','fuelLiters','fuelPricePerLt'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
            if (typeof onCategoryChange === 'function') onCategoryChange();
        }

        function updateCategorySelects() {
            const select = document.getElementById('category');
            const filterSelect = document.getElementById('filterCategory');
            if(select) {
                select.innerHTML = categories.map(c => `<option value="${c}">${c}</option>`).join('');
            }
            if(filterSelect) {
                filterSelect.innerHTML = `<option value="Tümü">Tümü</option>` + categories.map(c => `<option value="${c}">${c}</option>`).join('');
            }
        }

        function updatePaymentSelects() {
            const select = document.getElementById('paymentType');
            const filterSelect = document.getElementById('filterPayment');
            if(select) {
                select.innerHTML = paymentTypes.map(p => `<option value="${p}">${p}</option>`).join('');
            }
            if(filterSelect) {
                filterSelect.innerHTML = `<option value="Tümü">Tümü</option>` + paymentTypes.map(p => `<option value="${p}">${p}</option>`).join('');
            }
        }

        // Realtime Sync (Firebase)
        function initRealtimeSync() {
            if (syncInitialized) return;
            syncInitialized = true;
            loadDeletedExpenses();

            db.collection("expenses").onSnapshot(snap => {
                expenses = snap.docs.map(function(d) {
                    const row = Object.assign({ id: d.id }, d.data());
                    if (row.billSubtype === 'Platform') row.billSubtype = 'Abonelik';
                    return row;
                });
                scheduleRenderApp();
            });
            db.collection("notes").onSnapshot(snap => {
                notes = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                renderNotesList();
            });
            db.collection("settings").doc("bekirDebt").onSnapshot(d => {
                if (d.exists) bekirDebt = d.data();
                renderCardDebtUI('bekir');
                renderBudgetInfo();
            });
            db.collection("settings").doc("duyguDebt").onSnapshot(d => {
                if (d.exists) duyguDebt = d.data();
                renderCardDebtUI('duygu');
                renderBudgetInfo();
            });
            db.collection("settings").doc("categories").onSnapshot(d => {
                if (d.exists && d.data() && Array.isArray(d.data().list)) {
                    categories = d.data().list.map(c => c === 'Ulaşım' ? 'Araç' : c);
                    categories = [...new Set(categories)];
                    if (!categories.includes('Araç')) categories.splice(1, 0, 'Araç');
                }
                updateCategorySelects();
                renderCategoriesList();
            }, err => console.error("Kategori yükleme hatası:", err));
            db.collection("settings").doc("categorySubtypes").onSnapshot(d => {
                if (d.exists && d.data() && d.data().map && typeof d.data().map === 'object') {
                    categorySubtypes = Object.assign({}, DEFAULT_CATEGORY_SUBTYPES, d.data().map);
                } else if (d.exists && d.data()) {
                    // düz map dokümanı
                    const raw = d.data();
                    const map = raw.map || raw;
                    if (map && typeof map === 'object' && !Array.isArray(map)) {
                        categorySubtypes = Object.assign({}, DEFAULT_CATEGORY_SUBTYPES, map);
                    }
                }
                // Platform → Abonelik
                Object.keys(categorySubtypes || {}).forEach(function(cat) {
                    if (!Array.isArray(categorySubtypes[cat])) return;
                    categorySubtypes[cat] = categorySubtypes[cat].map(function(s) {
                        return s === 'Platform' ? 'Abonelik' : s;
                    });
                    categorySubtypes[cat] = [...new Set(categorySubtypes[cat])];
                });
                if (!categorySubtypes['Faturalar']) categorySubtypes['Faturalar'] = DEFAULT_CATEGORY_SUBTYPES['Faturalar'].slice();
                if (categorySubtypes['Faturalar'].indexOf('Abonelik') < 0) categorySubtypes['Faturalar'].push('Abonelik');
                updateCategorySelects();
                if (typeof fillSubtypeSelects === 'function') fillSubtypeSelects();
                renderCategoriesList();
            }, err => console.warn('categorySubtypes:', err));
            db.collection("settings").doc("periodConfig").onSnapshot(d => {
                if (d.exists && d.data()) {
                    const p = d.data();
                    periodConfig = {
                        startDay: Number(p.startDay) || 29,
                        endDay: Number(p.endDay) || 28
                    };
                    applyPeriodConfigToForm();
                    scheduleRenderApp();
                }
            }, err => console.warn('periodConfig', err));
            db.collection("settings").doc("budgetTarget").onSnapshot(d => {
                if (d.exists && d.data()) {
                    monthlyBudgetTarget = Number(d.data().amount) || 0;
                    const inp = document.getElementById('budgetTargetInput');
                    if (inp && document.activeElement !== inp) inp.value = monthlyBudgetTarget > 0 ? String(monthlyBudgetTarget) : '';
                } else {
                    monthlyBudgetTarget = 0;
                }
                if (typeof renderBudgetInfo === 'function') renderBudgetInfo();
            }, err => console.warn('budgetTarget', err));

            function refreshFamilyViews() {
                try {
                    if (typeof refreshAppNotifications === 'function') refreshAppNotifications();
                    if (typeof updateTaskNavBadges === 'function') updateTaskNavBadges();
                    if (typeof renderTabBar === 'function' && currentUser) renderTabBar();
                    const home = document.getElementById('tabContentHome');
                    if (home && !home.classList.contains('hidden') && typeof renderHomeTab === 'function') renderHomeTab();
                    const cal = document.getElementById('tabContentCalendar');
                    if (cal && !cal.classList.contains('hidden') && typeof renderCalendarTab === 'function') renderCalendarTab();
                    const tk = document.getElementById('tabContentTasks');
                    if (tk && !tk.classList.contains('hidden') && typeof renderTasksTab === 'function') renderTasksTab();
                    const sh = document.getElementById('tabContentShopping');
                    if (sh && !sh.classList.contains('hidden') && typeof renderShoppingTab === 'function') renderShoppingTab();
                } catch (_) {}
            }
            db.collection('familyCalendar').onSnapshot(function(snap) {
                familyCalendar = snap.docs.map(function(d) { return Object.assign({ id: d.id }, d.data()); });
                refreshFamilyViews();
            }, function(e) { console.warn('familyCalendar', e); });
            // Önce local, sonra settings/goldHoldings
            try {
                goldHoldings = loadGoldHoldingsLocal();
                if (typeof renderGoldHoldings === 'function') renderGoldHoldings();
            } catch (_) {}
            db.collection('settings').doc('goldHoldings').onSnapshot(function(d) {
                if (d.exists && d.data() && Array.isArray(d.data().list)) {
                    goldHoldings = d.data().list;
                    saveGoldHoldingsLocal(goldHoldings);
                    if (typeof renderGoldHoldings === 'function') renderGoldHoldings();
                }
            }, function(e) { console.warn('goldHoldings settings', e); });
            db.collection('familyTasks').onSnapshot(function(snap) {
                familyTasks = snap.docs.map(function(d) { return Object.assign({ id: d.id }, d.data()); });
                refreshFamilyViews();
            }, function(e) { console.warn('familyTasks', e); });
            db.collection('familyShopping').onSnapshot(function(snap) {
                familyShopping = snap.docs.map(function(d) { return Object.assign({ id: d.id }, d.data()); });
                refreshFamilyViews();
            }, function(e) { console.warn('familyShopping', e); });
            db.collection("settings").doc("uiPrefs").onSnapshot(d => {
                if (d.exists && d.data()) {
                    const u = d.data();
                    // Tema kullanıcıya özel localStorage'da; paylaşılan uiPrefs temayı dayatmaz
                    if (u.dashboardCards && typeof u.dashboardCards === 'object') {
                        dashboardCards = Object.assign(dashboardCards, u.dashboardCards);
                        applyDashboardCards();
                    }
                }
            }, err => console.warn('uiPrefs', err));
            db.collection("settings").doc("apiKeys").onSnapshot(d => {
                if (d.exists && d.data()) {
                    const k = d.data();
                    // openrouter öncelikli; eski gemini alanı yok sayılır
                    if (k.openrouter) openrouterApiKey = String(k.openrouter).trim();
                    else if (k.gemini) openrouterApiKey = String(k.gemini).trim(); // yanlışlıkla eski alan
                }
            }, err => console.warn('apiKeys:', err));
            db.collection("settings").doc("tabs").onSnapshot(d => {
                if (d.exists && d.data()) {
                    const data = d.data();
                    removedTabIds = Array.isArray(data.removed) ? data.removed : [];
                    if (Array.isArray(data.list) && data.list.length) {
                        tabsConfig = mergeTabsConfig(data.list, removedTabIds);
                    } else {
                        tabsConfig = mergeTabsConfig([], removedTabIds);
                    }
                } else {
                    removedTabIds = [];
                    tabsConfig = DEFAULT_TABS.map(t => ({ ...t }));
                }
                if (currentUser) applyRoleAndTabs();
                renderTabsList();
            }, err => console.error("Sekme yükleme hatası:", err));
            db.collection("settings").doc("paymentTypes").onSnapshot(d => {
                if (d.exists) paymentTypes = d.data().list;
                updatePaymentSelects();
            });
            db.collection("cardStatements").onSnapshot(snap => {
                cardStatements = snap.docs.map(d => ({ ...d.data(), id: d.id }));
                const statsTab = document.getElementById('tabContentStats');
                if (statsTab && !statsTab.classList.contains('hidden')) {
                    renderCardStatements('bekir');
                    renderCardStatements('duygu');
                }
            }, err => console.error("Cardstatements yüklemesinde hata:", err));
            db.collection("ibans").onSnapshot(snap => {
                ibans = snap.docs.map(d => ({ ...d.data(), id: d.id }));
                renderIbans();
            }, err => console.error("IBAN yüklemesinde hata:", err));

            // Aktivite logu (index yoksa orderBy hata verir → yedek yol)
            const loadActivity = (snap) => {
                activityLog = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                activityLog.sort((a, b) => String(b.at || '').localeCompare(String(a.at || '')));
                const panel = document.getElementById('activityPanel');
                if (panel && !panel.classList.contains('hidden')) renderActivityTable();
            };
            try {
                db.collection("activityLog").orderBy("at", "desc").limit(500).onSnapshot(
                    loadActivity,
                    err => {
                        console.warn("activityLog orderBy:", err.message);
                        db.collection("activityLog").limit(500).onSnapshot(loadActivity, e2 => console.error(e2));
                    }
                );
            } catch (e) {
                db.collection("activityLog").limit(500).onSnapshot(loadActivity, e2 => console.error(e2));
            }

            updateCategorySelects();
            updatePaymentSelects();
            renderCategoriesList();
        }

        // Bütçe Hesaplama
        function isCreditPayment(pt) {
            const s = String(pt || '').toLocaleLowerCase('tr-TR');
            return s.indexOf('kredi') >= 0 || s.indexOf('kart') >= 0;
        }

        function isCashPayment(pt) {
            const s = String(pt || '').toLocaleLowerCase('tr-TR');
            return s.indexOf('nakit') >= 0 || s === 'cash';
        }

        function sumByPay(list, pred) {
            return list.filter(pred).reduce(function(s, e) { return s + (Number(e.displayAmount) || 0); }, 0);
        }

        function fmtShortTL(n) {
            return (Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: 0 }) + ' TL';
        }

        function renderBudgetInfo() {
            const period = getCurrentPeriod();
            const periodInfo = getCurrentStatementPeriod();

            const processedExpenses = getProcessedExpenses().filter(e => e.effectiveMonth === period);
            const totalSpent = processedExpenses.reduce((sum, e) => sum + e.displayAmount, 0);

            const elTotal = document.getElementById('totalExpense');
            if (elTotal) elTotal.innerText = totalSpent.toLocaleString('tr-TR', {style:'currency', currency:'TRY'});

            const bekirList = processedExpenses.filter(e => e.person === 'Bekir');
            const duyguList = processedExpenses.filter(e => e.person === 'Duygu');
            const bekirSum = bekirList.reduce((s, e) => s + e.displayAmount, 0);
            const duyguSum = duyguList.reduce((s, e) => s + e.displayAmount, 0);
            const elBekir = document.getElementById('bekirExpense');
            const elDuygu = document.getElementById('duyguExpense');
            if (elBekir) elBekir.innerText = bekirSum.toLocaleString('tr-TR', {style:'currency', currency:'TRY'});
            if (elDuygu) elDuygu.innerText = duyguSum.toLocaleString('tr-TR', {style:'currency', currency:'TRY'});

            // Nakit / Kredi kartı kırılımı
            const setPair = function(cashId, cardId, list) {
                const cash = sumByPay(list, function(e) { return isCashPayment(e.paymentType); });
                const card = sumByPay(list, function(e) { return isCreditPayment(e.paymentType); });
                // diğer ödeme tipleri varsa kalanı kart+nakit dışında bırak; gösterimde sadece nakit+kk
                const cEl = document.getElementById(cashId);
                const kEl = document.getElementById(cardId);
                if (cEl) cEl.textContent = fmtShortTL(cash);
                if (kEl) kEl.textContent = fmtShortTL(card);
            };
            setPair('totalCashAmt', 'totalCardAmt', processedExpenses);
            setPair('bekirCashAmt', 'bekirCardAmt', bekirList);
            setPair('duyguCashAmt', 'duyguCardAmt', duyguList);

            const totalActiveDebt = (!bekirDebt.paid ? bekirDebt.amount : 0) + (!duyguDebt.paid ? duyguDebt.amount : 0);
            const elDebt = document.getElementById('totalCardDebtDisplay');
            if (elDebt) elDebt.innerText = totalActiveDebt.toLocaleString('tr-TR', {style:'currency', currency:'TRY'});

            const badge = document.getElementById('activePeriodBadge');
            if (badge && periodInfo) badge.textContent = 'Aktif dönem: ' + periodInfo.label;
            renderBudgetTargetUI(totalSpent, periodInfo);
            if (typeof refreshAppNotifications === 'function') refreshAppNotifications();
        }

        function renderBudgetTargetUI(totalSpent, periodInfo) {
            const card = document.getElementById('budgetTargetCard');
            const label = document.getElementById('budgetTargetLabel');
            const pctEl = document.getElementById('budgetTargetPct');
            const bar = document.getElementById('budgetTargetBar');
            const detail = document.getElementById('budgetTargetDetail');
            const target = Number(monthlyBudgetTarget) || 0;
            if (!card) return;
            if (!(target > 0)) {
                if (label) label.textContent = 'Hedef belirlenmedi';
                if (pctEl) pctEl.textContent = '—';
                if (bar) { bar.style.width = '0%'; bar.className = 'h-full rounded-full transition-all duration-700 bg-slate-300'; }
                if (detail) detail.textContent = 'Ayarlar → Bütçe hedefi ile dönem limiti koyun';
                return;
            }
            const spent = Number(totalSpent) || 0;
            const pct = Math.min(999, (spent / target) * 100);
            const remain = target - spent;
            if (label) label.textContent = 'Hedef ' + target.toLocaleString('tr-TR') + ' TL';
            if (pctEl) {
                pctEl.textContent = '%' + pct.toFixed(0);
                pctEl.className = 'text-lg font-black ' + (pct >= 100 ? 'text-rose-600' : pct >= 80 ? 'text-amber-600' : 'text-emerald-600');
            }
            if (bar) {
                bar.style.width = Math.min(100, pct) + '%';
                bar.className = 'h-full rounded-full transition-all duration-700 ' + (pct >= 100 ? 'bg-rose-500' : pct >= 80 ? 'bg-amber-500' : 'bg-emerald-500');
            }
            if (detail) {
                const pl = periodInfo && periodInfo.label ? periodInfo.label + ' · ' : '';
                detail.textContent = pl + 'Harcama ' + Math.round(spent).toLocaleString('tr-TR') + ' TL · ' +
                    (remain >= 0 ? ('kalan ' + Math.round(remain).toLocaleString('tr-TR') + ' TL') : ('aşım ' + Math.round(-remain).toLocaleString('tr-TR') + ' TL'));
            }
        }

        window.saveBudgetTarget = async function() {
            if (!isAdmin()) { showToast('Sadece admin', 'error'); return; }
            const raw = (document.getElementById('budgetTargetInput') || {}).value;
            const n = parseFloat(String(raw).replace(',', '.'));
            if (raw !== '' && raw != null && (isNaN(n) || n < 0 || n > 9999999)) {
                showToast('Geçerli bir hedef girin (0 = kapalı)', 'error');
                return;
            }
            const val = (!raw && raw !== 0) || isNaN(n) ? 0 : Math.round(n);
            try {
                await db.collection('settings').doc('budgetTarget').set({ amount: val, updatedAt: new Date().toISOString() }, { merge: true });
                monthlyBudgetTarget = val;
                showToast(val > 0 ? ('Hedef: ' + val.toLocaleString('tr-TR') + ' TL') : 'Bütçe hedefi kapatıldı', 'success');
                if (typeof renderBudgetInfo === 'function') renderBudgetInfo();
                logActivity('Diğer', 'Bütçe hedefi güncellendi', val > 0 ? (val + ' TL') : 'kapalı');
            } catch (err) {
                showToast(friendlyFirebaseError(err), 'error');
            }
        };

        // Kart Borcu İşlemleri
        window.setCardDebt = (person) => openCardDebtModal(person);
        window.handleCardDebtSubmit = async (e) => {
            e.preventDefault();
            try {
                const person = (document.getElementById('cardDebtPerson') || {}).value || 'bekir';
                const key = person === 'bekir' || person === 'Bekir' ? 'bekir' : 'duygu';
                const amountCheck = validateExpenseAmount((document.getElementById('cardDebtAmount') || {}).value);
                if (!amountCheck.ok) {
                    showToast(amountCheck.message, 'error');
                    return;
                }
                const amount = amountCheck.amount;
                const dueDate = getAutoCardDueDate();
                const debt = {
                    amount: amount,
                    paid: false,
                    dueDate: dueDate,
                    lastStatementId: null,
                    lastStatementMonth: null
                };
                if (key === 'bekir') {
                    bekirDebt = debt;
                    await db.collection('settings').doc('bekirDebt').set(debt);
                } else {
                    duyguDebt = debt;
                    await db.collection('settings').doc('duyguDebt').set(debt);
                }
                closeCardDebtModal();
                renderCardDebtUI(key);
                if (typeof renderBudgetInfo === 'function') renderBudgetInfo();
                showToast((key === 'bekir' ? 'Bekir' : 'Duygu') + ' kart borcu kaydedildi', 'success');
                logActivity('Diğer', 'Kart borcu girildi', (key === 'bekir' ? 'Bekir' : 'Duygu') + ' · ' + amount + ' TL');
            } catch (err) {
                console.error(err);
                showToast(friendlyFirebaseError(err), 'error');
            }
        };

        async function deleteCardStatementsOnUnpay(key, debt) {
            const ids = new Set();
            if (debt && debt.lastStatementId) ids.add(debt.lastStatementId);

            const list = (cardStatements || []).filter(s => String(s.person || '').toLowerCase() === key);
            // Aynı dönemdeki (lastStatementMonth) kayıtlar
            if (debt && debt.lastStatementMonth) {
                list.filter(s => s.month === debt.lastStatementMonth).forEach(s => { if (s.id) ids.add(s.id); });
            }
            // En son ödeme gününe ait tüm kayıtlar (eski hatadan kalanlar)
            if (list.length) {
                const sorted = list.slice().sort((a, b) =>
                    String(b.createdAt || b.paidDate || b.month || '').localeCompare(String(a.createdAt || a.paidDate || a.month || ''))
                );
                const latest = sorted[0];
                const day = String(latest.paidDate || (latest.createdAt || '')).slice(0, 10);
                sorted.forEach(s => {
                    const d = String(s.paidDate || (s.createdAt || '')).slice(0, 10);
                    if (day && d === day && s.id) ids.add(s.id);
                    // lastStatementId yoksa en azından en yeni tek kaydı sil
                    if (!debt || !debt.lastStatementId) {
                        if (s === latest && s.id) ids.add(s.id);
                    }
                });
            }

            let n = 0;
            for (const id of ids) {
                try {
                    await db.collection('cardStatements').doc(id).delete();
                    n++;
                } catch (e) {
                    console.warn('ekstre silinemedi', id, e);
                }
            }
            return n;
        }

        window.toggleCardDebt = async (person) => {
            const key = person === 'bekir' || person === 'Bekir' ? 'bekir' : 'duygu';
            let debt = key === 'bekir' ? bekirDebt : duyguDebt;
            if (!debt || typeof debt !== 'object') debt = { amount: 0, paid: false, dueDate: '' };

            try {
                if (!debt.paid) {
                    if (!(debt.amount > 0)) {
                        showToast('Önce borç tutarı girin', 'error');
                        return;
                    }
                    if (!confirm((key === 'bekir' ? 'Bekir' : 'Duygu') + ' kart borcu ödendi olarak işaretlensin mi? Ekstre kaydı oluşturulacak.')) return;

                    let statementMonth;
                    if (debt.dueDate) {
                        statementMonth = getPeriodKeyForDateStr(debt.dueDate);
                    } else {
                        statementMonth = getCurrentPeriod();
                    }
                    if (!statementMonth) statementMonth = new Date().toISOString().slice(0, 7);

                    const docId = key + '_' + statementMonth + '_' + Date.now();
                    const statementData = {
                        person: key,
                        month: statementMonth,
                        amount: Number(debt.amount) || 0,
                        dueDate: debt.dueDate || '',
                        paidDate: new Date().toISOString().split('T')[0],
                        status: 'paid',
                        createdAt: new Date().toISOString()
                    };

                    await db.collection('cardStatements').doc(docId).set(statementData);
                    debt.paid = true;
                    debt.lastStatementId = docId;
                    debt.lastStatementMonth = statementMonth;
                    await db.collection('settings').doc(key + 'Debt').set(debt);
                    if (key === 'bekir') bekirDebt = debt; else duyguDebt = debt;
                    showToast('Borç ödendi · ekstre kaydı eklendi', 'success');
                    logActivity('Diğer', 'Kart borcu ödendi', (key === 'bekir' ? 'Bekir' : 'Duygu') + ' · ' + statementData.amount + ' TL · ' + statementMonth);
                } else {
                    if (!confirm((key === 'bekir' ? 'Bekir' : 'Duygu') + ' tekrar borçlu yapılsın mı? İlgili ekstre kaydı silinecek.')) return;
                    const deleted = await deleteCardStatementsOnUnpay(key, debt);
                    debt.paid = false;
                    debt.lastStatementId = null;
                    debt.lastStatementMonth = null;
                    await db.collection('settings').doc(key + 'Debt').set(debt);
                    if (key === 'bekir') bekirDebt = debt; else duyguDebt = debt;
                    showToast(deleted ? ('Borçlu yapıldı · ' + deleted + ' ekstre silindi') : 'Borçlu olarak işaretlendi', 'info');
                    logActivity('Diğer', 'Kart borcu geri alındı', (key === 'bekir' ? 'Bekir' : 'Duygu') + (deleted ? (' · ' + deleted + ' ekstre silindi') : ''));
                }
                renderCardDebtUI(key);
                if (typeof renderCardStatements === 'function') {
                    renderCardStatements('bekir');
                    renderCardStatements('duygu');
                }
                if (typeof renderBudgetInfo === 'function') renderBudgetInfo();
            } catch (err) {
                console.error(err);
                showToast('Kart borcu güncellenemedi: ' + (err.message || err), 'error');
                alert('Kart borcu / ekstre kaydı hatası: ' + (err.message || err));
            }
        };

        /** Borç ödenmemişken kalan hatalı ekstreleri temizle */
        window.cleanupOrphanCardStatements = async function(person) {
            const key = !person ? null : ((person === 'bekir' || person === 'Bekir') ? 'bekir' : 'duygu');
            const keys = key ? [key] : ['bekir', 'duygu'];
            const today = new Date().toISOString().slice(0, 10);
            let total = 0;
            for (const k of keys) {
                const debt = k === 'bekir' ? bekirDebt : duyguDebt;
                if (debt && debt.paid) continue;
                const list = (cardStatements || []).filter(s => String(s.person || '').toLowerCase() === k);
                const ids = new Set();
                if (debt && debt.lastStatementId) ids.add(debt.lastStatementId);
                // Bugün oluşmuş hatalı kayıtlar (önceki bug)
                list.forEach(s => {
                    const d = String(s.paidDate || s.createdAt || '').slice(0, 10);
                    if (d === today && s.id) ids.add(s.id);
                });
                // lastStatementId yoksa en yeni tek kayıt
                if (!ids.size && list.length) {
                    const sorted = list.slice().sort((a, b) =>
                        String(b.createdAt || b.paidDate || '').localeCompare(String(a.createdAt || a.paidDate || ''))
                    );
                    if (sorted[0] && sorted[0].id) ids.add(sorted[0].id);
                }
                for (const id of ids) {
                    try {
                        await db.collection('cardStatements').doc(id).delete();
                        total++;
                    } catch (e) { console.warn(e); }
                }
                if (debt) {
                    debt.lastStatementId = null;
                    debt.lastStatementMonth = null;
                    try { await db.collection('settings').doc(k + 'Debt').set(debt); } catch (_) {}
                }
            }
            renderCardStatements('bekir');
            renderCardStatements('duygu');
            if (total) showToast(total + ' hatalı ekstre silindi', 'success');
            return total;
        };

        window.updateCardDueDate = async (person, date) => {
            let debt = person === 'bekir' ? bekirDebt : duyguDebt;
            debt.dueDate = date;
            await db.collection("settings").doc(person + "Debt").set(debt);
        };

        function isActiveCardDebt(debt) {
            return debt && !debt.paid && Number(debt.amount) > 0;
        }

        function renderCardDebtUI(person) {
            const key = person === 'bekir' || person === 'Bekir' ? 'bekir' : 'duygu';
            const debt = key === 'bekir' ? bekirDebt : duyguDebt;
            const card = document.getElementById(key + 'DebtCard');
            const visible = isActiveCardDebt(debt);
            if (card) card.classList.toggle('hidden', !visible);

            const disp = document.getElementById(key + 'DebtDisplay');
            const dueDisp = document.getElementById(key + 'DueDateDisplay');
            if (disp) disp.innerText = (debt && debt.amount ? debt.amount : 0).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' });
            if (dueDisp) dueDisp.innerText = (debt && debt.dueDate) ? formatDateTR(debt.dueDate) : '-';

            const badge = document.getElementById(key + 'DebtStatusBadge');
            const btn = document.getElementById(key + 'DebtToggleBtn');
            if (badge && btn) {
                if (debt && debt.paid) {
                    badge.innerText = 'ÖDENDİ';
                    badge.className = 'inline-block mt-2 text-[10px] px-2.5 py-1 rounded-full font-bold uppercase bg-emerald-100 text-emerald-700';
                    btn.innerText = 'Borçlu Yap';
                    btn.className = 'text-[11px] font-bold px-3 py-2 rounded-xl shadow-sm transition bg-slate-100 text-slate-500';
                } else {
                    badge.innerText = 'ÖDENMEDİ';
                    badge.className = 'inline-block mt-2 text-[10px] px-2.5 py-1 rounded-full font-bold uppercase bg-rose-100 text-rose-700';
                    btn.innerText = 'Ödendi Yap';
                    btn.className = 'text-[11px] font-bold px-3 py-2 rounded-xl shadow-sm transition bg-rose-600 text-white';
                }
            }
            updateProgressBar(key, debt && debt.dueDate);
            if (typeof refreshAppNotifications === 'function') refreshAppNotifications();
        }

        function updateProgressBar(person, dueDateStr) {
            const bar = document.getElementById(person + 'ProgressBar');
            const percText = document.getElementById(person + 'ProgressPercentage');
            if (!bar || !percText) return;

            let period = null;
            try { period = getCurrentStatementPeriod(); } catch (_) {}
            const start = period && period.startDate ? period.startDate : null;
            let due = dueDateStr ? parseYMD(dueDateStr) : (period && period.endDate ? period.endDate : null);
            if (!due) {
                bar.style.width = '0%';
                percText.innerText = '0%';
                return;
            }
            const today = new Date();
            today.setHours(12, 0, 0, 0);
            const dueMid = new Date(due.getFullYear(), due.getMonth(), due.getDate(), 12, 0, 0);
            const startMid = start
                ? new Date(start.getFullYear(), start.getMonth(), start.getDate(), 12, 0, 0)
                : new Date(dueMid.getFullYear(), dueMid.getMonth(), dueMid.getDate() - 30, 12, 0, 0);

            const totalMs = Math.max(1, dueMid - startMid);
            const elapsedMs = today - startMid;
            let percentage = Math.round(Math.min(100, Math.max(0, (elapsedMs / totalMs) * 100)));
            const diffDays = Math.ceil((dueMid - today) / (1000 * 60 * 60 * 24));

            bar.style.width = percentage + '%';
            if (diffDays < 0) percText.innerText = 'Günü geçti';
            else if (diffDays === 0) percText.innerText = 'Bugün son gün';
            else percText.innerText = diffDays + ' gün';
            bar.className = 'h-full rounded-full transition-all duration-1000 ' + (diffDays <= 3 ? 'bg-rose-500' : 'bg-indigo-500');
        }

        // Harcama İşlemleri

        window.onRecurringToggle = function() {
            const chk = document.getElementById('isRecurring');
            const wrap = document.getElementById('recurringMonthsWrap');
            const inst = document.getElementById('installmentCount');
            const on = chk && chk.checked;
            if (wrap) wrap.classList.toggle('hidden', !on);
            if (inst) {
                inst.disabled = !!on;
                if (on) inst.value = '1';
            }
        };

        window.onCategoryChange = function() {
            const cat = document.getElementById('category');
            const wrap = document.getElementById('vehicleSubtypeWrap');
            const billWrap = document.getElementById('billSubtypeWrap');
            if (!cat) return;
            const isVehicle = cat.value === 'Araç' || cat.value === 'Ulaşım';
            const isBill = cat.value === 'Faturalar';
            if (wrap) {
                wrap.classList.toggle('hidden', !isVehicle);
                const sel = document.getElementById('vehicleSubtype');
                if (sel && isVehicle && !sel.value) sel.value = 'Yakıt';
            }
            if (billWrap) {
                billWrap.classList.toggle('hidden', !isBill);
                if (isBill && typeof fillSubtypeSelects === 'function') fillSubtypeSelects();
            }
            if (typeof onVehicleSubtypeChange === 'function') onVehicleSubtypeChange();
        };

        window.onVehicleSubtypeChange = function() {
            const wrap = document.getElementById('fuelDetailWrap');
            const sel = document.getElementById('vehicleSubtype');
            const cat = document.getElementById('category');
            if (!wrap) return;
            const isFuel = cat && (cat.value === 'Araç' || cat.value === 'Ulaşım') && sel && sel.value === 'Yakıt';
            wrap.classList.toggle('hidden', !isFuel);
        };

        let vehicleFuelChart = null, vehicleMaintChart = null, vehicleFuelConsChart = null, vehicleFuelCostChart = null, vehicleFuelLitersChart = null, vehicleFuelPriceChart = null;
        let vehicleSubTab = 'fuel'; // fuel | maint

        window.showVehicleSubTab = function(which) {
            vehicleSubTab = which === 'maint' ? 'maint' : 'fuel';
            const fuelPanel = document.getElementById('vehicleFuelPanel');
            const maintPanel = document.getElementById('vehicleMaintPanel');
            const fuelBtn = document.getElementById('vehicleTabFuelBtn');
            const maintBtn = document.getElementById('vehicleTabMaintBtn');
            if (fuelPanel) fuelPanel.classList.toggle('hidden', vehicleSubTab !== 'fuel');
            if (maintPanel) maintPanel.classList.toggle('hidden', vehicleSubTab !== 'maint');
            if (fuelBtn) {
                fuelBtn.classList.toggle('border-indigo-600', vehicleSubTab === 'fuel');
                fuelBtn.classList.toggle('border-slate-200', vehicleSubTab !== 'fuel');
            }
            if (maintBtn) {
                maintBtn.classList.toggle('border-indigo-600', vehicleSubTab === 'maint');
                maintBtn.classList.toggle('border-slate-200', vehicleSubTab !== 'maint');
            }
            renderVehicleTab();
        };

        function isVehicleExpense(e) {
            const cat = e.category || '';
            return cat === 'Araç' || cat === 'Ulaşım';
        }

        function vehicleKind(e) {
            const t = (e.vehicleSubtype || '').trim();
            if (t === 'Yakıt' || t === 'Yakit') return 'fuel';
            if (t === 'Vergi' || t === 'Bakım' || t === 'Bakim' || t === 'Vergi&Bakım') return 'maint';
            // Eski kayıtlarda subtype yoksa açıklamadan tahmin etme — genel araç
            return 'other';
        }

        window.renderVehicleTab = function() {
            const processed = getProcessedExpenses().filter(isVehicleExpense);
            const fuelItems = processed.filter(e => vehicleKind(e) === 'fuel');
            const maintItems = processed.filter(e => vehicleKind(e) === 'maint' || vehicleKind(e) === 'other');

            const fillList = (elId, items) => {
                const el = document.getElementById(elId);
                if (!el) return;
                if (!items.length) {
                    el.innerHTML = '<p class="text-sm text-slate-400 font-medium py-4 text-center">Kayıt yok</p>';
                    return;
                }
                const total = items.reduce((s, e) => s + (e.displayAmount || 0), 0);
                el.innerHTML = `
                    <p class="text-xs font-bold text-slate-500 mb-3">Toplam: <span class="text-rose-600 font-black">${total.toLocaleString('tr-TR')} TL</span> · ${items.length} kayıt</p>
                    <div class="space-y-2 max-h-64 overflow-y-auto">
                        ${items.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,40).map(e => `
                            <div class="flex justify-between gap-2 bg-slate-50 rounded-xl p-3 border border-slate-100">
                                <div class="min-w-0">
                                    <p class="text-sm font-bold text-slate-800 truncate">${escapeHtml(e.description || '-')}</p>
                                    <p class="text-[11px] text-slate-400 font-semibold">${escapeHtml(e.date||'')} · ${escapeHtml(e.person||'')} · ${escapeHtml(e.vehicleSubtype||'Araç')}</p>
                                    ${e.fuelNote ? '<p class="text-[11px] text-indigo-600 font-bold mt-1">' + escapeHtml(e.fuelNote) + '</p>' : ''}
                                    ${e.fuelKm || e.fuelLiters ? '<p class="text-[10px] text-slate-400 mt-0.5">' +
                                        (e.fuelKm ? escapeHtml(String(e.fuelKm)) + ' km' : '') +
                                        (e.fuelLiters ? ' · ' + escapeHtml(String(e.fuelLiters)) + ' L' : '') +
                                        (e.fuelPricePerLt ? ' · ' + escapeHtml(String(e.fuelPricePerLt)) + ' TL/L' : '') +
                                    '</p>' : ''}
                                </div>
                                <p class="text-sm font-black text-rose-600 shrink-0">${(e.displayAmount||0).toLocaleString('tr-TR')} TL</p>
                            </div>
                        `).join('')}
                    </div>`;
            };
            fillList('vehicleFuelList', fuelItems);
            fillList('vehicleMaintList', maintItems);

            // --- Yakıt özet kartları ---
            const withCons = fuelItems.filter(e => e.fuelKm > 0 && e.fuelLiters > 0);
            const consValues = withCons.map(e => (e.fuelLiters / e.fuelKm) * 100);
            const costValues = withCons.map(e => {
                if (e.fuelPricePerLt > 0) return (e.fuelLiters * e.fuelPricePerLt) / e.fuelKm;
                if (e.displayAmount > 0) return e.displayAmount / e.fuelKm;
                return null;
            }).filter(v => v != null && !isNaN(v));
            const totalFuelTl = fuelItems.reduce((s, e) => s + (e.displayAmount || 0), 0);
            const totalLiters = fuelItems.reduce((s, e) => s + (parseFloat(e.fuelLiters) || 0), 0);
            const totalKm = fuelItems.reduce((s, e) => s + (parseFloat(e.fuelKm) || 0), 0);
            const avgCons = consValues.length ? consValues.reduce((a, b) => a + b, 0) / consValues.length : null;
            const avgCost = costValues.length ? costValues.reduce((a, b) => a + b, 0) / costValues.length : null;

            const setTxt = (id, text) => {
                const el = document.getElementById(id);
                if (el) el.textContent = text;
            };
            setTxt('fuelStatTotal', totalFuelTl.toLocaleString('tr-TR') + ' TL');
            setTxt('fuelStatLiters', totalLiters > 0 ? totalLiters.toLocaleString('tr-TR', { maximumFractionDigits: 1 }) + ' L' : '—');
            setTxt('fuelStatKm', totalKm > 0 ? totalKm.toLocaleString('tr-TR', { maximumFractionDigits: 0 }) + ' km' : '—');
            setTxt('fuelStatCons', avgCons != null ? avgCons.toFixed(2) + ' L/100km' : '—');
            setTxt('fuelStatCost', avgCost != null ? avgCost.toFixed(2) + ' TL/km' : '—');

            // Aylık yardımcılar
            const monthKeys = [];
            const now = new Date();
            for (let i = 5; i >= 0; i--) {
                const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
                monthKeys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
            }
            const monthLabels = monthKeys.map(k => {
                const [y, m] = k.split('-').map(Number);
                const months = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
                return months[m - 1] + ' ' + y;
            });
            const monthlySum = (items, field) => monthKeys.map(k =>
                items.filter(e => String(e.date || '').startsWith(k))
                    .reduce((s, e) => s + (field === 'amount' ? (e.displayAmount || 0) : (parseFloat(e[field]) || 0)), 0)
            );

            const fuelSpend = monthlySum(fuelItems, 'amount');
            const fuelLitersM = monthlySum(fuelItems, 'fuelLiters');
            const maintSpend = monthlySum(maintItems.filter(e => vehicleKind(e) === 'maint'), 'amount');

            // Dolum bazlı (tarihe göre) tüketim / maliyet
            const sortedFuel = withCons.slice().sort((a, b) => String(a.date).localeCompare(String(b.date))).slice(-12);
            const fillLabels = sortedFuel.map(e => {
                const s = String(e.date || '').slice(0, 10);
                const parts = s.split('-');
                return parts.length === 3 ? (parts[2] + '.' + parts[1]) : s;
            });
            const fillCons = sortedFuel.map(e => +((e.fuelLiters / e.fuelKm) * 100).toFixed(2));
            const fillCost = sortedFuel.map(e => {
                if (e.fuelPricePerLt > 0) return +(((e.fuelLiters * e.fuelPricePerLt) / e.fuelKm).toFixed(2));
                return +((e.displayAmount / e.fuelKm).toFixed(2));
            });

            const mkBar = (canvasId, chartRefName, labels, data, color, label) => {
                const ctx = document.getElementById(canvasId);
                if (!ctx || typeof Chart === 'undefined') return null;
                if (window[chartRefName]) {
                    try { window[chartRefName].destroy(); } catch (_) {}
                }
                // use outer vars
                return new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels,
                        datasets: [{ label, data, backgroundColor: color, borderRadius: 8, maxBarThickness: 36 }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: { y: { beginAtZero: true } }
                    }
                });
            };
            const mkLine = (canvasId, labels, data, color, label) => {
                const ctx = document.getElementById(canvasId);
                if (!ctx || typeof Chart === 'undefined') return null;
                return new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels,
                        datasets: [{
                            label,
                            data,
                            borderColor: color,
                            backgroundColor: color + '22',
                            fill: true,
                            tension: 0.3,
                            pointRadius: 8, pointHoverRadius: 12, pointHitRadius: 28,
                            pointBackgroundColor: color
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: true, position: 'bottom' } },
                        scales: { y: { beginAtZero: true } }
                    }
                });
            };

            if (vehicleFuelChart) { try { vehicleFuelChart.destroy(); } catch (_) {} }
            if (vehicleFuelLitersChart) { try { vehicleFuelLitersChart.destroy(); } catch (_) {} }
            if (vehicleFuelConsChart) { try { vehicleFuelConsChart.destroy(); } catch (_) {} }
            if (vehicleFuelCostChart) { try { vehicleFuelCostChart.destroy(); } catch (_) {} }
            if (vehicleFuelPriceChart) { try { vehicleFuelPriceChart.destroy(); } catch (_) {} }
            if (vehicleMaintChart) { try { vehicleMaintChart.destroy(); } catch (_) {} }

            // Dolum bazlı litre fiyatı
            const fillPrice = sortedFuel.map(function(e) {
                const p = parseFloat(e.fuelPricePerLt);
                if (p > 0) return +p.toFixed(2);
                const lt = parseFloat(e.fuelLiters);
                if (lt > 0 && e.displayAmount > 0) return +(e.displayAmount / lt).toFixed(2);
                return null;
            });

            // 1) Aylık harcama (TL) + litre — iki çubuk; web yan yana, mobil yatay (aylar alt alta)
            const ctxF = document.getElementById('vehicleFuelChart');
            if (ctxF) {
                const fuelMobile = typeof window !== 'undefined' && window.innerWidth < 640;
                // Mobilde boş ayları gizle → çubuklar daha büyük
                let mLabels = monthLabels.slice();
                let mSpend = fuelSpend.slice();
                let mLiters = fuelLitersM.slice();
                if (fuelMobile) {
                    const keep = [];
                    for (let i = 0; i < mLabels.length; i++) {
                        if ((mSpend[i] || 0) > 0 || (mLiters[i] || 0) > 0) keep.push(i);
                    }
                    if (keep.length) {
                        mLabels = keep.map(function(i) { return mLabels[i]; });
                        mSpend = keep.map(function(i) { return mSpend[i]; });
                        mLiters = keep.map(function(i) { return mLiters[i]; });
                    }
                    // Yüksek kutu: ay başına ~56px + eksen/legend
                    const box = ctxF.parentElement;
                    if (box) {
                        const h = Math.max(320, 72 + mLabels.length * 56);
                        box.style.height = h + 'px';
                    }
                }
                const fuelDatasets = fuelMobile ? [
                    {
                        label: 'Harcama (TL)',
                        data: mSpend,
                        backgroundColor: 'rgba(79, 70, 229, 0.85)',
                        borderRadius: 8,
                        maxBarThickness: 22,
                        barPercentage: 0.92,
                        categoryPercentage: 0.72,
                        xAxisID: 'x'
                    },
                    {
                        label: 'Litre (L)',
                        data: mLiters,
                        backgroundColor: 'rgba(6, 182, 212, 0.85)',
                        borderRadius: 8,
                        maxBarThickness: 22,
                        barPercentage: 0.92,
                        categoryPercentage: 0.72,
                        xAxisID: 'x1'
                    }
                ] : [
                    {
                        label: 'Harcama (TL)',
                        data: fuelSpend,
                        backgroundColor: 'rgba(79, 70, 229, 0.85)',
                        borderRadius: 6,
                        maxBarThickness: 32,
                        barPercentage: 0.85,
                        categoryPercentage: 0.75,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Litre (L)',
                        data: fuelLitersM,
                        backgroundColor: 'rgba(6, 182, 212, 0.85)',
                        borderRadius: 6,
                        maxBarThickness: 32,
                        barPercentage: 0.85,
                        categoryPercentage: 0.75,
                        yAxisID: 'y1'
                    }
                ];
                vehicleFuelChart = new Chart(ctxF, {
                    type: 'bar',
                    data: {
                        labels: fuelMobile ? mLabels : monthLabels,
                        datasets: fuelDatasets
                    },
                    options: {
                        indexAxis: fuelMobile ? 'y' : 'x',
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: { mode: 'index', intersect: false },
                        layout: {
                            padding: fuelMobile ? { top: 4, bottom: 4, left: 2, right: 8 } : { top: 4, bottom: 0 }
                        },
                        plugins: {
                            legend: {
                                display: true,
                                position: 'bottom',
                                labels: { boxWidth: 12, font: { size: fuelMobile ? 12 : 11 }, padding: fuelMobile ? 12 : 10 }
                            }
                        },
                        scales: fuelMobile ? {
                            x: {
                                beginAtZero: true,
                                position: 'bottom',
                                title: { display: true, text: 'TL', font: { size: 12, weight: '700' }, color: '#4f46e5' },
                                ticks: { color: '#4f46e5', font: { size: 11 } }
                            },
                            x1: {
                                beginAtZero: true,
                                position: 'top',
                                grid: { drawOnChartArea: false },
                                title: { display: true, text: 'Litre', font: { size: 12, weight: '700' }, color: '#06b6d4' },
                                ticks: { color: '#06b6d4', font: { size: 11 } }
                            },
                            y: {
                                ticks: { font: { size: 12, weight: '600' }, color: '#334155' }
                            }
                        } : {
                            x: {
                                stacked: false,
                                ticks: { maxRotation: 40, font: { size: 10 } }
                            },
                            y: {
                                beginAtZero: true,
                                position: 'left',
                                stacked: false,
                                title: { display: true, text: 'TL', font: { size: 11, weight: '600' }, color: '#4f46e5' },
                                ticks: { color: '#4f46e5' }
                            },
                            y1: {
                                beginAtZero: true,
                                position: 'right',
                                stacked: false,
                                grid: { drawOnChartArea: false },
                                title: { display: true, text: 'Litre', font: { size: 11, weight: '600' }, color: '#06b6d4' },
                                ticks: { color: '#06b6d4' }
                            }
                        }
                    }
                });
            }

            // 2) Tüketim (L/100km) + Km maliyeti (TL/km) — tek grafik
            const ctxC = document.getElementById('vehicleFuelConsChart');
            if (ctxC) {
                vehicleFuelConsChart = new Chart(ctxC, {
                    type: 'line',
                    data: {
                        labels: fillLabels.length ? fillLabels : ['Veri yok'],
                        datasets: [
                            {
                                label: 'L / 100 km',
                                data: fillCons.length ? fillCons : [0],
                                borderColor: '#10b981',
                                backgroundColor: 'rgba(16,185,129,0.12)',
                                fill: false,
                                tension: 0.3,
                                pointRadius: 8, pointHoverRadius: 12, pointHitRadius: 28,
                                pointBackgroundColor: '#10b981',
                                yAxisID: 'y'
                            },
                            {
                                label: 'TL / km',
                                data: fillCost.length ? fillCost : [0],
                                borderColor: '#f59e0b',
                                backgroundColor: 'rgba(245,158,11,0.12)',
                                fill: false,
                                tension: 0.3,
                                pointRadius: 8, pointHoverRadius: 12, pointHitRadius: 28,
                                pointBackgroundColor: '#f59e0b',
                                yAxisID: 'y1'
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: { mode: 'index', intersect: false },
                        plugins: { legend: { display: true, position: 'bottom' } },
                        scales: {
                            y: {
                                beginAtZero: true,
                                position: 'left',
                                title: { display: true, text: 'L/100 km', font: { size: 11, weight: '600' }, color: '#10b981' },
                                ticks: { color: '#10b981' }
                            },
                            y1: {
                                beginAtZero: true,
                                position: 'right',
                                grid: { drawOnChartArea: false },
                                title: { display: true, text: 'TL/km', font: { size: 11, weight: '600' }, color: '#f59e0b' },
                                ticks: { color: '#f59e0b' }
                            }
                        }
                    }
                });
            }

            // 3) Yakıt LT fiyatı (TL)
            const ctxP = document.getElementById('vehicleFuelPriceChart');
            if (ctxP) {
                vehicleFuelPriceChart = new Chart(ctxP, {
                    type: 'line',
                    data: {
                        labels: fillLabels.length ? fillLabels : ['Veri yok'],
                        datasets: [{
                            label: 'LT fiyatı (TL)',
                            data: fillPrice.length ? fillPrice : [null],
                            borderColor: '#8b5cf6',
                            backgroundColor: 'rgba(139, 92, 246, 0.12)',
                            fill: true,
                            tension: 0.3,
                            pointRadius: 8, pointHoverRadius: 12, pointHitRadius: 28,
                            pointBackgroundColor: '#8b5cf6',
                            spanGaps: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: true, position: 'bottom' } },
                        scales: {
                            y: {
                                beginAtZero: false,
                                title: { display: true, text: 'TL / L', font: { size: 11, weight: '600' }, color: '#8b5cf6' }
                            }
                        }
                    }
                });
            }

            const ctxM = document.getElementById('vehicleMaintChart');
            if (ctxM) {
                vehicleMaintChart = new Chart(ctxM, {
                    type: 'bar',
                    data: {
                        labels: monthLabels,
                        datasets: [{ label: 'Vergi & Bakım (TL)', data: maintSpend, backgroundColor: '#f59e0b', borderRadius: 8, maxBarThickness: 36 }]
                    },
                    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
                });
            }
        };

        function validateExpenseAmount(raw) {
            const amount = parseFloat(String(raw).replace(',', '.'));
            if (isNaN(amount) || !isFinite(amount)) {
                return { ok: false, message: 'Geçerli bir tutar girin.' };
            }
            if (amount < AMOUNT_MIN) {
                return { ok: false, message: 'Tutar en az ' + AMOUNT_MIN + ' TL olmalı.' };
            }
            if (amount > AMOUNT_MAX) {
                return { ok: false, message: 'Tutar en fazla ' + AMOUNT_MAX.toLocaleString('tr-TR') + ' TL olabilir.\n(Çok büyük değer yanlışlıkla girilmiş olabilir.)' };
            }
            return { ok: true, amount: amount };
        }

        window.handleFormSubmit = async (e) => {
            e.preventDefault();
            const id = document.getElementById('editId').value;
            const amountCheck = validateExpenseAmount(document.getElementById('amount').value);
            if (!amountCheck.ok) {
                alert(amountCheck.message);
                const amtEl = document.getElementById('amount');
                if (amtEl) amtEl.focus();
                return;
            }
            const amount = amountCheck.amount;
            const isRecurring = !!(document.getElementById('isRecurring') && document.getElementById('isRecurring').checked);
            let installment = parseInt(document.getElementById('installmentCount').value) || 1;
            let amountPerInstallment;
            if (isRecurring) {
                const rm = parseInt((document.getElementById('recurringMonths') || {}).value, 10) || 1;
                installment = Math.min(12, Math.max(1, rm));
                amountPerInstallment = amount; // her ay aynı tutar
            } else {
                amountPerInstallment = amount / installment;
            }
            const person = document.getElementById('person').value;
            const paymentType = document.getElementById('paymentType').value;
            const date = document.getElementById('date').value;
            const description = document.getElementById('description').value || '-';
            const category = document.getElementById('category').value;
            let vehicleSubtype = '';
            let billSubtype = '';
            let fuelKm = null, fuelLiters = null, fuelPricePerLt = null;
            let fuelNote = '';
            if (category === 'Faturalar') {
                const bs = document.getElementById('billSubtype');
                billSubtype = bs ? bs.value : '';
                if (!billSubtype) {
                    alert('Fatura türü seçin: Elektrik, Su, Doğalgaz, Telefon, İnternet veya Abonelik');
                    return;
                }
            }
            if (category === 'Araç' || category === 'Ulaşım') {
                const vs = document.getElementById('vehicleSubtype');
                vehicleSubtype = vs ? vs.value : '';
                if (!vehicleSubtype) {
                    alert('Araç kategorisi için Yakıt, Vergi veya Bakım seçin');
                    return;
                }
                if (vehicleSubtype === 'Yakıt') {
                    const kmEl = document.getElementById('fuelKm');
                    const ltEl = document.getElementById('fuelLiters');
                    const prEl = document.getElementById('fuelPricePerLt');
                    fuelKm = kmEl && kmEl.value !== '' ? parseFloat(kmEl.value) : null;
                    fuelLiters = ltEl && ltEl.value !== '' ? parseFloat(ltEl.value) : null;
                    fuelPricePerLt = prEl && prEl.value !== '' ? parseFloat(prEl.value) : null;
                    if (fuelKm && fuelKm > 0 && fuelLiters && fuelLiters > 0) {
                        const per100 = (fuelLiters / fuelKm) * 100;
                        let costPerKm = null;
                        if (fuelPricePerLt && fuelPricePerLt > 0) {
                            costPerKm = (fuelLiters * fuelPricePerLt) / fuelKm;
                        } else if (amount && amount > 0) {
                            costPerKm = amount / fuelKm;
                        }
                        fuelNote = '100 km\'de ' + per100.toFixed(2) + ' L';
                        if (costPerKm != null && !isNaN(costPerKm)) {
                            fuelNote += ' · 1 km ' + costPerKm.toFixed(2) + ' TL';
                        }
                    }
                }
            }
            
            if (!amount || amount <= 0) {
                alert('Lütfen geçerli bir tutar giriniz');
                return;
            }
            if (!date) {
                alert('Lütfen tarih seçiniz');
                return;
            }
            
            const data = {
                amount: isRecurring ? amount : amount,
                installmentCount: installment,
                amountPerInstallment: amountPerInstallment,
                isRecurring: !!isRecurring,
                person: person,
                category: category === 'Ulaşım' ? 'Araç' : category,
                paymentType: paymentType,
                date: date,
                description: description,
                expenseMonth: date.substring(0, 7),
                statementPeriod: getPeriodKeyForDateStr(date),
                vehicleSubtype: (category === 'Araç' || category === 'Ulaşım') ? vehicleSubtype : '',
                billSubtype: category === 'Faturalar' ? billSubtype : '',
                fuelKm: fuelKm,
                fuelLiters: fuelLiters,
                fuelPricePerLt: fuelPricePerLt,
                fuelNote: fuelNote || ''
            };
            
            try {
                if (id) {
                    data.updatedAt = new Date().toISOString();
                    await db.collection("expenses").doc(id).update(data);
                } else {
                    data.createdAt = new Date().toISOString();
                    data.updatedAt = data.createdAt;
                    await db.collection("expenses").add(data);
                }
                
                resetForm();
                closeExpenseModal();
                await new Promise(resolve => setTimeout(resolve, 300));
                renderApp();
                updateStatsPanel();
                logActivity('Harcama', id ? 'Harcama güncellendi' : 'Harcama eklendi',
                    (person || '') + ' · ' + (category || '') + ' · ' + amount + ' TL' + (description && description !== '-' ? ' · ' + description : ''));
                if (!id) {
                    setTimeout(function() {
                        try { if (typeof showEyvahPopup === 'function') showEyvahPopup(); } catch (_) {}
                    }, 350);
                }
            } catch (err) {
                console.error("Harcama kayıt hatası:", err);
                showToast(friendlyFirebaseError(err), 'error');
            }
        };

        let _eyvahTimer = null;
        window.showEyvahPopup = function() {
            try {
                const ov = document.getElementById('eyvahOverlay');
                if (!ov) {
                    console.warn('eyvahOverlay yok');
                    return;
                }
                ov.classList.remove('hidden');
                ov.style.display = 'flex';
                ov.setAttribute('aria-hidden', 'false');
                if (_eyvahTimer) clearTimeout(_eyvahTimer);
                _eyvahTimer = setTimeout(function() {
                    ov.classList.add('hidden');
                    ov.style.display = '';
                    ov.setAttribute('aria-hidden', 'true');
                }, 5000);
                ov.onclick = function() {
                    ov.classList.add('hidden');
                    ov.style.display = '';
                    ov.setAttribute('aria-hidden', 'true');
                    if (_eyvahTimer) clearTimeout(_eyvahTimer);
                };
            } catch (err) {
                console.error('showEyvahPopup', err);
            }
        };

        window.deleteExpense = async (id) => {
            if (!confirm("Silmek istediğinize emin misiniz?")) return;
            
            let actualId = id;
            if (typeof id === 'string' && id.includes('_ins_')) {
                actualId = id.split('_ins_')[0];
            }
            
            const item = expenses.find(e => e.id === actualId);
            
            if (!item) {
                alert('Harcama bulunamadı');
                return;
            }
            
            deletedExpenses.push({...item, deletedAt: new Date().toISOString()});
            localStorage.setItem('deletedExpenses', JSON.stringify(deletedExpenses));
            await db.collection("expenses").doc(actualId).delete();
            logActivity('Harcama', 'Harcama silindi', (item.person || '') + ' · ' + (item.amount || '') + ' TL · ' + (item.description || ''));
        };

        window.editExpense = (id) => {
            let actualId = id;
            if (typeof id === 'string' && id.includes('_ins_')) {
                actualId = id.split('_ins_')[0];
            }
            
            const e = expenses.find(i => i.id === actualId);
            if (!e) {
                alert('Harcama bulunamadı');
                return;
            }
            
            document.getElementById('editId').value = e.id;
            document.getElementById('amount').value = e.amount;
            const isRec = !!e.isRecurring;
            const recChk = document.getElementById('isRecurring');
            if (recChk) recChk.checked = isRec;
            if (typeof onRecurringToggle === 'function') onRecurringToggle();
            if (isRec) {
                const rms = document.getElementById('recurringMonths');
                if (rms) rms.value = String(Math.min(12, e.installmentCount || 1));
                document.getElementById('installmentCount').value = '1';
            } else {
                document.getElementById('installmentCount').value = e.installmentCount || 1;
            }
            document.getElementById('person').value = e.person;
            const catVal = e.category === 'Ulaşım' ? 'Araç' : e.category;
            document.getElementById('category').value = catVal;
            document.getElementById('paymentType').value = e.paymentType;
            document.getElementById('date').value = e.date;
            document.getElementById('description').value = e.description === '-' ? '' : e.description;
            document.getElementById('formTitle').innerText = "Harcamayı Düzenle";
            if (typeof onCategoryChange === 'function') onCategoryChange();
            const vs = document.getElementById('vehicleSubtype');
            if (vs && e.vehicleSubtype) vs.value = e.vehicleSubtype;
            const bs = document.getElementById('billSubtype');
            if (bs && e.billSubtype) bs.value = e.billSubtype;
            if (typeof onVehicleSubtypeChange === 'function') onVehicleSubtypeChange();
            const fk = document.getElementById('fuelKm');
            const fl = document.getElementById('fuelLiters');
            const fp = document.getElementById('fuelPricePerLt');
            if (fk) fk.value = e.fuelKm != null ? e.fuelKm : '';
            if (fl) fl.value = e.fuelLiters != null ? e.fuelLiters : '';
            if (fp) fp.value = e.fuelPricePerLt != null ? e.fuelPricePerLt : '';
            openExpenseModal();
        };

        // Tablo Render
        function todayDateStr() {
            const d = new Date();
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${y}-${m}-${day}`;
        }

        function isFutureDateStr(dateStr) {
            if (!dateStr) return false;
            const s = String(dateStr).slice(0, 10);
            return s > todayDateStr();
        }

        function getProcessedExpenses() {
            // Harcamaları 29–28 ekstre dönemine göre işler. effectiveMonth = periodKey
            const currentPeriod = getCurrentPeriod();
            let processed = [];

            expenses.forEach(item => {
                const count = item.installmentCount || 1;
                const perAmount = item.isRecurring
                    ? (item.amountPerInstallment != null ? item.amountPerInstallment : item.amount)
                    : (item.amountPerInstallment != null ? item.amountPerInstallment : (item.amount / count));
                const originalDate = item.date;

                if (count <= 1) {
                    const periodKey = getPeriodKeyForDateStr(originalDate);
                    processed.push({
                        ...item,
                        displayAmount: item.amount,
                        installmentLabel: 'Peşin',
                        effectiveMonth: periodKey,
                        date: originalDate
                    });
                } else {
                    const installmentEntries = [];
                    for (let i = 0; i < count; i++) {
                        const dateStr = shiftDateByMonths(originalDate, i);
                        const periodKey = getPeriodKeyForDateStr(dateStr);
                        const label = item.isRecurring
                            ? (`Tekrar ${i + 1}/${count}`)
                            : (`Taksit ${i + 1}/${count}`);
                        installmentEntries.push({
                            ...item,
                            id: item.id + '_ins_' + i,
                            displayAmount: perAmount,
                            installmentLabel: label,
                            effectiveMonth: periodKey,
                            date: dateStr,
                            installmentIndex: i
                        });
                    }

                    if (currentShowInstallments) {
                        installmentEntries.forEach(entry => {
                            if (entry.effectiveMonth >= currentPeriod) {
                                processed.push(entry);
                            }
                        });
                    } else {
                        const inCurrent = installmentEntries.find(e => e.effectiveMonth === currentPeriod);
                        if (inCurrent) {
                            processed.push({
                                ...inCurrent,
                                id: item.id
                            });
                        }
                    }
                }
            });
            return processed;
        }

        function formatDateTR(ymd) {
            const s = String(ymd || '').slice(0, 10);
            const p = s.split('-');
            if (p.length !== 3) return s || '-';
            return p[2] + '.' + p[1] + '.' + p[0];
        }

        window.toggleExpenseCard = function(el, ev) {
            if (ev && ev.target && ev.target.closest && ev.target.closest('button')) return;
            if (!el) return;
            const wasOpen = el.classList.contains('is-open');
            // tek açık kart
            document.querySelectorAll('.expense-m-card.is-open').forEach(function(c) {
                if (c !== el) c.classList.remove('is-open');
            });
            el.classList.toggle('is-open', !wasOpen);
        };


        function expenseTimeKey(item) {
            if (!item) return '';
            const c = item.createdAt;
            if (c != null && c !== '') {
                if (typeof c === 'string') {
                    // ISO veya benzeri
                    return c;
                }
                if (typeof c.toDate === 'function') {
                    try { return c.toDate().toISOString(); } catch (_) {}
                }
                if (typeof c === 'object' && c.seconds != null) {
                    return new Date(Number(c.seconds) * 1000 + Math.floor(Number(c.nanoseconds || 0) / 1e6)).toISOString();
                }
                if (c instanceof Date && !isNaN(c.getTime())) return c.toISOString();
            }
            // updatedAt yedek
            const u = item.updatedAt;
            if (typeof u === 'string' && u) return u;
            if (u && typeof u.toDate === 'function') {
                try { return u.toDate().toISOString(); } catch (_) {}
            }
            // Firestore auto-id kabaca zaman sıralı
            return String(item.id || '');
        }

        function renderTable() {
            const tbody = document.getElementById('expenseTableBody');
            const cardsHost = document.getElementById('expenseCardsMobile');
            if (tbody) tbody.innerHTML = '';
            if (cardsHost) cardsHost.innerHTML = '';

            let filtered = [];

            if (currentShowInstallments) {
                filtered = getProcessedExpenses().filter(item => item.installmentLabel !== 'Peşin');
            } else {
                filtered = getProcessedExpenses().map(e => ({ ...e }));
            }

            filtered = filtered.filter(item => {
                if (currentPersonFilter !== 'Tümü' && item.person !== currentPersonFilter) return false;
                if (currentCategoryFilter !== 'Tümü' && item.category !== currentCategoryFilter) return false;
                if (currentPaymentFilter !== 'Tümü' && item.paymentType !== currentPaymentFilter) return false;

                if (currentStartDateFilter && item.date < currentStartDateFilter) return false;
                if (currentEndDateFilter && item.date > currentEndDateFilter) return false;

                if (currentSearchFilter) {
                    const q = currentSearchFilter.toLocaleLowerCase('tr-TR');
                    const blob = [
                        item.category, item.description, item.person, item.paymentType,
                        item.vehicleSubtype, item.billSubtype, item.installmentLabel, item.fuelNote
                    ].map(x => String(x || '')).join(' ').toLocaleLowerCase('tr-TR');
                    if (!blob.includes(q)) return false;
                }

                return true;
            });

            filtered.sort((a, b) => {
                if (sortColumn === 'date') {
                    const dA = String(a.date || '');
                    const dB = String(b.date || '');
                    if (dA !== dB) {
                        return sortDirection === 'asc' ? (dA > dB ? 1 : -1) : (dA < dB ? 1 : -1);
                    }
                    // Aynı gün: her zaman en son eklenen üstte (saat / createdAt)
                    const tA = expenseTimeKey(a);
                    const tB = expenseTimeKey(b);
                    if (tA !== tB) return tA < tB ? 1 : -1;
                    return String(b.id || '').localeCompare(String(a.id || ''));
                }
                let vA = a[sortColumn], vB = b[sortColumn];
                if (sortColumn === 'amount') { vA = a.displayAmount; vB = b.displayAmount; }
                if (vA === vB) {
                    const tA = expenseTimeKey(a);
                    const tB = expenseTimeKey(b);
                    if (tA !== tB) return tA < tB ? 1 : -1;
                }
                return sortDirection === 'asc' ? (vA > vB ? 1 : -1) : (vA < vB ? 1 : -1);
            });

            const totalRecords = filtered.length;
            const displayedRecords = Math.min(displayLimit, totalRecords);
            const slice = filtered.slice(0, displayedRecords);

            // --- Web tablo ---
            if (tbody) {
                slice.forEach(item => {
                    const tr = document.createElement('tr');
                    const isIncome = item.installmentLabel === 'Gelir';
                    const isFuture = !isIncome && isFutureDateStr(item.date);
                    if (isFuture) {
                        tr.className = 'row-future-expense';
                        tr.title = 'İleri tarihli kayıt';
                    }
                    const safeId = escapeHtml(item.id);
                    const dateCell = isFuture
                        ? `<td class="px-8 py-5"><span class="inline-flex items-center gap-1.5"><span class="opacity-80">${escapeHtml(item.date || '-')}</span><span class="text-[9px] font-black uppercase tracking-wide text-amber-700 bg-amber-100/80 px-1.5 py-0.5 rounded">İleri</span></span></td>`
                        : `<td class="px-8 py-5 opacity-60">${escapeHtml(item.date || '-')}</td>`;
                    tr.innerHTML = `
                        ${dateCell}
                        <td class="px-6 py-5">
                            <span class="px-3 py-1 rounded-lg text-[10px] font-black ${item.person === 'Bekir' ? 'bg-blue-50 text-blue-600' : (item.person === 'Duygu' ? 'bg-pink-50 text-pink-600' : 'bg-emerald-50 text-emerald-600')}">
                                ${escapeHtml((item.person || '').toUpperCase())}
                            </span>
                        </td>
                        <td class="px-6 py-5"><span class="bg-slate-100 px-2 py-1 rounded text-[10px]">${escapeHtml(item.category)}${item.billSubtype ? ' · ' + escapeHtml(item.billSubtype) : ''}${item.vehicleSubtype ? ' · ' + escapeHtml(item.vehicleSubtype) : ''}</span></td>
                        <td class="px-6 py-5 opacity-60">${escapeHtml(item.paymentType || '-')}</td>
                        <td class="px-6 py-5">
                            <div class="flex flex-col">
                                <span>${escapeHtml(item.description)}</span>
                                <span class="text-[9px] text-indigo-500 font-black tracking-tighter uppercase">${escapeHtml(item.installmentLabel)}</span>
                            </div>
                        </td>
                        <td class="px-6 py-5 text-right font-black ${isIncome ? 'text-emerald-600' : 'text-rose-600'}">
                            ${isIncome ? '+' : '-'}${item.displayAmount.toLocaleString('tr-TR')} TL
                        </td>
                        <td class="px-8 py-5 text-center space-x-2">
                            ${!isIncome && !String(item.id).includes('_ins_') ? `<button onclick="editExpense('${safeId}')" class="text-indigo-600 hover:scale-110 transition">✏️</button>` : ''}
                            <button onclick="${isIncome ? `deleteIncome('${safeId}')` : `deleteExpense('${safeId}')`}" class="text-rose-500 hover:scale-110 transition">🗑️</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });

                if (totalRecords > displayedRecords) {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td colspan="7" class="p-4 text-center">
                            <button onclick="loadMoreRecords()" class="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold text-sm hover:bg-indigo-700 transition">
                                Daha Fazla Göster (${totalRecords - displayedRecords} kayıt kaldı)
                            </button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                }
            }

            // --- Mobil kartlar: ileri tarihli (açılır) + normal (max displayLimit) ---
            if (cardsHost) {
                const isIncomeItem = function(item) { return item.installmentLabel === 'Gelir'; };
                const futures = filtered.filter(function(item) {
                    return !isIncomeItem(item) && isFutureDateStr(item.date);
                });
                // Normal listeden ileri tarihlileri ayır; limit normal kayıtlara uygulanır
                const normalsAll = filtered.filter(function(item) {
                    return isIncomeItem(item) || !isFutureDateStr(item.date);
                });
                const normalDisplayed = Math.min(displayLimit, normalsAll.length);
                const normals = normalsAll.slice(0, normalDisplayed);

                function buildMobileCard(item) {
                    const isIncome = isIncomeItem(item);
                    const isFuture = !isIncome && isFutureDateStr(item.date);
                    const safeId = escapeHtml(String(item.id || ''));
                    const desc = escapeHtml(item.description || item.category || 'Harcama');
                    const amt = (isIncome ? '+' : '-') + (Number(item.displayAmount) || 0).toLocaleString('tr-TR') + ' TL';
                    const personCls = item.person === 'Bekir' ? 'person-bekir' : (item.person === 'Duygu' ? 'person-duygu' : '');
                    const catLine = escapeHtml(item.category || '-')
                        + (item.billSubtype ? ' · ' + escapeHtml(item.billSubtype) : '')
                        + (item.vehicleSubtype ? ' · ' + escapeHtml(item.vehicleSubtype) : '');
                    const canEdit = !isIncome && !String(item.id).includes('_ins_');
                    const delFn = isIncome ? "deleteIncome('" + safeId + "')" : "deleteExpense('" + safeId + "')";

                    const card = document.createElement('div');
                    card.className = 'expense-m-card' + (isFuture ? ' is-future' : '');
                    card.setAttribute('role', 'button');
                    card.onclick = function(ev) { toggleExpenseCard(card, ev); };
                    card.innerHTML =
                        '<div class="expense-m-main">' +
                          '<div class="expense-m-left">' +
                            '<p class="expense-m-desc">' + desc + '</p>' +
                            '<p class="expense-m-date">' + escapeHtml(formatDateTR(item.date)) + '</p>' +
                          '</div>' +
                          '<div class="expense-m-right">' +
                            (isFuture ? '<span class="expense-m-badge-future">İleri tarihli</span>' : '') +
                            '<span class="expense-m-amount' + (isIncome ? ' is-income' : '') + '">' + amt + '</span>' +
                          '</div>' +
                        '</div>' +
                        '<div class="expense-m-detail">' +
                          '<div class="expense-m-chips">' +
                            '<span class="expense-m-chip ' + personCls + '">' + escapeHtml(item.person || '-') + '</span>' +
                            '<span class="expense-m-chip">' + catLine + '</span>' +
                            '<span class="expense-m-chip">' + escapeHtml(item.paymentType || '-') + '</span>' +
                            (item.installmentLabel && item.installmentLabel !== 'Peşin'
                              ? '<span class="expense-m-chip">' + escapeHtml(item.installmentLabel) + '</span>' : '') +
                          '</div>' +
                          (item.fuelNote ? '<p class="expense-m-meta">' + escapeHtml(item.fuelNote) + '</p>' : '') +
                          '<div class="expense-m-actions">' +
                            (canEdit
                              ? '<button type="button" class="expense-m-btn-edit" onclick="event.stopPropagation();editExpense(\'' + safeId + '\')">Düzenle</button>'
                              : '') +
                            '<button type="button" class="expense-m-btn-del" onclick="event.stopPropagation();' + delFn + '">Sil</button>' +
                          '</div>' +
                        '</div>';
                    return card;
                }

                cardsHost.innerHTML = '';

                // İleri tarihli bölüm (üstte, kapalı)
                if (futures.length) {
                    // futures: yakın tarihe göre sırala (artan tarih)
                    futures.sort(function(a, b) {
                        const d = String(a.date || '').localeCompare(String(b.date || ''));
                        if (d !== 0) return d;
                        return expenseTimeKey(b).localeCompare(expenseTimeKey(a));
                    });
                    const wrap = document.createElement('div');
                    wrap.className = 'expense-future-section';
                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'expense-future-toggle';
                    btn.innerHTML = '<span>İleri tarihli (' + futures.length + ')</span><span class="chev">▼</span>';
                    const list = document.createElement('div');
                    list.className = 'expense-future-list';
                    list.id = 'expenseFutureList';
                    futures.forEach(function(item) { list.appendChild(buildMobileCard(item)); });
                    btn.onclick = function(ev) {
                        ev.stopPropagation();
                        const open = list.classList.toggle('is-open');
                        btn.classList.toggle('is-open', open);
                    };
                    wrap.appendChild(btn);
                    wrap.appendChild(list);
                    cardsHost.appendChild(wrap);
                }

                if (!normals.length && !futures.length) {
                    cardsHost.innerHTML = '<p class="expense-m-empty">Kayıt yok</p>';
                } else {
                    normals.forEach(function(item) {
                        cardsHost.appendChild(buildMobileCard(item));
                    });
                    if (normalsAll.length > normalDisplayed) {
                        const more = document.createElement('div');
                        more.className = 'expense-m-more';
                        more.innerHTML = '<button type="button" onclick="loadMoreRecords()">Daha fazla göster (' + (normalsAll.length - normalDisplayed) + ')</button>';
                        cardsHost.appendChild(more);
                    }
                }
            }
        }

        window.loadMoreRecords = () => {
            displayLimit += 10;
            renderTable();
        };


        // Raporlar paneli
        window.showCategoryExpenses = function(category) {
            const period = getCurrentPeriod();
            const items = getProcessedExpenses().filter(e =>
                e.effectiveMonth === period && e.category === category
            );
            const modal = document.getElementById('categoryDetailModal');
            const title = document.getElementById('categoryDetailTitle');
            const body = document.getElementById('categoryDetailBody');
            const totalEl = document.getElementById('categoryDetailTotal');
            if (!modal || !body) return;
            if (title) title.textContent = category + ' — dönem harcamaları';
            const total = items.reduce((s, e) => s + (e.displayAmount || 0), 0);
            if (totalEl) totalEl.textContent = total.toLocaleString('tr-TR') + ' TL';
            if (!items.length) {
                body.innerHTML = '<p class="text-sm text-slate-400 font-medium text-center py-6">Bu kategoride dönem harcaması yok</p>';
            } else {
                body.innerHTML = items
                    .slice()
                    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
                    .map(e => `
                    <div class="flex justify-between gap-3 items-start py-3 border-b border-slate-100 last:border-0">
                        <div class="min-w-0">
                            <p class="text-sm font-bold text-slate-800 truncate">${escapeHtml(e.description || '-')}</p>
                            <p class="text-[11px] text-slate-400 font-semibold mt-0.5">${escapeHtml(e.date || '')} · ${escapeHtml(e.person || '')} · ${escapeHtml(e.installmentLabel || '')}</p>
                        </div>
                        <p class="text-sm font-black text-rose-600 whitespace-nowrap">${(e.displayAmount || 0).toLocaleString('tr-TR')} TL</p>
                    </div>`).join('');
            }
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        };

        window.closeCategoryDetailModal = function() {
            const modal = document.getElementById('categoryDetailModal');
            if (!modal) return;
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        };

        window.showDayExpenses = function(ymd, label) {
            const day = String(ymd || '').slice(0, 10);
            // Ham + işlenmiş kayıtlardan güne göre topla
            let items = getProcessedExpenses().filter(function(e) {
                return String(e.date || '').slice(0, 10) === day;
            });
            // İşlenmişte yoksa orijinal expenses
            if (!items.length && Array.isArray(expenses)) {
                items = expenses.filter(function(e) {
                    return String(e.date || '').slice(0, 10) === day;
                }).map(function(e) {
                    return Object.assign({}, e, {
                        displayAmount: e.amount,
                        installmentLabel: (e.installmentCount > 1 ? 'Taksit/Tekrar' : 'Peşin')
                    });
                });
            }
            const modal = document.getElementById('categoryDetailModal');
            const title = document.getElementById('categoryDetailTitle');
            const body = document.getElementById('categoryDetailBody');
            const totalEl = document.getElementById('categoryDetailTotal');
            if (!modal || !body) {
                alert('Detay penceresi bulunamadı. Sayfayı Ctrl+F5 ile yenileyin.');
                return;
            }
            if (title) title.textContent = (label || day) + ' — gün harcamaları';
            const total = items.reduce(function(s, e) { return s + (Number(e.displayAmount != null ? e.displayAmount : e.amount) || 0); }, 0);
            if (totalEl) totalEl.textContent = total.toLocaleString('tr-TR') + ' TL';
            if (!items.length) {
                body.innerHTML = '<p class="text-sm text-slate-400 font-medium text-center py-6">Bu günde harcama yok</p>';
            } else {
                body.innerHTML = items.slice().sort(function(a, b) {
                    return String(b.createdAt || b.id || '').localeCompare(String(a.createdAt || a.id || ''));
                }).map(function(e) {
                    const amt = Number(e.displayAmount != null ? e.displayAmount : e.amount) || 0;
                    return '<div class="flex justify-between gap-3 items-start py-3 border-b border-slate-100 last:border-0">' +
                        '<div class="min-w-0">' +
                          '<p class="text-sm font-bold text-slate-800 truncate">' + escapeHtml(e.description || e.category || '-') + '</p>' +
                          '<p class="text-[11px] text-slate-400 font-semibold mt-0.5">' +
                            escapeHtml(e.category || '') +
                            (e.billSubtype ? ' · ' + escapeHtml(e.billSubtype) : '') +
                            ' · ' + escapeHtml(e.person || '') +
                            (e.installmentLabel ? ' · ' + escapeHtml(e.installmentLabel) : '') +
                          '</p>' +
                        '</div>' +
                        '<p class="text-sm font-black text-rose-600 whitespace-nowrap">' + amt.toLocaleString('tr-TR') + ' TL</p>' +
                      '</div>';
                }).join('');
            }
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        };



        function buildExpenseSummaryForAi() {
            // Site ile aynı mantık: 29–28 dönem + taksit satırları (effectiveMonth / displayAmount)
            const processed = getProcessedExpenses();
            // En yeni dönem başta: [0]=aktif, [1]=önceki, [2]=onunkisi
            const periodKeys = getPreviousPeriodKeys(3).slice().reverse();
            const byPeriod = {};
            periodKeys.forEach(pk => { byPeriod[pk] = {}; });

            processed.forEach(e => {
                const pk = e.effectiveMonth || getPeriodKeyForDateStr(e.date);
                if (!byPeriod[pk]) return;
                const cat = e.category || 'Diğer';
                const sub = e.billSubtype || e.vehicleSubtype || '';
                const label = sub ? (cat + '/' + sub) : cat;
                const amt = Number(e.displayAmount);
                if (!isFinite(amt)) return;
                byPeriod[pk][label] = (byPeriod[pk][label] || 0) + amt;
            });

            // Aktif dönem toplamını bütçe kartıyla aynı formülle doğrula
            const currentPk = getCurrentPeriod();
            const currentTotal = processed
                .filter(e => e.effectiveMonth === currentPk)
                .reduce((s, e) => s + (Number(e.displayAmount) || 0), 0);

            return {
                months: periodKeys, // geriye uyum: runAiAdvisor "months" kullanıyor
                byMonth: byPeriod,
                period: currentPk,
                currentTotal,
                labels: Object.fromEntries(periodKeys.map(pk => [pk, formatPeriodLabel(pk)]))
            };
        }


        function renderAdvisorInto(boxId, lines, sourceLabel, accent) {
            const box = document.getElementById(boxId);
            if (!box) return;
            const color = accent === 'ai' ? 'violet' : 'indigo';
            const head = sourceLabel
                ? '<p class="text-[11px] font-bold text-' + color + '-600 mb-3">' + escapeHtml(sourceLabel) + '</p>'
                : '';
            const cards = (lines || []).filter(Boolean).map(function(line, i) {
                let t = String(line).replace(/\*\*/g, '').replace(/\*/g, '').trim();
                let title = '';
                let body = t;
                const colon = t.indexOf(':');
                if (colon > 0 && colon < 80) {
                    title = t.slice(0, colon).trim();
                    body = t.slice(colon + 1).trim();
                }
                return (
                    '<div class="bg-white rounded-xl border border-' + color + '-100 p-3.5 mb-2.5 shadow-sm">' +
                      '<div class="flex gap-2.5 items-start">' +
                        '<span class="shrink-0 w-6 h-6 rounded-full bg-' + color + '-600 text-white text-[11px] font-black flex items-center justify-center">' + (i + 1) + '</span>' +
                        '<div class="min-w-0">' +
                          (title ? '<p class="text-sm font-black text-slate-900 mb-1">' + escapeHtml(title) + '</p>' : '') +
                          '<p class="text-sm text-slate-600 font-medium leading-relaxed">' + escapeHtml(body || t) + '</p>' +
                        '</div>' +
                      '</div>' +
                    '</div>'
                );
            }).join('');
            box.innerHTML = head + (cards || '<p class="text-sm text-slate-400">Öneri yok</p>');
        }

        function parseAdvisorText(raw) {
            if (!raw) return [];
            let t = String(raw).replace(/\r/g, '').replace(/\*\*/g, '').replace(/__/g, '').trim();
            let parts = t.split(/\n+/).map(function(s) { return s.trim(); }).filter(Boolean);
            if (parts.length <= 2) {
                parts = t.split(/(?=\d+[\.\)]\s)/).map(function(s) { return s.trim(); }).filter(Boolean);
            }
            if (parts.length <= 1) {
                parts = t.split(/(?=•\s)/).map(function(s) { return s.trim(); }).filter(Boolean);
            }
            return parts.map(function(p) {
                return p.replace(/^\d+[\.\)]\s*/, '').replace(/^[-•]\s*/, '').trim();
            }).filter(function(p) { return p.length > 8; }).slice(0, 12);
        }

        function buildDetailedLocalTips() {
            const tips = [];
            const summary = buildExpenseSummaryForAi();
            const processed = getProcessedExpenses();
            const months = summary.months || [];
            if (!months.length) {
                return ['Henüz harcama verisi yok. Kayıt ekledikten sonra tekrar deneyin.'];
            }

            const cur = months[0];
            const prev = months[1];
            const prev2 = months[2];
            const curCats = summary.byMonth[cur] || {};
            const prevCats = prev ? (summary.byMonth[prev] || {}) : {};
            const curLabel = (summary.labels && summary.labels[cur]) || formatPeriodLabel(cur);
            const prevLabel = prev ? ((summary.labels && summary.labels[prev]) || formatPeriodLabel(prev)) : '';
            const curItems = processed.filter(function(e) { return e.effectiveMonth === cur; });
            const curTotal = (summary.period === cur && summary.currentTotal != null)
                ? summary.currentTotal
                : Object.values(curCats).reduce(function(a, b) { return a + b; }, 0);
            const prevTotal = Object.values(prevCats).reduce(function(a, b) { return a + b; }, 0);

            tips.push('Aktif dönem (' + curLabel + '): ' + Math.round(curTotal).toLocaleString('tr-TR') + ' TL · ' + curItems.length + ' kalem.');
            // Gelire göre dönem analizi (110.000 TL sabit)
            (function() {
                const income = HOUSEHOLD_MONTHLY_INCOME;
                const ratio = income > 0 ? (curTotal / income) * 100 : 0;
                const remain = income - curTotal;
                tips.push('Gelir çerçevesi: aylık ' + income.toLocaleString('tr-TR') + ' TL varsayımıyla bu dönem harcama gelire oranı %' + ratio.toFixed(1) + ' · kalan ~' + Math.round(remain).toLocaleString('tr-TR') + ' TL.');
                if (ratio > 90) {
                    tips.push('Kritik: Harcama gelire çok yakın/üstü. Zorunlu olmayan (eğlence, giyim, online) kalemleri dondurun; kart ekstre ödemesini geciktirmeyin.');
                } else if (ratio > 75) {
                    tips.push('Yüksek baskı: Gelirin %' + ratio.toFixed(0) + '\'i harcanmış. Bu dönemde yeni abonelik/taksit açmayın; market ve yeme-içmeyi haftalık limitleyin.');
                } else if (ratio > 55) {
                    tips.push('Orta seviye: Gelirin %' + ratio.toFixed(0) + '\'i kullanılmış. Hedef: bir sonraki dönemde oranı %50 altına çekmek için en yüksek 2 kategoride %10 kısıt.');
                } else if (ratio > 0) {
                    tips.push('Rahat bant: Gelirin %' + ratio.toFixed(0) + '\'i harcanmış; ~' + Math.round(remain).toLocaleString('tr-TR') + ' TL nefes payı var. Fazlayı acil fon veya kart borcuna yönlendirin.');
                }
                // Kategori / gelir
                const cats = {};
                curItems.forEach(function(e) {
                    const c = e.category || 'Diğer';
                    cats[c] = (cats[c] || 0) + (e.displayAmount || 0);
                });
                Object.entries(cats).sort(function(a,b){return b[1]-a[1];}).slice(0, 4).forEach(function(kv) {
                    const pInc = income > 0 ? (kv[1] / income * 100) : 0;
                    if (pInc >= 8) {
                        tips.push(kv[0] + ': ' + Math.round(kv[1]).toLocaleString('tr-TR') + ' TL = gelirin %' + pInc.toFixed(1) + '\'i. ' + (pInc >= 20 ? 'Bu kategori hane bütçesini domine ediyor; kalem kalem inceleme şart.' : 'İzleyin; bir üst limite yaklaşırsa kısıtlayın.'));
                    }
                });
                // Tasarruf önerisi
                const saveTarget = Math.round(income * 0.15);
                if (remain > saveTarget) {
                    tips.push('Tasarruf fırsatı: Gelirin %15\'i (~' + saveTarget.toLocaleString('tr-TR') + ' TL) ayrılabilir görünüyor; otomatik transfer veya kart borcu erken ödemesi düşünün.');
                } else if (remain > 0 && remain < saveTarget) {
                    tips.push('Tasarruf hedefi (~' + saveTarget.toLocaleString('tr-TR') + ' TL / gelirin %15\'i) şu an tam dolmuyor; en az ' + Math.round(saveTarget - remain).toLocaleString('tr-TR') + ' TL kısma alanı bulun.');
                }
            })();


            if (prev) {
                const diff = curTotal - prevTotal;
                const pct = prevTotal > 0 ? Math.round((diff / prevTotal) * 100) : 0;
                if (Math.abs(diff) < 50) {
                    tips.push('Önceki dönem (' + prevLabel + ') ile fark az: ' + Math.round(prevTotal).toLocaleString('tr-TR') + ' TL → benzer seviye.');
                } else if (diff > 0) {
                    tips.push('Önceki döneme göre +' + Math.round(diff).toLocaleString('tr-TR') + ' TL (%' + pct + '). Artışın hangi kategoriden geldiğine bakın.');
                } else {
                    tips.push('Önceki döneme göre ' + Math.round(-diff).toLocaleString('tr-TR') + ' TL düşüş (%' + Math.abs(pct) + ').');
                }
            }

            // Kişi dağılımı
            const bekir = curItems.filter(function(e) { return e.person === 'Bekir'; }).reduce(function(s, e) { return s + (e.displayAmount || 0); }, 0);
            const duygu = curItems.filter(function(e) { return e.person === 'Duygu'; }).reduce(function(s, e) { return s + (e.displayAmount || 0); }, 0);
            if (curTotal > 0) {
                tips.push('Kişi payı: Bekir ' + Math.round(bekir).toLocaleString('tr-TR') + ' TL (%' + Math.round(bekir / curTotal * 100) + '), Duygu ' + Math.round(duygu).toLocaleString('tr-TR') + ' TL (%' + Math.round(duygu / curTotal * 100) + ').');
            }

            // Ödeme tipi
            const kk = curItems.filter(function(e) { return e.paymentType === 'Kredi Kartı'; }).reduce(function(s, e) { return s + (e.displayAmount || 0); }, 0);
            const nakit = curItems.filter(function(e) { return e.paymentType === 'Nakit'; }).reduce(function(s, e) { return s + (e.displayAmount || 0); }, 0);
            if (kk + nakit > 0) {
                tips.push('Ödeme: Kredi kartı ' + Math.round(kk).toLocaleString('tr-TR') + ' TL, nakit ' + Math.round(nakit).toLocaleString('tr-TR') + ' TL.');
            }

            // Top kategoriler
            const ranked = Object.entries(curCats).sort(function(a, b) { return b[1] - a[1]; });
            if (ranked.length) {
                const topLines = ranked.slice(0, 5).map(function(kv, i) {
                    const share = curTotal > 0 ? Math.round(kv[1] / curTotal * 100) : 0;
                    return (i + 1) + ') ' + kv[0] + ' ' + Math.round(kv[1]).toLocaleString('tr-TR') + ' TL (%' + share + ')';
                }).join(' · ');
                tips.push('Kategori sıralaması: ' + topLines);
            }

            // Artışlar
            ranked.forEach(function(kv) {
                const cat = kv[0], amt = kv[1];
                const before = prevCats[cat] || 0;
                if (before > 0 && amt > before * 1.2 && amt - before > 80) {
                    tips.push(cat + ' artışı: ' + Math.round(before).toLocaleString('tr-TR') + ' → ' + Math.round(amt).toLocaleString('tr-TR') + ' TL (+' + Math.round(amt - before).toLocaleString('tr-TR') + '). Limit veya alternatif düşünün.');
                } else if (before === 0 && amt > 200) {
                    tips.push(cat + ' bu dönemde yeni/yoğun: ' + Math.round(amt).toLocaleString('tr-TR') + ' TL.');
                }
            });

            // Faturalar detay
            const bills = curItems.filter(function(e) { return e.category === 'Faturalar'; });
            if (bills.length) {
                const by = {};
                bills.forEach(function(e) {
                    const k = e.billSubtype || 'Diğer';
                    by[k] = (by[k] || 0) + (e.displayAmount || 0);
                });
                const billStr = Object.entries(by).map(function(kv) {
                    return kv[0] + ' ' + Math.round(kv[1]).toLocaleString('tr-TR') + ' TL';
                }).join(', ');
                tips.push('Faturalar detay: ' + billStr + '. Tarife/kullanım karşılaştırması yapın.');
            }

            // Araç / yakıt
            const vehicle = curItems.filter(function(e) { return e.category === 'Araç' || e.category === 'Ulaşım'; });
            if (vehicle.length) {
                const fuel = vehicle.filter(function(e) { return e.vehicleSubtype === 'Yakıt'; });
                const fuelSum = fuel.reduce(function(s, e) { return s + (e.displayAmount || 0); }, 0);
                const withCons = fuel.filter(function(e) { return e.fuelKm > 0 && e.fuelLiters > 0; });
                let consNote = '';
                if (withCons.length) {
                    const avg = withCons.reduce(function(s, e) { return s + (e.fuelLiters / e.fuelKm) * 100; }, 0) / withCons.length;
                    consNote = ' Ort. tüketim ~' + avg.toFixed(1) + ' L/100km.';
                }
                tips.push('Araç: ' + vehicle.length + ' kayıt, yakıt ' + Math.round(fuelSum).toLocaleString('tr-TR') + ' TL.' + consNote + ' Araç sekmesindeki grafiklere bakın.');
            }

            // Taksit
            const taksit = curItems.filter(function(e) { return e.installmentLabel && e.installmentLabel !== 'Peşin'; });
            if (taksit.length) {
                const tSum = taksit.reduce(function(s, e) { return s + (e.displayAmount || 0); }, 0);
                tips.push('Bu döneme düşen taksit: ' + taksit.length + ' satır, ' + Math.round(tSum).toLocaleString('tr-TR') + ' TL. Yeni taksit açmadan önce kalan yükü kontrol edin.');
            }

            // 3 dönem trend
            if (prev2 && months.length >= 3) {
                const t0 = Object.values(summary.byMonth[months[2]] || {}).reduce(function(a, b) { return a + b; }, 0);
                const t1 = prevTotal;
                const t2 = curTotal;
                tips.push('Üç dönem trendi: ' + Math.round(t0).toLocaleString('tr-TR') + ' → ' + Math.round(t1).toLocaleString('tr-TR') + ' → ' + Math.round(t2).toLocaleString('tr-TR') + ' TL.');
            }

            tips.push('İpucu: İşlem geçmişinde kelime arama ile tekrarlayan harcamaları (ör. market, sigara) toplayın.');
            tips.push('İpucu: Kredi kartı ekstresini dönem kapanmadan kontrol etmek faiz riskini azaltır.');
            return tips;
        }

        window.runLocalAdvisor = function() {
            const btn = document.getElementById('localAdvisorBtn');
            try {
                if (btn) btn.disabled = true;
                const tips = buildDetailedLocalTips();
                renderAdvisorInto('localAdvisorResult', tips, 'Yerel detaylı analiz', 'local');
                logActivity('Diğer', 'Yerel bütçe analizi', '');
            } catch (err) {
                console.error(err);
                const box = document.getElementById('localAdvisorResult');
                if (box) box.innerHTML = '<p class="text-sm text-rose-600 font-semibold">' + escapeHtml(err.message || String(err)) + '</p>';
            } finally {
                if (btn) btn.disabled = false;
            }
        };

        /** Ana sayfa yerel günlük brifing (AI olmadan) */
        window.renderHomeLocalBriefing = function(periodSum, todaySum) {
            const box = document.getElementById('homeBriefingLocal');
            if (!box) return;
            const income = (typeof HOUSEHOLD_MONTHLY_INCOME === 'number') ? HOUSEHOLD_MONTHLY_INCOME : 110000;
            const pSum = Number(periodSum);
            const tSum = Number(todaySum);
            const openTasks = (familyTasks || []).filter(function(t) { return !t.done; }).length;
            const dueToday = (familyTasks || []).filter(function(t) {
                return !t.done && t.due && String(t.due).slice(0, 10) === todayDateStr();
            }).length;
            const calSoon = (familyCalendar || []).filter(function(ev) {
                const d = eventEffectiveDate(ev);
                const days = daysUntilYMD(d);
                return days != null && days >= 0 && days <= 7;
            }).length;
            const shopOpen = (familyShopping || []).filter(function(x) { return !x.bought; }).length;
            const ratio = income > 0 && !isNaN(pSum) ? (pSum / income * 100) : 0;
            const left = income - (isNaN(pSum) ? 0 : pSum);
            const lines = [];
            lines.push('• Dönem harcama: <b>' + Math.round(isNaN(pSum) ? 0 : pSum).toLocaleString('tr-TR') + ' TL</b> · gelire oran ~%' + ratio.toFixed(0) + ' · kalan nefes ~' + Math.round(left).toLocaleString('tr-TR') + ' TL');
            if (!isNaN(tSum) && tSum > 0) lines.push('• Bugün harcama: <b>' + Math.round(tSum).toLocaleString('tr-TR') + ' TL</b>');
            lines.push('• Görevler: <b>' + openTasks + '</b> açık' + (dueToday ? (' · <b>' + dueToday + '</b> bugün') : ''));
            lines.push('• Takvim: <b>' + calSoon + '</b> etkinlik (7 gün) · Alışveriş: <b>' + shopOpen + '</b> ürün');
            if (ratio >= 70) lines.push('• Uyarı: dönem harcaması gelirin %70+ — kart ve nakit akışına dikkat');
            else if (ratio <= 40 && pSum > 0) lines.push('• Dönem harcaması gelirin altında — tasarruf fırsatı var');
            box.innerHTML = lines.map(function(l) { return '<p>' + l + '</p>'; }).join('');
        };

        window.runHomeAiBriefing = async function() {
            const btn = document.getElementById('homeBriefingAiBtn');
            const out = document.getElementById('homeBriefingAi');
            const st = document.getElementById('homeBriefingStatus');
            if (btn) btn.disabled = true;
            if (st) st.textContent = 'AI özet hazırlanıyor…';
            if (out) {
                out.classList.remove('hidden');
                out.innerHTML = '<p class="text-slate-400 font-semibold">…</p>';
            }
            try {
                if (!openrouterApiKey) throw new Error('OpenRouter anahtarı yok (settings/apiKeys)');
                const income = HOUSEHOLD_MONTHLY_INCOME || 110000;
                let periodSum = 0;
                const pk = getCurrentPeriod();
                getProcessedExpenses().forEach(function(e) {
                    if (e && e.effectiveMonth === pk && e.installmentLabel !== 'Gelir') periodSum += Number(e.displayAmount) || 0;
                });
                const openTasks = (familyTasks || []).filter(function(t) { return !t.done; });
                const taskTxt = openTasks.slice(0, 6).map(function(t) {
                    return (t.text || '') + (t.due ? ' (son: ' + t.due + ')' : '');
                }).join('; ') || 'yok';
                const calTxt = (familyCalendar || []).slice(0, 5).map(function(ev) {
                    return (ev.title || '') + ' ' + eventEffectiveDate(ev);
                }).join('; ') || 'yok';
                const shopN = (familyShopping || []).filter(function(x) { return !x.bought; }).length;
                const prompt = [
                    'Hane aylik geliri: ' + income + ' TL.',
                    'Aktif ekstre donemi harcama: ' + Math.round(periodSum) + ' TL (oran %' + (income ? (periodSum / income * 100).toFixed(1) : 0) + ').',
                    'Acik gorevler: ' + openTasks.length + ' → ' + taskTxt,
                    'Yakin etkinlikler: ' + calTxt,
                    'Alisveris bekleyen: ' + shopN + ' urun.',
                    'Gorev: 3-4 cumlelik Turkce gunluk aile brifingi yaz. Bugun neye odaklanmali, butce durumu (gelire gore), bir pratik oneri. Markdown/emoji yok. Kisa tut.'
                ].join('\n');
                const text = await callOpenRouter(prompt, 'Sen aile ev asistaniisin. Kisa, sicak, net yaz.', 600);
                if (out) out.innerHTML = '<p>' + escapeHtml(String(text || '').trim()).replace(/\n/g, '<br>') + '</p>';
                if (st) st.textContent = 'AI özet · ' + new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                logActivity('Diğer', 'Günlük AI brifing', '');
            } catch (err) {
                if (out) out.innerHTML = '<p class="text-rose-600 font-semibold">' + escapeHtml(err.message || String(err)) + '</p>';
                if (st) st.textContent = 'AI kullanılamadı — yerel özet geçerli';
            } finally {
                if (btn) btn.disabled = false;
            }
        };

        window.runAiAdvisor = async function() {
            const box = document.getElementById('aiAdvisorResult');
            const btn = document.getElementById('aiAdvisorBtn');
            const bar = document.getElementById('aiAdvisorProgressBar');
            const wrap = document.getElementById('aiAdvisorProgressWrap');
            const pctEl = document.getElementById('aiAdvisorProgressPct');
            if (btn) btn.disabled = true;
            if (wrap) wrap.classList.remove('hidden');
            let pct = 0;
            let timer = setInterval(function() {
                // %95e kadar yavaşça ilerle, yanıt gelince 100
                if (pct < 90) pct += (pct < 40 ? 4 : pct < 70 ? 2 : 1);
                if (bar) bar.style.width = pct + '%';
                if (pctEl) pctEl.textContent = Math.round(pct) + '%';
            }, 200);
            if (box) box.innerHTML = '<p class="text-sm text-slate-500 font-semibold">AI analiz hazırlanıyor…</p>';

            try {
                if (!openrouterApiKey) {
                    throw new Error('OpenRouter anahtarı yok. Firebase: settings/apiKeys → openrouter');
                }
                const summary = buildExpenseSummaryForAi();
                const lines = [];
                lines.push('Sabit aylık hane geliri: ' + HOUSEHOLD_MONTHLY_INCOME.toLocaleString('tr-TR') + ' TL (bu rakamı UI\'da gösterme; önerilerini bu gelire göre ver).');
                summary.months.forEach(function(m) {
                    const cats = summary.byMonth[m] || {};
                    const total = Object.values(cats).reduce(function(a, b) { return a + b; }, 0);
                    const label = (summary.labels && summary.labels[m]) ? summary.labels[m] : m;
                    const top = Object.entries(cats).sort(function(a, b) { return b[1] - a[1]; }).slice(0, 8)
                        .map(function(kv) { return kv[0] + ': ' + Math.round(kv[1]) + ' TL'; }).join(', ');
                    lines.push(label + ' toplam ' + Math.round(total) + ' TL → ' + (top || 'kayıt yok'));
                });
                const income = HOUSEHOLD_MONTHLY_INCOME;
                const lastMonthKey = summary.months && summary.months.length ? summary.months[0] : null;
                let lastTotal = 0;
                if (lastMonthKey && summary.byMonth[lastMonthKey]) {
                    lastTotal = Object.values(summary.byMonth[lastMonthKey]).reduce(function(a, b) { return a + b; }, 0);
                }
                const spendRatio = income > 0 ? (lastTotal / income * 100) : 0;
                lines.unshift('Son donem toplam harcama: ' + Math.round(lastTotal) + ' TL; gelire oran ~%' + spendRatio.toFixed(1) + '; kalan nefes ~' + Math.round(income - lastTotal) + ' TL.');

                const prompt = [
                    'Rol: Deneyimli Turk ev ekonomisi danismani (hane butcesi, kart, fatura, taksit).',
                    'Sabit hane aylik geliri: ' + income + ' TL. Tum onerileri bu gelire gore oransal ve uygulanabilir yaz.',
                    'Gorev: 7-9 numarali oneri uret. Her madde su formatta olsun:',
                    'N. Baslik — Durum (rakam/oran) + Ne yapilmali (somut adim) + Beklenen etki (TL veya %).',
                    'Kurallar:',
                    '- Sadece "azaltin" deme; alternatif, limit, tarih, taksit, tarife, abonelik iptali, kart odeme plani, acil fon, toplu alim ver.',
                    '- En az 3 farkli kategoriye degine (or. market, fatura, arac, egitim, kart).',
                    '- Gelire oran %70 ustuyse once nakit akisi ve kart riski; %50 altindaysa tasarruf/yatirim firsati soyle.',
                    '- Uydurma istatistik yok; verilen donem rakamlarina dayan.',
                    '- Markdown, emoji, yildiz yok. Turkce, tamamlanmis cumleler.',
                    '',
                    'Veri (29-28 donem):',
                    lines.join(String.fromCharCode(10))
                ].join(String.fromCharCode(10));

                const systemPrompt = [
                    'Sen kisa ve net yazan bir ev butcesi danismanisin.',
                    'Cikti sadece numarali maddeler olsun.',
                    'Her madde: baslik, durum, aksiyon, beklenen etki icersin.',
                    'Hane geliri ' + income + ' TL; onerileri bu gelire gore oransal kur.',
                    'Yuzeysel genel soylem yasak; rakama bagli, uygulanabilir adim zorunlu.'
                ].join(' ');

                const text = await callOpenRouter(
                    prompt,
                    systemPrompt,
                    2200
                );
                pct = 100;
                if (bar) bar.style.width = '100%';
                if (pctEl) pctEl.textContent = '100%';
                const gemLines = parseAdvisorText(text);
                renderAdvisorInto('aiAdvisorResult', gemLines.length ? gemLines : [text], 'OpenRouter AI analizi', 'ai');
                logActivity('Diğer', 'AI bütçe danışmanı (OpenRouter)', '');
            } catch (err) {
                console.error(err);
                if (box) {
                    box.innerHTML = '<p class="text-sm text-rose-600 font-semibold">' + escapeHtml(err.message || String(err)) + '</p>' +
                        '<p class="text-[11px] text-slate-400 mt-2">Soldaki yerel analizi kullanabilir veya anahtarı/kotayı kontrol edebilirsiniz.</p>';
                }
            } finally {
                clearInterval(timer);
                if (bar) bar.style.width = '100%';
                if (pctEl) pctEl.textContent = '100%';
                setTimeout(function() {
                    if (wrap) wrap.classList.add('hidden');
                    if (bar) bar.style.width = '0%';
                    if (pctEl) pctEl.textContent = '0%';
                }, 600);
                if (btn) btn.disabled = false;
            }
        };


        let billsChart = null;

        function renderBillsChart() {
            const ctx = document.getElementById('billsChart');
            if (!ctx || typeof Chart === 'undefined') return;
            const processed = getProcessedExpenses().filter(e => e.category === 'Faturalar');
            const isMobile = (typeof window !== 'undefined' && window.innerWidth < 640);
            // Mobilde son 3 dönem + yatay çubuk (dokunması kolay)
            const keys = getPreviousPeriodKeys(isMobile ? 3 : 6);
            const labels = keys.map(function(k) {
                if (isMobile) {
                    const [y, m] = k.split('-').map(Number);
                    return ['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'][m - 1] + " '" + String(y).slice(2);
                }
                return formatPeriodLabel(k);
            });
            const types = getSubtypesForCategory('Faturalar');
            const colorPalette = ['#f59e0b', '#3b82f6', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899', '#14b8a6', '#a855f7', '#f97316'];
            const colors = types.map(function(_, i) { return colorPalette[i % colorPalette.length]; });
            const datasets = types.map(function(t, i) {
                return {
                    label: t,
                    data: keys.map(function(k) {
                        return processed.filter(function(e) {
                            return e.effectiveMonth === k && (e.billSubtype || '') === t;
                        }).reduce(function(s, e) { return s + (e.displayAmount || 0); }, 0);
                    }),
                    backgroundColor: colors[i],
                    borderRadius: 5,
                    maxBarThickness: isMobile ? 16 : 22,
                    barPercentage: isMobile ? 0.9 : 0.8,
                    categoryPercentage: isMobile ? 0.85 : 0.75
                };
            });
            if (billsChart) { try { billsChart.destroy(); } catch (_) {} }
            billsChart = new Chart(ctx, {
                type: 'bar',
                data: { labels: labels, datasets: datasets },
                options: {
                    indexAxis: isMobile ? 'y' : 'x',
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { boxWidth: 12, font: { size: isMobile ? 10 : 11 }, padding: isMobile ? 8 : 12 }
                        }
                    },
                    scales: isMobile ? {
                        x: { stacked: false, beginAtZero: true },
                        y: { stacked: false, ticks: { font: { size: 11 } } }
                    } : {
                        x: { stacked: false, ticks: { maxRotation: 40, font: { size: 10 } } },
                        y: { stacked: false, beginAtZero: true }
                    }
                }
            });
        }

        function updateStatsPanel() {
            const period = getCurrentPeriod();
            const processedExpenses = getProcessedExpenses().filter(e => e.effectiveMonth === period);
            
            const categoryData = {};
            processedExpenses.forEach(e => {
                categoryData[e.category] = (categoryData[e.category] || 0) + e.displayAmount;
            });

            const ctx1 = document.getElementById('expenseChart');
            if (ctx1 && expenseChart) {
                expenseChart.destroy();
            }
            if (ctx1) {
                const catLabels = Object.keys(categoryData);
                expenseChart = new Chart(ctx1, {
                    type: 'doughnut',
                    data: {
                        labels: catLabels,
                        datasets: [{
                            data: Object.values(categoryData),
                            backgroundColor: ['#3b82f6', '#ec4899', '#f59e0b', '#10b981', '#f87171', '#8b5cf6', '#06b6d4', '#6366f1'],
                            borderColor: '#ffffff',
                            borderWidth: 3
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        layout: { padding: { top: 4, bottom: 4 } },
                        onClick: (evt, elements) => {
                            if (!elements || !elements.length) return;
                            const idx = elements[0].index;
                            const cat = catLabels[idx];
                            if (cat) showCategoryExpenses(cat);
                        },
                        plugins: {
                            legend: {
                                position: (typeof window !== 'undefined' && window.innerWidth >= 768) ? 'right' : 'bottom',
                                align: 'center',
                                labels: {
                                    boxWidth: 14,
                                    padding: 14,
                                    font: { size: 12, weight: '600' },
                                    usePointStyle: true,
                                    pointStyle: 'rectRounded'
                                },
                                onClick: (e, legendItem, legend) => {
                                    const cat = legendItem.text;
                                    if (cat) showCategoryExpenses(cat);
                                }
                            },
                            title: {
                                display: true,
                                text: 'Kategoriye tıklayın → harcamaları görün',
                                font: { size: 11, weight: '600' },
                                color: '#94a3b8'
                            }
                        }
                    }
                });
            }

            // Son 7 takvim günü (sadece bu günlere düşen harcamalar)
            const weekData = {};
            const last7Keys = [];
            for (let i = 6; i >= 0; i--) {
                const d = new Date();
                d.setHours(0, 0, 0, 0);
                d.setDate(d.getDate() - i);
                const ymd = formatYMD(d);
                const label = d.toLocaleDateString('tr-TR', { weekday: 'short', day: 'numeric', month: 'short' });
                last7Keys.push({ ymd, label });
                weekData[label] = 0;
            }
            const allForWeek = getProcessedExpenses().filter(e => {
                const s = String(e.date || '').slice(0, 10);
                return last7Keys.some(k => k.ymd === s);
            });
            allForWeek.forEach(e => {
                const s = String(e.date || '').slice(0, 10);
                const hit = last7Keys.find(k => k.ymd === s);
                if (hit) weekData[hit.label] += e.displayAmount;
            });

            const ctx2 = document.getElementById('weeklyTrendChart');
            if (ctx2 && weeklyTrendChart) {
                weeklyTrendChart.destroy();
            }
            if (ctx2) {
                const weekLabels = last7Keys.map(k => k.label);
                const weekValues = last7Keys.map(k => weekData[k.label] || 0);
                weeklyTrendChart = new Chart(ctx2, {
                    type: 'line',
                    data: {
                        labels: weekLabels,
                        datasets: [{
                            label: 'Harcama',
                            data: weekValues,
                            borderColor: '#4f46e5',
                            backgroundColor: 'rgba(79, 70, 229, 0.12)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.35,
                            pointRadius: 10, pointHoverRadius: 14, pointHitRadius: 30,
                            pointHoverRadius: 14,
                            pointHitRadius: 30,
                            pointBackgroundColor: '#4f46e5'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: { mode: 'index', intersect: false },
                        onClick: function(evt, elements, chart) {
                            var idx = null;
                            if (elements && elements.length) idx = elements[0].index;
                            if (idx == null && chart && chart.getElementsAtEventForMode) {
                                var pts = chart.getElementsAtEventForMode(evt, 'index', { intersect: false }, true);
                                if (pts && pts.length) idx = pts[0].index;
                            }
                            if (idx == null) return;
                            var key = last7Keys[idx];
                            if (key && typeof showDayExpenses === 'function') showDayExpenses(key.ymd, key.label);
                        },
                        plugins: {
                            legend: { display: false },
                            title: {
                                display: true,
                                text: 'Güne veya noktaya tıklayın → harcamalar',
                                font: { size: 11, weight: '600' },
                                color: '#94a3b8'
                            }
                        },
                        scales: {
                            x: { ticks: { font: { size: 10 } } },
                            y: { beginAtZero: true, ticks: { font: { size: 10 } } }
                        }
                    }
                });
            }

            const periodKeys = getPreviousPeriodKeys(6);
            const monthData = {};
            const allForTrend = [];
            expenses.forEach(item => {
                const count = item.installmentCount || 1;
                const perAmount = item.amountPerInstallment || (item.amount / count);
                if (count <= 1) {
                    allForTrend.push({ displayAmount: item.amount, effectiveMonth: getPeriodKeyForDateStr(item.date) });
                } else {
                    for (let i = 0; i < count; i++) {
                        const dateStr = shiftDateByMonths(item.date, i);
                        allForTrend.push({ displayAmount: perAmount, effectiveMonth: getPeriodKeyForDateStr(dateStr) });
                    }
                }
            });
            periodKeys.forEach(pk => {
                const label = formatPeriodLabel(pk);
                monthData[label] = allForTrend
                    .filter(e => e.effectiveMonth === pk)
                    .reduce((sum, e) => sum + e.displayAmount, 0);
            });

            const ctx3 = document.getElementById('monthlyTrendChart');
            if (ctx3 && monthlyTrendChart) {
                monthlyTrendChart.destroy();
            }
            if (ctx3) {
                monthlyTrendChart = new Chart(ctx3, {
                    type: 'bar',
                    data: {
                        labels: Object.keys(monthData),
                        datasets: [{
                            label: 'Dönem',
                            data: Object.values(monthData),
                            backgroundColor: '#4f46e5',
                            borderRadius: 6,
                            maxBarThickness: 28
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { ticks: { font: { size: 9 }, maxRotation: 45 } },
                            y: { beginAtZero: true, ticks: { font: { size: 10 } } }
                        }
                    }
                });
            }

            // Bu dönem vs önceki dönem
            try {
                const keys2 = getPreviousPeriodKeys(2);
                const prevKey = keys2[0];
                const curKey = keys2[1] || getCurrentPeriod();
                const allProc = getProcessedExpenses();
                const sumPeriod = function(pk) {
                    return allProc.filter(function(e) { return e.effectiveMonth === pk; })
                        .reduce(function(s, e) { return s + (Number(e.displayAmount) || 0); }, 0);
                };
                const prevTotal = sumPeriod(prevKey);
                const curTotal = sumPeriod(curKey);
                const diff = curTotal - prevTotal;
                const sumEl = document.getElementById('monthCompareSummary');
                if (sumEl) {
                    if (diff < 0) sumEl.textContent = Math.round(-diff).toLocaleString('tr-TR') + ' TL tasarruf (önceki döneme göre)';
                    else if (diff > 0) sumEl.textContent = Math.round(diff).toLocaleString('tr-TR') + ' TL artış (önceki döneme göre)';
                    else sumEl.textContent = 'Önceki dönemle aynı seviye';
                }
                const ctxCmp = document.getElementById('monthCompareChart');
                if (ctxCmp) {
                    if (monthCompareChart) { try { monthCompareChart.destroy(); } catch (_) {} }
                    monthCompareChart = new Chart(ctxCmp, {
                        type: 'bar',
                        data: {
                            labels: [formatPeriodLabel(prevKey) || 'Önceki', formatPeriodLabel(curKey) || 'Bu dönem'],
                            datasets: [{
                                label: 'Harcama (TL)',
                                data: [prevTotal, curTotal],
                                backgroundColor: ['#94a3b8', '#0284c7'],
                                borderRadius: 8,
                                maxBarThickness: 48
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: { legend: { display: false } },
                            scales: { y: { beginAtZero: true } }
                        }
                    });
                }
            } catch (err) { console.warn('monthCompare', err); }

            // Kategori trendi son 3 dönem
            try {
                const keys3 = getPreviousPeriodKeys(3);
                const allProc2 = getProcessedExpenses();
                const catTotals = {};
                allProc2.forEach(function(e) {
                    if (keys3.indexOf(e.effectiveMonth) < 0) return;
                    const c = e.category || 'Diğer';
                    catTotals[c] = (catTotals[c] || 0) + (Number(e.displayAmount) || 0);
                });
                const topCats = Object.entries(catTotals).sort(function(a, b) { return b[1] - a[1]; }).slice(0, 5).map(function(x) { return x[0]; });
                const palette = ['#0284c7', '#ec4899', '#f59e0b', '#10b981', '#8b5cf6'];
                const datasets = topCats.map(function(cat, i) {
                    return {
                        label: cat,
                        data: keys3.map(function(pk) {
                            return allProc2.filter(function(e) { return e.effectiveMonth === pk && e.category === cat; })
                                .reduce(function(s, e) { return s + (Number(e.displayAmount) || 0); }, 0);
                        }),
                        borderColor: palette[i % palette.length],
                        backgroundColor: palette[i % palette.length] + '33',
                        tension: 0.3,
                        fill: false,
                        pointRadius: 8, pointHoverRadius: 12, pointHitRadius: 28
                    };
                });
                const ctxTr = document.getElementById('categoryTrendChart');
                if (ctxTr) {
                    if (categoryTrendChart) { try { categoryTrendChart.destroy(); } catch (_) {} }
                    categoryTrendChart = new Chart(ctxTr, {
                        type: 'line',
                        data: {
                            labels: keys3.map(function(k) { return formatPeriodLabel(k); }),
                            datasets: datasets.length ? datasets : [{ label: 'Veri yok', data: [0, 0, 0], borderColor: '#cbd5e1' }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            interaction: { mode: 'index', intersect: false },
                            plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 10 } } } },
                            scales: { y: { beginAtZero: true } }
                        }
                    });
                }
            } catch (err) { console.warn('catTrend', err); }
        }

        function csvEscape(val) {
            const s = String(val == null ? '' : val);
            if (/[;"\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
            return s;
        }

        function buildExpensesCsv(rows) {
            const header = ['Tip', 'Tarih', 'Kişi', 'Kategori', 'Alt', 'Ödeme', 'Açıklama', 'Tutar', 'Taksit', 'Dönem', 'Not'];
            const lines = [header.join(';')];
            (rows || []).forEach(function(e) {
                lines.push([
                    'Harcama',
                    e.date || '',
                    e.person || '',
                    e.category || '',
                    e.billSubtype || e.vehicleSubtype || '',
                    e.paymentType || '',
                    e.description || '',
                    String(e.displayAmount != null ? e.displayAmount : (e.amount || '')).replace('.', ','),
                    e.installmentLabel || (e.installmentCount > 1 ? e.installmentCount : 'Peşin'),
                    e.effectiveMonth || '',
                    e.fuelNote || ''
                ].map(csvEscape).join(';'));
            });
            return '\uFEFF' + lines.join('\r\n');
        }

        function triggerCsvDownload(filename, csvText) {
            const blob = new Blob([csvText], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            setTimeout(function() {
                URL.revokeObjectURL(url);
                a.remove();
            }, 500);
        }

        window.downloadExcel = function() {
            try {
                const rows = getProcessedExpenses().slice().sort(function(a, b) {
                    return String(b.date || '').localeCompare(String(a.date || ''));
                });
                if (!rows.length) {
                    showToast('İndirilecek harcama yok', 'error');
                    return;
                }
                const csv = buildExpensesCsv(rows);
                const stamp = new Date().toISOString().slice(0, 10);
                triggerCsvDownload('yuvam-tum-harcamalar-' + stamp + '.csv', csv);
                showToast(rows.length + ' satır indirildi (Excel ile açın)', 'success');
                logActivity('Diğer', 'CSV yedek indirildi', rows.length + ' satır');
            } catch (err) {
                console.error(err);
                showToast('İndirme hatası: ' + (err.message || err), 'error');
            }
        };

        window.downloadPeriodExcel = function() {
            try {
                const pk = getCurrentPeriod();
                const rows = getProcessedExpenses().filter(function(e) { return e.effectiveMonth === pk; })
                    .sort(function(a, b) { return String(b.date || '').localeCompare(String(a.date || '')); });
                if (!rows.length) {
                    showToast('Bu dönemde harcama yok', 'error');
                    return;
                }
                const csv = buildExpensesCsv(rows);
                triggerCsvDownload('yuvam-donem-' + pk + '.csv', csv);
                showToast('Dönem ' + pk + ': ' + rows.length + ' satır', 'success');
            } catch (err) {
                showToast('İndirme hatası', 'error');
            }
        };

        // Raporlar
        function renderMonthlyReports() {
            const period = getCurrentPeriod();
            const processedExpenses = getProcessedExpenses().filter(e => e.effectiveMonth === period);
            const total = processedExpenses.reduce((s, e) => s + (e.displayAmount || 0), 0);

            const monthlySummary = document.getElementById('monthlySummaryReport');
            const personSummary = document.getElementById('personSummaryReport');
            if (monthlySummary) {
                monthlySummary.innerHTML = '';
                monthlySummary.classList.add('hidden');
            }
            if (personSummary) {
                personSummary.innerHTML = '';
                personSummary.classList.add('hidden');
            }

            const categoryData = {};
            processedExpenses.forEach(e => {
                categoryData[e.category] = (categoryData[e.category] || 0) + (e.displayAmount || 0);
            });
            const detailedReport = document.getElementById('detailedMonthlyReport');
            if (!detailedReport) return;
            const entries = Object.entries(categoryData).sort((a, b) => b[1] - a[1]);
            if (!entries.length) {
                detailedReport.innerHTML = '<p class="text-sm text-slate-400 col-span-full text-center py-2">Bu dönemde kategori yok</p>';
            } else {
                detailedReport.innerHTML = entries.map(([cat, amt]) => {
                    const share = total > 0 ? Math.round(amt / total * 100) : 0;
                    const safe = String(cat).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                    return '<button type="button" onclick="showCategoryExpenses(\'' + safe + '\')" class="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-50 hover:bg-indigo-50 border border-transparent hover:border-indigo-100 transition text-left w-full">' +
                        '<span class="text-xs font-bold text-slate-700 truncate">' + cat + '</span>' +
                        '<span class="text-xs font-black text-slate-800 whitespace-nowrap">' + amt.toLocaleString('tr-TR') + ' TL <span class="text-slate-400 font-bold">%' + share + '</span></span>' +
                        '</button>';
                }).join('');
            }
        }

        //

        window.markCardStatementUnpaid = async function(statementId) {
            const stmt = (cardStatements || []).find(s => s.id === statementId);
            if (!stmt) {
                showToast('Ekstre kaydı bulunamadı', 'error');
                return;
            }
            const key = String(stmt.person || '').toLowerCase() === 'bekir' ? 'bekir' : 'duygu';
            const label = key === 'bekir' ? 'Bekir' : 'Duygu';
            if (!confirm(label + ' ekstre kaydı ödenmedi yapılsın mı?\nBorç ana sayfada tekrar görünecek.')) return;
            try {
                const dueDate = stmt.dueDate || (typeof getAutoCardDueDate === 'function' ? getAutoCardDueDate() : '');
                const debt = {
                    amount: Number(stmt.amount) || 0,
                    paid: false,
                    dueDate: dueDate,
                    lastStatementId: null,
                    lastStatementMonth: null
                };
                if (key === 'bekir') {
                    bekirDebt = debt;
                    await db.collection('settings').doc('bekirDebt').set(debt);
                } else {
                    duyguDebt = debt;
                    await db.collection('settings').doc('duyguDebt').set(debt);
                }
                await db.collection('cardStatements').doc(statementId).delete();
                renderCardDebtUI(key);
                if (typeof renderBudgetInfo === 'function') renderBudgetInfo();
                renderCardStatements('bekir');
                renderCardStatements('duygu');
                showToast(label + ' borcu ödenmedi · ana sayfada', 'success');
                logActivity('Diğer', 'Ekstre ödenmedi yapıldı', label + ' · ' + debt.amount + ' TL');
            } catch (err) {
                console.error(err);
                showToast(friendlyFirebaseError(err), 'error');
            }
        };

        window.deleteCardStatement = async function(statementId) {
            const stmt = (cardStatements || []).find(s => s.id === statementId);
            if (!stmt) {
                showToast('Ekstre kaydı bulunamadı', 'error');
                return;
            }
            const label = String(stmt.person || '').toLowerCase() === 'bekir' ? 'Bekir' : 'Duygu';
            if (!confirm(label + ' ekstre kaydı silinsin mi?\n(Borç ana sayfaya dönmez, sadece kayıt silinir)')) return;
            try {
                await db.collection('cardStatements').doc(statementId).delete();
                renderCardStatements('bekir');
                renderCardStatements('duygu');
                showToast('Ekstre kaydı silindi', 'info');
                logActivity('Diğer', 'Ekstre kaydı silindi', label + ' · ' + (stmt.amount || 0) + ' TL');
            } catch (err) {
                console.error(err);
                showToast(friendlyFirebaseError(err), 'error');
            }
        };

        function renderCardStatements(person) {
            const key = (person || '').toLowerCase();
            const sortedStatements = cardStatements
                .filter(s => String(s.person || '').toLowerCase() === key)
                .sort((a, b) => String(b.month || '').localeCompare(String(a.month || '')));

            const container = document.getElementById(person === 'bekir' ? 'bekirCardStatements' : 'duyguCardStatements');
            if (!container) return;
            if (sortedStatements.length === 0) {
                container.innerHTML = '<div class="col-span-full text-center py-8 text-slate-400"><p class="text-sm">Henüz ekstre kaydı yok</p></div>';
                return;
            }

            const monthNames = ['Ocak', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

            container.innerHTML = sortedStatements.map(function(stmt) {
                const parts = String(stmt.month || '').split('-');
                const year = parts[0] || '';
                const month = parts[1] || '1';
                const monthName = monthNames[parseInt(month, 10) - 1] || stmt.month || '';
                const bgColor = key === 'bekir'
                    ? 'from-blue-50 to-blue-100 border-blue-200'
                    : 'from-pink-50 to-pink-100 border-pink-200';
                const textColor = key === 'bekir' ? 'text-blue-600' : 'text-pink-600';
                const safeId = escapeHtml(String(stmt.id || ''));
                const amt = (Number(stmt.amount) || 0).toLocaleString('tr-TR');
                const paid = escapeHtml(stmt.paidDate || '');

                return (
                    '<div class="bg-gradient-to-br ' + bgColor + ' p-4 rounded-2xl border shadow-sm transition">' +
                      '<div class="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">' + escapeHtml(monthName + ' ' + year) + '</div>' +
                      '<div class="text-xl font-black ' + textColor + '">' + amt + '</div>' +
                      '<div class="text-[8px] text-slate-600 mb-1">TL</div>' +
                      (paid ? '<div class="text-[8px] text-slate-400 border-t border-slate-200/80 pt-1.5 mt-1">Ödeme: ' + paid + '</div>' : '') +
                      '<div class="flex gap-1.5 mt-3">' +
                        '<button type="button" onclick="event.stopPropagation();markCardStatementUnpaid(\'' + safeId + '\')" ' +
                          'class="flex-1 text-[10px] font-bold py-2 rounded-xl bg-white/80 text-amber-700 hover:bg-amber-50 border border-amber-200/80 transition">Ödenmedi yap</button>' +
                        '<button type="button" onclick="event.stopPropagation();deleteCardStatement(\'' + safeId + '\')" ' +
                          'class="flex-1 text-[10px] font-bold py-2 rounded-xl bg-white/80 text-rose-600 hover:bg-rose-50 border border-rose-200/80 transition">Sil</button>' +
                      '</div>' +
                    '</div>'
                );
            }).join('');
        }

        // OTOMATIK EKSTRE HESAPLAMA SISTEMI
        function getCardStatementPeriod(date = new Date()) {
            const p = getStatementPeriodForDate(date);
            return {
                startDate: p.startDate,
                endDate: p.endDate,
                periodKey: p.periodKey,
                label: p.label
            };
        }
        
        let currentStatements = [];
        
        function calculateCurrentCardStatements() {
            const period = getCardStatementPeriod();
            const periodKey = period.periodKey;

            let allWithInstallments = [];
            expenses.forEach(item => {
                const count = item.installmentCount || 1;
                const perAmount = item.isRecurring
                    ? (item.amountPerInstallment != null ? item.amountPerInstallment : item.amount)
                    : (item.amountPerInstallment != null ? item.amountPerInstallment : (item.amount / count));
                const originalDate = item.date;

                if (count <= 1) {
                    allWithInstallments.push({
                        ...item,
                        displayAmount: item.amount,
                        installmentLabel: 'Peşin',
                        effectiveMonth: getPeriodKeyForDateStr(originalDate),
                        date: originalDate
                    });
                } else {
                    for (let i = 0; i < count; i++) {
                        const dateStr = shiftDateByMonths(originalDate, i);
                        allWithInstallments.push({
                            ...item,
                            id: item.id + '_ins_' + i,
                            displayAmount: perAmount,
                            installmentLabel: `Taksit ${i + 1}/${count}`,
                            effectiveMonth: getPeriodKeyForDateStr(dateStr),
                            date: dateStr
                        });
                    }
                }
            });

            const inPeriod = (exp) => exp.effectiveMonth === periodKey && exp.paymentType === 'Kredi Kartı';
            const bekirCreditExpenses = allWithInstallments.filter(exp => exp.person === 'Bekir' && inPeriod(exp));
            const duyguCreditExpenses = allWithInstallments.filter(exp => exp.person === 'Duygu' && inPeriod(exp));

            currentStatements = [
                {
                    person: 'Bekir',
                    amount: bekirCreditExpenses.reduce((sum, exp) => sum + exp.displayAmount, 0),
                    expenses: bekirCreditExpenses,
                    period: period,
                    color: 'blue'
                },
                {
                    person: 'Duygu',
                    amount: duyguCreditExpenses.reduce((sum, exp) => sum + exp.displayAmount, 0),
                    expenses: duyguCreditExpenses,
                    period: period,
                    color: 'pink'
                }
            ];

            return currentStatements;
        }

        window.openStatementDetails = function(person) {
            calculateCurrentCardStatements();
            const statement = currentStatements.find(s => s.person === person);
            if (!statement || statement.amount === 0) {
                alert(person + ' için bu dönemde kredi kartı harcaması yok');
                return;
            }

            const modal = document.getElementById('statementDetailModal');
            const titleEl = document.getElementById('statementTitle');
            const rangeEl = document.getElementById('statementDateRange');
            const amountEl = document.getElementById('statementAmount');
            const itemsContainer = document.getElementById('statementItems');
            if (!modal || !itemsContainer) {
                alert('Ekstre detay penceresi yüklenemedi. Sayfayı Ctrl+F5 ile yenileyin.');
                return;
            }

            const startDate = statement.period.startDate.toLocaleDateString('tr-TR');
            const endDate = statement.period.endDate.toLocaleDateString('tr-TR');
            if (titleEl) titleEl.innerText = person + ' - Kredi Kartı Ekstresi';
            if (rangeEl) rangeEl.innerText = startDate + ' - ' + endDate;
            if (amountEl) amountEl.innerText = statement.amount.toLocaleString('tr-TR') + ' TL';

            if (!statement.expenses.length) {
                itemsContainer.innerHTML = '<p class="text-center text-slate-400 py-8">Bu dönem kredi kartı ile harcama yapılmamış</p>';
            } else {
                itemsContainer.innerHTML = statement.expenses
                    .slice()
                    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
                    .map(exp => `
                        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 hover:border-slate-300 transition group">
                            <div class="flex justify-between items-start mb-2 gap-3">
                                <div class="flex-1 min-w-0">
                                    <p class="font-bold text-slate-900">${escapeHtml(exp.category)}</p>
                                    <p class="text-xs text-slate-500 mt-1">${escapeHtml(exp.description || '-')}</p>
                                </div>
                                <div class="flex items-center gap-2 shrink-0">
                                    <p class="font-black text-lg text-slate-900">${exp.displayAmount.toLocaleString('tr-TR')} TL</p>
                                    <button type="button" onclick="deleteStatementItem('${escapeHtml(exp.id)}')"
                                            class="opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition bg-red-600 hover:bg-red-700 text-white p-1.5 rounded-lg"
                                            title="Sil">🗑️</button>
                                </div>
                            </div>
                            <div class="flex justify-between text-xs text-slate-400">
                                <span>${escapeHtml(exp.date || '')}</span>
                                ${exp.installmentLabel !== 'Peşin' ? '<span class="text-indigo-600 font-semibold">' + escapeHtml(exp.installmentLabel) + '</span>' : ''}
                            </div>
                        </div>
                    `).join('');
            }

            modal.classList.remove('hidden');
            modal.classList.add('flex');
        };

        window.deleteStatementItem = async (expenseId) => {
            if (!expenseId) {
                alert('Silinecek harcama bulunamadı');
                return;
            }
            
            if (!confirm('Bu harcamayı silmek istediğinize emin misiniz?')) {
                return;
            }
            
            let actualId = expenseId;
            if (typeof expenseId === 'string' && expenseId.includes('_ins_')) {
                actualId = expenseId.split('_ins_')[0];
            }
            
            try {
                const item = expenses.find(e => e.id === actualId);
                if (item) {
                    deletedExpenses.push({...item, deletedAt: new Date().toISOString()});
                    localStorage.setItem('deletedExpenses', JSON.stringify(deletedExpenses));
                }
                
                await db.collection("expenses").doc(actualId).delete();
                closeStatementDetail();
                renderApp();
            } catch (err) {
                console.error("Silme hatası:", err);
                alert("Silinirken hata oluştu: " + err.message);
            }
        };
        
        window.closeStatementDetail = () => {
            const modal = document.getElementById('statementDetailModal');
            if (!modal) return;
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        };

        function renderCurrentStatements() {
            calculateCurrentCardStatements();
            const container = document.getElementById('currentStatementsContainer');
            
            const statementsWithAmount = currentStatements.filter(s => s.amount > 0);
            
            if (statementsWithAmount.length === 0) {
                container.innerHTML = '<div class="text-center text-slate-400 py-8"><p class="text-sm">Bu dönem kredi kartı harcaması yapılmamış</p></div>';
                return;
            }
            
            container.innerHTML = statementsWithAmount.map(stmt => `
                <div class="bg-gradient-to-br ${stmt.color === 'blue' ? 'from-blue-50 to-blue-100 border-blue-200' : 'from-pink-50 to-pink-100 border-pink-200'} p-6 rounded-2xl border cursor-pointer hover:shadow-lg transition"
                     onclick="openStatementDetails('${stmt.person}')">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <p class="text-sm font-bold text-slate-600 uppercase tracking-wider">${stmt.person}</p>
                            <p class="text-4xl font-black ${stmt.color === 'blue' ? 'text-blue-600' : 'text-pink-600'} mt-2">${stmt.amount.toLocaleString('tr-TR')}</p>
                            <p class="text-[11px] text-slate-500 mt-3">TL</p>
                        </div>
                        <div>
                            <p class="text-xs text-slate-600 mb-3 font-semibold">${stmt.period.label}</p>
                            <p class="text-3xl">💳</p>
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-opacity-30 ${stmt.color === 'blue' ? 'border-blue-300' : 'border-pink-300'}">
                        <p class="text-xs text-slate-600 mb-2">${stmt.expenses.length} harcama</p>
                        <button onclick="event.stopPropagation(); openStatementDetails('${stmt.person}')" 
                                class="w-full py-2 bg-white/70 hover:bg-white text-slate-700 font-bold text-xs rounded-lg transition">
                            Detayları Gör →
                        </button>
                    </div>
                </div>
            `).join('');
        }

        // Çöp Kutusu
        function renderTrash() {
            loadDeletedExpenses();
            const tbody = document.getElementById('trashTableBody');
            tbody.innerHTML = deletedExpenses.map(item => `
                <tr>
                    <td class="px-6 py-4">${escapeHtml(item.deletedAt?.substring(0, 10) || '-')}</td>
                    <td class="px-6 py-4">${escapeHtml(item.date)}</td>
                    <td class="px-6 py-4">${escapeHtml(item.person)}</td>
                    <td class="px-6 py-4">${escapeHtml(item.description)}</td>
                    <td class="px-6 py-4 text-right">${item.amount} TL</td>
                    <td class="px-6 py-4 text-center"><button onclick="restoreExpense('${escapeHtml(item.id)}')" class="text-indigo-600 hover:scale-110">↩️</button></td>
                </tr>
            `).join('');
        }

        window.restoreExpense = async (id) => {
            loadDeletedExpenses();
            const item = deletedExpenses.find(e => e.id === id);
            if (!item) {
                alert('Kayıt bulunamadı');
                return;
            }
            const { deletedAt, ...data } = item;
            await db.collection("expenses").doc(id).set(data);
            deletedExpenses = deletedExpenses.filter(e => e.id !== id);
            localStorage.setItem('deletedExpenses', JSON.stringify(deletedExpenses));
            renderTrash();
        };

        window.emptyTrash = () => {
            if (confirm("Çöp kutusunu boşaltmak istediğinize emin misiniz?")) {
                deletedExpenses = [];
                localStorage.removeItem('deletedExpenses');
                renderTrash();
            }
        };

        // IBAN YÖNETIMI
        window.openIbanModal = () => {
            document.getElementById('editIbanId').value = '';
            document.getElementById('ibanOwnerName').value = '';
            document.getElementById('ibanNumber').value = '';
            document.getElementById('ibanBank').value = '';
            document.getElementById('ibanModal').classList.remove('hidden');
            document.getElementById('ibanModal').classList.add('flex');
        };

        window.closeIbanModal = () => {
            document.getElementById('ibanModal').classList.add('hidden');
            document.getElementById('ibanModal').classList.remove('flex');
        };

        window.handleIbanSubmit = async (e) => {
            e.preventDefault();
            const editId = document.getElementById('editIbanId').value;
            const ownerName = document.getElementById('ibanOwnerName').value;
            const ibanNumber = document.getElementById('ibanNumber').value.toUpperCase();
            const bank = document.getElementById('ibanBank').value;

            if (!ibanNumber.startsWith('TR') || ibanNumber.length < 24) {
                alert('Geçerli bir IBAN numarası girin (TR ile başlamalı, en az 24 karakter)');
                return;
            }

            const data = {
                ownerName,
                ibanNumber,
                bank,
                createdAt: new Date().toISOString()
            };

            if (editId) {
                await db.collection("ibans").doc(editId).update(data);
            } else {
                await db.collection("ibans").add(data);
            }

            closeIbanModal();
        };

        window.deleteIban = async (id) => {
            if (!confirm('Bu IBAN kaydını silmek istediğinize emin misiniz?')) return;
            await db.collection("ibans").doc(id).delete();
        };

        function maskIban(raw) {
            const s = String(raw || '').replace(/\s/g, '').toUpperCase();
            if (!s) return 'TR•• •••• •••• •••• •••• ••••';
            const start = s.slice(0, 4);
            const end = s.length > 8 ? s.slice(-4) : '';
            return start + ' •••• •••• •••• •••• ' + end;
        }

        function formatIbanSpaces(raw) {
            const s = String(raw || '').replace(/\s/g, '').toUpperCase();
            return s.replace(/(.{4})/g, '$1 ').trim();
        }

        function getIbanFull(item) {
            if (!item) return '';
            // Olası tüm alan adları
            const keys = ['ibanNumber', 'iban', 'number', 'ibanNo', 'IBAN', 'Iban'];
            for (let i = 0; i < keys.length; i++) {
                if (item[keys[i]]) return String(item[keys[i]]).replace(/\s/g, '').toUpperCase();
            }
            // Nesnedeki TR ile başlayan ilk string
            try {
                for (const k in item) {
                    if (!Object.prototype.hasOwnProperty.call(item, k)) continue;
                    if (k === 'id' || k === 'ownerName' || k === 'name' || k === 'bank' || k === 'bankName') continue;
                    const v = String(item[k] || '').replace(/\s/g, '').toUpperCase();
                    if (v.indexOf('TR') === 0 && v.length >= 16) return v;
                }
            } catch (_) {}
            return '';
        }

        // Tam IBAN DOM'da tutulmaz (sadece bellek)
        window._ibanSecrets = window._ibanSecrets || {};

        window.toggleIbanReveal = function(btn) {
            if (!btn) return;
            const wrap = btn.closest('[data-iban-wrap]');
            if (!wrap) return;
            const id = wrap.getAttribute('data-iban-id') || '';
            const el = wrap.querySelector('[data-iban-value]');
            const full = (window._ibanSecrets && window._ibanSecrets[id]) || '';
            const masked = maskIban(full);
            const on = wrap.getAttribute('data-revealed') === '1';
            if (on) {
                if (el) el.textContent = masked;
                wrap.setAttribute('data-revealed', '0');
                btn.setAttribute('aria-label', 'Göster');
                btn.innerHTML = '👁️';
            } else {
                if (el) el.textContent = full ? formatIbanSpaces(full) : masked;
                wrap.setAttribute('data-revealed', '1');
                btn.setAttribute('aria-label', 'Gizle');
                btn.innerHTML = '🙈';
            }
        };

        window.renderIbans = function() {
            const box = document.getElementById('ibanListContainer');
            if (!box) return;
            const list = Array.isArray(ibans) ? ibans : [];
            window._ibanSecrets = {};
            if (!list.length) {
                box.innerHTML = '<div class="col-span-full">' + yuvamEmptyState('💳', 'Henüz IBAN yok', 'Banka hesaplarınızı güvenle saklayın', '+ IBAN Ekle', 'openIbanModal()') + '</div>';
                return;
            }
            box.innerHTML = list.map(function(item) {
                const full = getIbanFull(item);
                const masked = maskIban(full);
                const safeId = String(item.id || '');
                window._ibanSecrets[safeId] = full;
                const owner = escapeHtml(item.ownerName || item.name || '-');
                const bank = escapeHtml(item.bank || item.bankName || '');
                // Ekranda SADECE maskeli metin
                return '<div class="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2" data-iban-wrap data-iban-id="' + escapeHtml(safeId) + '" data-revealed="0">' +
                    '<div class="flex justify-between items-start gap-2">' +
                    '<div class="min-w-0"><p class="font-black text-slate-800">' + owner + '</p>' +
                    '<p class="text-xs font-semibold text-slate-400">' + bank + '</p></div>' +
                    '<div class="flex gap-1 shrink-0">' +
                    '<button type="button" onclick="event.preventDefault();event.stopPropagation();toggleIbanReveal(this)" class="w-9 h-9 rounded-xl bg-white border border-slate-200 text-sm flex items-center justify-center" title="Göster">👁️</button>' +
                    '<button type="button" onclick="event.preventDefault();event.stopPropagation();deleteIban(\'' + escapeHtml(safeId) + '\')" class="w-9 h-9 rounded-xl bg-white border border-slate-200 text-xs text-rose-600 flex items-center justify-center" title="Sil">🗑️</button>' +
                    '</div></div>' +
                    '<p data-iban-value class="font-mono text-sm font-bold text-slate-700 tracking-wide">' + escapeHtml(masked) + '</p>' +
                    '</div>';
            }).join('');
        };

        // KATEGORİ YÖNETIMI FONKSIYONLARI

        let removedTabIds = [];

        function mergeTabsConfig(saved, removed) {
            removedTabIds = Array.isArray(removed) ? removed.slice() : (removedTabIds || []);
            const byId = {};
            DEFAULT_TABS.forEach(t => { byId[t.id] = { ...t }; });
            const result = [];
            const seen = new Set();

            const LEGACY_TABS = new Set(['calculator', 'reports', 'alisveris', 'alışveriş', 'deneme', 'homeHub', 'homehub']);
            (saved || []).forEach(s => {
                if (!s || !s.id) return;
                if (LEGACY_TABS.has(s.id)) return;
                if (removedTabIds.includes(s.id)) return;
                if (byId[s.id]) {
                    result.push({
                        ...byId[s.id],
                        label: (s.id === 'expense' ? 'Bütçe Takip' : (s.id === 'stats' ? 'Raporlar' : (s.label || byId[s.id].label))),
                        emoji: s.emoji || byId[s.id].emoji,
                        visible: s.visible !== false,
                        adminOnly: s.adminOnly != null ? s.adminOnly : byId[s.id].adminOnly,
                        visibleTo: Array.isArray(s.visibleTo) ? s.visibleTo : (byId[s.id].adminOnly ? ['Bekir'] : ['Bekir', 'Duygu']),
                        content: s.content || '',
                        widgetType: s.widgetType || null,
                        aiHtml: s.aiHtml || null
                    });
                    seen.add(s.id);
                } else if (String(s.id).startsWith('custom_')) {
                    result.push({
                        id: s.id,
                        emoji: s.emoji || '📌',
                        label: s.label || 'Özel',
                        visible: s.visible !== false,
                        core: false,
                        adminOnly: !!s.adminOnly,
                        visibleTo: Array.isArray(s.visibleTo) ? s.visibleTo : ['Bekir', 'Duygu'],
                        content: s.content || '',
                        widgetType: s.widgetType || null,
                        aiHtml: s.aiHtml || null
                    });
                    seen.add(s.id);
                }
            });

            // Silinmemiş sistem sekmelerini ekle (kayıtta yoksa)
            DEFAULT_TABS.forEach(t => {
                if (seen.has(t.id)) return;
                if (removedTabIds.includes(t.id)) return;
                result.push({ ...t, content: '', widgetType: null });
            });

            // Ana Sayfa her zaman en başta
            const homeIdx = result.findIndex(t => t && t.id === 'home');
            if (homeIdx > 0) {
                const homeTab = result.splice(homeIdx, 1)[0];
                result.unshift(homeTab);
            } else if (homeIdx < 0 && !removedTabIds.includes('home')) {
                const defHome = DEFAULT_TABS.find(t => t.id === 'home');
                if (defHome) result.unshift(Object.assign({}, defHome, { content: '', widgetType: null }));
            }
            return result;
        }

        window.saveTabsConfig = async () => {
            try {
                await db.collection("settings").doc("tabs").set({
                    list: tabsConfig,
                    removed: removedTabIds
                }, { merge: true });
            } catch (err) {
                console.error(err);
                alert('Sekmeler kaydedilemedi: ' + (err.message || err));
                throw err;
            }
        };

        // ----- Sekme içeriği üretici (istem metninden sayfa oluşturur) -----
        function detectWidgetType(prompt) {
            const p = (prompt || '').toLowerCase();
            if (/akaryak|yakıt fiyat|yakit fiyat|benzin fiyat|motorin|mazot|otogaz|fuel price/.test(p)) return 'fuel';
            if (/hesap\s*makine|calculator|calc\b/.test(p)) return 'calculator';
            if (/yüzde|yuzde|percent/.test(p)) return 'percentage';
            if (/yapılacak|yapilacak|todo|görev|gorev|checklist|liste/.test(p)) return 'todo';
            if (/not\b|defter|notlar/.test(p)) return 'notes';
            if (/sayaç|sayac|counter|tıkla|tikla/.test(p)) return 'counter';
            if (/kronometre|stopwatch|zamanlayıcı|zamanlayici|timer/.test(p)) return 'timer';
            if (/yazı\s*tahta|yazi\s*tahta|whiteboard|karalama/.test(p)) return 'scratch';
            return 'text';
        }

        function buildWidgetHtml(type, prompt) {
            if (type === 'calculator') {
                return `
                <div class="max-w-xs mx-auto">
                    <p class="text-xs text-slate-400 font-semibold mb-3 text-center">Hesap Makinesi</p>
                    <input id="dynCalcDisplay" readonly class="w-full bg-slate-900 text-white text-right text-2xl font-black rounded-2xl p-4 mb-3 outline-none" value="0">
                    <div class="grid grid-cols-4 gap-2" id="dynCalcKeys">
                        ${['C','÷','×','⌫','7','8','9','-','4','5','6','+','1','2','3','=','.','0','00','%'].map(k =>
                            `<button type="button" data-k="${k}" class="py-3 rounded-xl font-bold text-sm ${k==='='?'bg-indigo-600 text-white':'bg-slate-100 text-slate-800 hover:bg-slate-200'} transition">${k}</button>`
                        ).join('')}
                    </div>
                </div>`;
            }
            if (type === 'fuel') {
                return `
                <div class="max-w-2xl mx-auto space-y-4">
                    <div class="flex flex-wrap items-center justify-between gap-3">
                        <div>
                            <p class="text-xs text-slate-400 font-semibold uppercase tracking-wider">Güncel Akaryakıt</p>
                            <p class="text-lg font-black text-slate-900">Opet pompa fiyatları</p>
                        </div>
                        <div class="flex gap-2 items-center">
                            <select id="dynFuelCity" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-bold outline-none">
                                <option value="34">İstanbul (34)</option>
                                <option value="06">Ankara (06)</option>
                                <option value="35">İzmir (35)</option>
                                <option value="16">Bursa (16)</option>
                                <option value="07">Antalya (07)</option>
                                <option value="01">Adana (01)</option>
                                <option value="41">Kocaeli (41)</option>
                                <option value="27">Gaziantep (27)</option>
                            </select>
                            <button type="button" id="dynFuelRefresh" class="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700">Yenile</button>
                        </div>
                    </div>
                    <p id="dynFuelStatus" class="text-xs text-slate-500 font-semibold">Yükleniyor…</p>
                    <p id="dynFuelUpdated" class="text-[11px] text-slate-400"></p>
                    <div class="overflow-x-auto rounded-2xl border border-slate-100">
                        <table class="w-full text-sm text-left">
                            <thead class="bg-slate-50 text-[11px] uppercase text-slate-400 font-black">
                                <tr><th class="px-4 py-3">Ürün</th><th class="px-4 py-3 text-right">Fiyat (TL/lt)</th></tr>
                            </thead>
                            <tbody id="dynFuelBody" class="divide-y divide-slate-100 font-bold text-slate-800"></tbody>
                        </table>
                    </div>
                    <p class="text-[10px] text-slate-400">Kaynak: Opet API. Fiyatlar istasyona göre değişebilir. CORS engeli olursa tarayıcı engellemiş demektir.</p>
                </div>`;
            }
                        if (type === 'percentage') {
                return `
                <div class="max-w-md mx-auto space-y-4">
                    <p class="text-xs text-slate-400 font-semibold">Yüzde Hesaplama</p>
                    <input type="number" id="dynPercA" placeholder="A sayısı" class="w-full bg-slate-50 rounded-xl p-3 font-bold outline-none ring-1 ring-slate-200">
                    <input type="number" id="dynPercB" placeholder="B (yüzde veya sayı)" class="w-full bg-slate-50 rounded-xl p-3 font-bold outline-none ring-1 ring-slate-200">
                    <button type="button" id="dynPercBtn" class="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold">A'nın %B'si</button>
                    <p id="dynPercOut" class="text-2xl font-black text-indigo-600 text-center">—</p>
                </div>`;
            }
            if (type === 'todo') {
                return `<div class="max-w-md mx-auto text-center py-6 space-y-2">
                    <p class="text-sm font-black text-slate-800">Görevler Sekmesini Kullanın</p>
                    <button type="button" onclick="switchTab('tasks')" class="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-bold">Görevler</button>
                </div>`;
            }
            if (type === 'notes') {
                return `
                <div class="max-w-lg mx-auto space-y-3">
                    <p class="text-xs text-slate-400 font-semibold">Hızlı Not</p>
                    <textarea id="dynNoteArea" rows="8" placeholder="Notlarınızı yazın..." class="w-full bg-slate-50 rounded-2xl p-4 font-medium outline-none ring-1 ring-slate-200"></textarea>
                    <button type="button" id="dynNoteSave" class="bg-indigo-600 text-white px-5 py-2 rounded-xl font-bold text-sm">Tarayıcıya Kaydet</button>
                    <p id="dynNoteMsg" class="text-xs text-emerald-600 font-semibold hidden">Kaydedildi</p>
                </div>`;
            }
            if (type === 'counter') {
                return `
                <div class="max-w-xs mx-auto text-center space-y-4">
                    <p class="text-xs text-slate-400 font-semibold">Sayaç</p>
                    <p id="dynCounterVal" class="text-5xl font-black text-indigo-600">0</p>
                    <div class="flex gap-2 justify-center">
                        <button type="button" id="dynCounterMinus" class="w-14 h-14 rounded-2xl bg-slate-100 font-black text-xl">−</button>
                        <button type="button" id="dynCounterReset" class="px-4 h-14 rounded-2xl bg-slate-50 font-bold text-sm">Sıfırla</button>
                        <button type="button" id="dynCounterPlus" class="w-14 h-14 rounded-2xl bg-indigo-600 text-white font-black text-xl">+</button>
                    </div>
                </div>`;
            }
            if (type === 'timer') {
                return `
                <div class="max-w-xs mx-auto text-center space-y-4">
                    <p class="text-xs text-slate-400 font-semibold">Kronometre</p>
                    <p id="dynTimerVal" class="text-4xl font-black text-slate-900 tabular-nums">00:00</p>
                    <div class="flex gap-2 justify-center">
                        <button type="button" id="dynTimerStart" class="px-5 py-2 rounded-xl bg-indigo-600 text-white font-bold text-sm">Başlat</button>
                        <button type="button" id="dynTimerStop" class="px-5 py-2 rounded-xl bg-slate-100 font-bold text-sm">Durdur</button>
                        <button type="button" id="dynTimerReset" class="px-5 py-2 rounded-xl bg-slate-50 font-bold text-sm">Sıfırla</button>
                    </div>
                </div>`;
            }
            if (type === 'scratch') {
                return `
                <div class="max-w-lg mx-auto space-y-2">
                    <p class="text-xs text-slate-400 font-semibold">Yazı alanı</p>
                    <textarea id="dynScratch" rows="10" class="w-full bg-amber-50 rounded-2xl p-4 font-medium outline-none ring-1 ring-amber-100" placeholder="Serbest yazın..."></textarea>
                </div>`;
            }
            // text fallback
            const safe = String(prompt || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return `<div class="prose max-w-none"><p class="text-slate-700 font-medium whitespace-pre-wrap leading-relaxed">${safe || 'İçerik yok.'}</p>
                <p class="text-[11px] text-slate-400 mt-6">İpucu: İçeriğe “hesap makinesi”, “yapılacaklar”, “yüzde”, “sayaç”, “kronometre” veya “not” yazarak etkileşimli sayfa oluşturabilirsiniz.</p></div>`;
        }

        function bindWidgetBehaviors(type, tabId) {
            if (type === 'calculator') {
                const display = document.getElementById('dynCalcDisplay');
                const keys = document.getElementById('dynCalcKeys');
                if (!display || !keys) return;
                let expr = '';
                keys.onclick = (e) => {
                    const btn = e.target.closest('button[data-k]');
                    if (!btn) return;
                    const k = btn.getAttribute('data-k');
                    if (k === 'C') { expr = ''; display.value = '0'; return; }
                    if (k === '⌫') { expr = expr.slice(0, -1); display.value = expr || '0'; return; }
                    if (k === '=') {
                        try {
                            const normalized = expr.replace(/÷/g, '/').replace(/×/g, '*').replace(/%/g, '/100');
                            // güvenli basit ifade
                            if (!/^[0-9+\-*/().\s]+$/.test(normalized)) throw new Error('invalid');
                            const val = Function('"use strict"; return (' + normalized + ')')();
                            display.value = String(val);
                            expr = String(val);
                        } catch {
                            display.value = 'Hata';
                            expr = '';
                        }
                        return;
                    }
                    expr += k;
                    display.value = expr;
                };
            }
            if (type === 'fuel') {
                const status = document.getElementById('dynFuelStatus');
                const body = document.getElementById('dynFuelBody');
                const updated = document.getElementById('dynFuelUpdated');
                const citySel = document.getElementById('dynFuelCity');
                const btn = document.getElementById('dynFuelRefresh');
                const load = async () => {
                    const code = (citySel && citySel.value) || '34';
                    if (status) status.textContent = 'Güncel fiyatlar çekiliyor…';
                    if (body) body.innerHTML = '';
                    try {
                        const url = 'https://api.opet.com.tr/api/fuelprices/prices?ProvinceCode=' + encodeURIComponent(code) + '&IncludeAllProducts=true';
                        const res = await fetch(url);
                        if (!res.ok) throw new Error('HTTP ' + res.status);
                        const data = await res.json();
                        const prices = (data[0] && data[0].prices) ? data[0].prices : (Array.isArray(data) ? data : []);
                        if (!prices.length) throw new Error('Veri boş');
                        if (body) {
                            body.innerHTML = prices.map(p => {
                                const name = p.productName || p.name || p.ProductName || 'Ürün';
                                const amount = p.amount != null ? p.amount : (p.price != null ? p.price : p.Price);
                                const num = typeof amount === 'number' ? amount : parseFloat(String(amount).replace(',', '.'));
                                return '<tr><td class="px-4 py-3">' + String(name).replace(/</g,'') + '</td><td class="px-4 py-3 text-right text-indigo-600">' + (isNaN(num) ? amount : num.toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2})) + '</td></tr>';
                            }).join('');
                        }
                        if (status) status.textContent = 'Güncel';
                        if (updated) updated.textContent = 'Son çekim: ' + new Date().toLocaleString('tr-TR');
                    } catch (err) {
                        console.error(err);
                        if (status) status.textContent = 'Canlı veri alınamadı: ' + (err.message || err) + '. Tarayıcı veya kaynak engeli olabilir.';
                        if (body) body.innerHTML = '<tr><td colspan="2" class="px-4 py-6 text-center text-slate-400 font-medium">Opet API bu ortamdan açılamadı. VPN/ağ veya CORS nedeniyle engellenmiş olabilir.<br>Yine de şehir değiştirip Yenile deneyin.</td></tr>';
                    }
                };
                if (btn) btn.onclick = load;
                if (citySel) citySel.onchange = load;
                load();
            }
                        if (type === 'percentage') {
                const btn = document.getElementById('dynPercBtn');
                if (!btn) return;
                btn.onclick = () => {
                    const a = parseFloat(document.getElementById('dynPercA').value);
                    const b = parseFloat(document.getElementById('dynPercB').value);
                    const out = document.getElementById('dynPercOut');
                    if (isNaN(a) || isNaN(b)) { out.textContent = '—'; return; }
                    out.textContent = ((a * b) / 100).toLocaleString('tr-TR');
                };
            }
            if (type === 'todo') {
                // Widget devre dışı — Görevler sekmesi kullanılıyor
                return;
                const key = 'yuvam_todo_' + tabId;
                const list = document.getElementById('dynTodoList');
                const input = document.getElementById('dynTodoInput');
                const add = document.getElementById('dynTodoAdd');
                let items = [];
                try { items = JSON.parse(localStorage.getItem(key) || '[]'); } catch { items = []; }

                const persist = async () => {
                    localStorage.setItem(key, JSON.stringify(items));
                    try {
                        await db.collection('tabTodos').doc(String(tabId)).set({
                            items: items,
                            updatedAt: new Date().toISOString(),
                            updatedBy: (currentUser && currentUser.name) || ''
                        }, { merge: true });
                    } catch (err) {
                        console.warn('Todo Firebase kayıt hatası:', err);
                    }
                };

                const render = () => {
                    if (!list) return;
                    if (!items.length) {
                        list.innerHTML = '<li class="text-sm text-slate-400 font-medium px-1">Henüz görev yok</li>';
                        return;
                    }
                    list.innerHTML = items.map((it, i) => {
                        const due = it.due ? String(it.due).slice(0, 10) : '';
                        const dueLabel = due
                            ? ('<span class="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-lg shrink-0">' + escapeHtml(formatDateTR(due)) + '</span>')
                            : '';
                        return '<li class="flex items-center gap-2 bg-slate-50 p-3 rounded-xl">' +
                            '<input type="checkbox" ' + (it.done ? 'checked' : '') + ' data-i="' + i + '" class="dyn-todo-check rounded">' +
                            '<span class="flex-1 text-sm font-bold ' + (it.done ? 'line-through text-slate-400' : 'text-slate-800') + '">' + escapeHtml(it.text) + '</span>' +
                            dueLabel +
                            '<button type="button" data-del="' + i + '" class="text-rose-500 text-xs font-bold">Sil</button>' +
                            '</li>';
                    }).join('');
                };

                // Firebase'den yükle (varsa)
                db.collection('tabTodos').doc(String(tabId)).get().then(doc => {
                    if (doc.exists && doc.data() && Array.isArray(doc.data().items)) {
                        items = doc.data().items;
                        localStorage.setItem(key, JSON.stringify(items));
                    }
                    render();
                }).catch(() => render());

                render();
                if (add) add.onclick = () => {
                    const t = input.value.trim();
                    if (!t) return;
                    const dueEl = document.getElementById('dynTodoDue');
                    const due = dueEl && dueEl.value ? String(dueEl.value).slice(0, 10) : '';
                    items.push({ text: t, done: false, at: new Date().toISOString(), due: due || null });
                    input.value = '';
                    if (dueEl) dueEl.value = '';
                    render();
                    persist();
                    if (typeof refreshAppNotifications === 'function') refreshAppNotifications();
                };
                if (list) list.onclick = (e) => {
                    if (e.target.matches('.dyn-todo-check')) {
                        const i = +e.target.dataset.i;
                        if (items[i]) items[i].done = e.target.checked;
                        render();
                        persist();
                    }
                    if (e.target.dataset.del != null) {
                        items.splice(+e.target.dataset.del, 1);
                        render();
                        persist();
                    }
                };
            }
            if (type === 'notes') {
                const key = 'yuvam_note_' + tabId;
                const area = document.getElementById('dynNoteArea');
                const save = document.getElementById('dynNoteSave');
                if (!area) return;
                area.value = localStorage.getItem(key) || '';
                save.onclick = () => {
                    localStorage.setItem(key, area.value);
                    const msg = document.getElementById('dynNoteMsg');
                    msg.classList.remove('hidden');
                    setTimeout(() => msg.classList.add('hidden'), 1500);
                };
            }
            if (type === 'counter') {
                const key = 'yuvam_cnt_' + tabId;
                let val = parseInt(localStorage.getItem(key) || '0', 10) || 0;
                const el = document.getElementById('dynCounterVal');
                const sync = () => { el.textContent = val; localStorage.setItem(key, String(val)); };
                document.getElementById('dynCounterPlus').onclick = () => { val++; sync(); };
                document.getElementById('dynCounterMinus').onclick = () => { val--; sync(); };
                document.getElementById('dynCounterReset').onclick = () => { val = 0; sync(); };
                sync();
            }
            if (type === 'timer') {
                let sec = 0, timer = null;
                const el = document.getElementById('dynTimerVal');
                const fmt = () => {
                    const m = String(Math.floor(sec / 60)).padStart(2, '0');
                    const s = String(sec % 60).padStart(2, '0');
                    el.textContent = m + ':' + s;
                };
                document.getElementById('dynTimerStart').onclick = () => {
                    if (timer) return;
                    timer = setInterval(() => { sec++; fmt(); }, 1000);
                };
                document.getElementById('dynTimerStop').onclick = () => { clearInterval(timer); timer = null; };
                document.getElementById('dynTimerReset').onclick = () => { clearInterval(timer); timer = null; sec = 0; fmt(); };
                fmt();
            }
        }

        // Kalıcı widget türleri (yenilemede veri kaybolmaz)
        const PERSISTENT_WIDGETS = new Set(['notes', 'counter', 'calculator', 'percentage', 'timer', 'scratch', 'fuel']);


        async function callOpenRouter(userPrompt, systemPrompt, maxTokens) {
            if (!openrouterApiKey) throw new Error('OpenRouter anahtarı yok (Firebase settings/apiKeys → openrouter)');
            const models = [
                'openrouter/free',
                'meta-llama/llama-3.3-70b-instruct:free',
                'meta-llama/llama-3.2-3b-instruct:free',
                'google/gemma-3-12b-it:free',
                'qwen/qwen-2.5-7b-instruct:free'
            ];
            let lastErr = '';
            for (let i = 0; i < models.length; i++) {
                try {
                    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + openrouterApiKey,
                            'Content-Type': 'application/json',
                            'HTTP-Referer': (typeof location !== 'undefined' ? location.origin : 'https://yuvam.app'),
                            'X-Title': 'YUVAM'
                        },
                        body: JSON.stringify({
                            model: models[i],
                            messages: [
                                { role: 'system', content: systemPrompt || 'You are a helpful assistant.' },
                                { role: 'user', content: userPrompt }
                            ],
                            temperature: 0.4,
                            max_tokens: maxTokens || 2000
                        })
                    });
                    const data = await res.json();
                    if (!res.ok) {
                        lastErr = String((data && data.error && (data.error.message || data.error)) || ('HTTP ' + res.status));
                        continue;
                    }
                    const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
                    if (text && String(text).trim()) return String(text).trim();
                } catch (e) {
                    lastErr = e.message || String(e);
                }
            }
            throw new Error(lastErr || 'OpenRouter yanıt vermedi');
        }

        function sanitizeAiHtml(html) {
            if (!html) return '';
            let s = String(html);
            // code fences
            s = s.replace(/^```(?:html|HTML)?\s*/i, '').replace(/```\s*$/i, '');
            s = s.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '');
            s = s.replace(/<iframe[\s\S]*?>[\s\S]*?<\/iframe>/gi, '');
            s = s.replace(/<object[\s\S]*?>[\s\S]*?<\/object>/gi, '');
            s = s.replace(/<embed[\s\S]*?>/gi, '');
            s = s.replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
            s = s.replace(/javascript:/gi, '');
            // only body fragment if full document
            const bodyMatch = s.match(/<body[^>]*>([\s\S]*)<\/body>/i);
            if (bodyMatch) s = bodyMatch[1];
            return s.trim();
        }

        async function generateTabHtmlWithAI(description, tabLabel) {
            const system = 'Sen bir UI üreticisisin. Sadece HTML parçası döndür (Tailwind CSS class kullanabilirsin). Script, iframe, onclick, javascript: YASAK. Form, tablo, kart, liste, sayaç görseli, not alanı gibi statik/interaktif görünümlü arayüz üret. Türkçe etiket kullan. Markdown ve açıklama yazma, yalnızca HTML.';
            const user = 'Sekme adı: ' + (tabLabel || 'Özel') + '\nİstek: ' + description + '\n\nMobil uyumlu, temiz, modern bir sayfa içeriği HTML olarak üret.';
            const raw = await callOpenRouter(user, system, 2500);
            return sanitizeAiHtml(raw);
        }

        window.renderCustomTabPage = function(tab) {
            const body = document.getElementById('customTabBody');
            const title = document.getElementById('customTabTitle');
            if (!body || !tab) return;
            title.textContent = (tab.emoji || '') + ' ' + (tab.label || '');

            // AI ile üretilmiş HTML
            if (tab.aiHtml && String(tab.aiHtml).trim()) {
                body.innerHTML = sanitizeAiHtml(tab.aiHtml);
                const hint = document.createElement('p');
                hint.className = 'text-[11px] text-slate-400 text-center mt-6 font-medium';
                hint.textContent = tab.content ? ('İstek: "' + tab.content + '"') : 'AI ile oluşturuldu';
                body.appendChild(hint);
                return;
            }

            const detected = detectWidgetType(tab.content || tab.label || '');
            const type = (tab.widgetType && tab.widgetType !== 'ai' && tab.widgetType !== 'text')
                ? tab.widgetType
                : detected;
            body.innerHTML = buildWidgetHtml(type, tab.content);
            if (tab.content && type !== 'text') {
                const hint = document.createElement('p');
                hint.className = 'text-[11px] text-slate-400 text-center mt-6 font-medium';
                hint.textContent = 'İstek: "' + tab.content + '"';
                body.appendChild(hint);
            }
            setTimeout(function() { bindWidgetBehaviors(type, tab.id); }, 0);
        };


        window.toggleTabsPanel = () => {
            const panel = document.getElementById('tabsPanel');
            const icon = document.getElementById('tabsToggleIcon');
            if (!panel) return;
            const opening = panel.classList.contains('hidden');
            panel.classList.toggle('hidden');
            if (icon) icon.style.transform = opening ? 'rotate(180deg)' : 'rotate(0deg)';
            if (opening) renderTabsList();
        };

        window.renderTabsList = () => {
            const container = document.getElementById('tabsList');
            if (!container) return;
            if (!isAdmin()) {
                container.innerHTML = '<p class="text-sm text-slate-400">Sadece admin düzenleyebilir.</p>';
                return;
            }
            container.innerHTML = tabsConfig.map((t, idx) => `
                <div class="bg-slate-50 p-3.5 rounded-xl border border-slate-100 flex flex-col sm:flex-row sm:items-center gap-3">
                    <div class="flex items-center gap-3 flex-1 min-w-0">
                        <span class="text-lg">${escapeHtml(t.emoji || '📌')}</span>
                        <div class="min-w-0">
                            <p class="font-bold text-slate-800 text-sm truncate">${escapeHtml(t.label)}</p>
                            <p class="text-[10px] text-slate-400 font-semibold">${t.core ? 'Sistem sekmesi' : 'Özel sekme'}${t.adminOnly ? ' · Sadece admin' : ''}${t.widgetType ? ' · ' + t.widgetType : ''}</p>
                        </div>
                    </div>
                    <div class="flex flex-wrap gap-1">
                        <button type="button" onclick="toggleTabVisible(${idx})" class="text-[11px] font-bold px-2.5 py-1.5 rounded-lg ${t.visible ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-200 text-slate-500'}">${t.visible ? 'Görünür' : 'Gizli'}</button>
                        <button type="button" onclick="editTabMeta(${idx})" class="text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:border-indigo-300">Düzenle</button>
                        <button type="button" onclick="moveTabUp(${idx})" class="text-[11px] px-2 py-1.5 rounded-lg bg-white border border-slate-200" ${idx===0?'disabled style="opacity:0.3"':''}>⬆️</button>
                        <button type="button" onclick="moveTabDown(${idx})" class="text-[11px] px-2 py-1.5 rounded-lg bg-white border border-slate-200" ${idx===tabsConfig.length-1?'disabled style="opacity:0.3"':''}>⬇️</button>
                        <button type="button" onclick="removeTab(${idx})" class="text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-600">Sil</button>
                    </div>
                </div>
            `).join('') + `
                <button type="button" onclick="restoreDefaultTabs()" class="w-full mt-2 text-xs font-bold text-indigo-600 py-2 hover:underline">Silinen sistem sekmelerini geri yükle</button>
            `;
        };

        window.toggleTabVisible = async (index) => {
            if (!isAdmin()) return;
            tabsConfig[index].visible = !tabsConfig[index].visible;
            await saveTabsConfig();
            applyRoleAndTabs();
            renderTabsList();
        };

        window.editTabMeta = (index) => {
            try {
                if (!isAdmin()) {
                    alert('Sadece admin sekmeleri düzenleyebilir');
                    return;
                }
                const t = tabsConfig[index];
                if (!t) {
                    alert('Sekme bulunamadı');
                    return;
                }
                const modal = document.getElementById('tabEditModal');
                if (!modal) {
                    alert('Düzenleme penceresi yüklenemedi. Ctrl+F5 ile yenileyin.');
                    return;
                }
                const set = (id, val) => {
                    const el = document.getElementById(id);
                    if (el) el.value = val;
                };
                set('editTabIndex', String(index));
                set('editTabEmoji', t.emoji || '📌');
                set('editTabLabel', t.label || '');
                set('editTabContent', t.content || '');
                set('editTabVisibleTo', selectFromVisibility(t));
                const st = document.getElementById('editTabStatus');
                if (st) st.classList.add('hidden');
                modal.classList.remove('hidden');
                modal.classList.add('flex');
            } catch (err) {
                console.error(err);
                alert('Düzenle açılamadı: ' + (err.message || err));
            }
        };

        window.closeTabEditModal = () => {
            const modal = document.getElementById('tabEditModal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        };

        window.saveTabEdit = async (e) => {
            e.preventDefault();
            if (!isAdmin()) return;
            const index = parseInt(document.getElementById('editTabIndex').value, 10);
            if (isNaN(index) || !tabsConfig[index]) return;
            const emoji = document.getElementById('editTabEmoji').value.trim() || '📌';
            const label = document.getElementById('editTabLabel').value.trim();
            if (!label) {
                alert('Sekme adı gerekli');
                return;
            }
            const content = document.getElementById('editTabContent').value.trim();
            const vis = visibilityFromSelect(document.getElementById('editTabVisibleTo').value);

            tabsConfig[index].emoji = emoji;
            tabsConfig[index].label = label;
            tabsConfig[index].content = content;
            tabsConfig[index].visibleTo = vis.visibleTo;
            if (!tabsConfig[index].core || (tabsConfig[index].id !== 'settings' && tabsConfig[index].id !== 'trash')) {
                tabsConfig[index].adminOnly = vis.adminOnly;
            }
            if (content) tabsConfig[index].widgetType = detectWidgetType(content);
            else tabsConfig[index].widgetType = tabsConfig[index].widgetType || null;

            await saveTabsConfig();
            applyRoleAndTabs();
            renderTabsList();
            closeTabEditModal();
        };

        window.moveTabUp = async (index) => {
            if (!isAdmin() || index === 0) return;
            [tabsConfig[index], tabsConfig[index - 1]] = [tabsConfig[index - 1], tabsConfig[index]];
            await saveTabsConfig();
            applyRoleAndTabs();
            renderTabsList();
        };

        window.moveTabDown = async (index) => {
            if (!isAdmin() || index === tabsConfig.length - 1) return;
            [tabsConfig[index], tabsConfig[index + 1]] = [tabsConfig[index + 1], tabsConfig[index]];
            await saveTabsConfig();
            applyRoleAndTabs();
            renderTabsList();
        };

        window.removeTab = async (index) => {
            if (!isAdmin()) return;
            const t = tabsConfig[index];
            const msg = t.core
                ? `"${t.label}" sistem sekmesi menüden kaldırılacak. Devam?`
                : `"${t.label}" sekmesi silinsin mi?`;
            if (!confirm(msg)) return;
            if (t.core && !removedTabIds.includes(t.id)) {
                removedTabIds.push(t.id);
            }
            // İlgili içerik alanını gizle (sistem)
            if (t.core) {
                const el = document.getElementById('tabContent' + capitalizeTab(t.id));
                if (el) el.classList.add('hidden');
            }
            const removedLabel = t.label;
            tabsConfig.splice(index, 1);
            await saveTabsConfig();
            applyRoleAndTabs();
            renderTabsList();
            logActivity('Sekme', 'Sekme silindi', removedLabel);
        };

        window.restoreDefaultTabs = async () => {
            if (!isAdmin()) return;
            if (!confirm('Silinen tüm sistem sekmeleri geri yüklensin mi?')) return;
            removedTabIds = [];
            // Mevcut özel sekmeleri koru
            const customs = tabsConfig.filter(t => !t.core);
            tabsConfig = DEFAULT_TABS.map(t => ({ ...t, content: '', widgetType: null })).concat(customs);
            await saveTabsConfig();
            applyRoleAndTabs();
            renderTabsList();
        };

        window.addCustomTab = async () => {
            if (!isAdmin()) {
                alert('Sadece admin yeni sekme ekleyebilir');
                return;
            }
            const emoji = (document.getElementById('newTabEmoji').value || '📌').trim();
            const label = (document.getElementById('newTabLabel').value || '').trim();
            const content = (document.getElementById('newTabContent').value || '').trim();
            const vis = visibilityFromSelect(document.getElementById('newTabVisibleTo').value);
            const useAi = !!(document.getElementById('newTabUseAI') && document.getElementById('newTabUseAI').checked);
            const btn = document.getElementById('addTabBtn');
            const status = document.getElementById('newTabAiStatus');
            if (!label) {
                alert('Sekme adı gerekli');
                return;
            }
            const id = 'custom_' + Date.now();
            let widgetType = detectWidgetType(content || label);
            let aiHtml = null;

            if (btn) { btn.disabled = true; btn.textContent = useAi && content ? 'AI üretiyor...' : 'Ekleniyor...'; }
            if (status) {
                status.classList.remove('hidden');
                status.textContent = useAi && content ? 'Yapay zeka sayfa içeriğini oluşturuyor…' : '';
            }

            try {
                // Bilinen widget (todo, hesap makinesi vb.) varsa onu kullan; yoksa ve AI açıksa üret
                const knownWidget = widgetType && widgetType !== 'text';
                if (content && useAi && !knownWidget) {
                    try {
                        aiHtml = await generateTabHtmlWithAI(content, label);
                        if (aiHtml && aiHtml.length > 20) {
                            widgetType = 'ai';
                        } else {
                            aiHtml = null;
                            if (status) status.textContent = 'AI boş döndü, metin sekmesi olarak kaydedildi.';
                        }
                    } catch (aiErr) {
                        console.warn(aiErr);
                        if (status) status.textContent = 'AI kullanılamadı: ' + (aiErr.message || aiErr) + ' — basit sekme kaydedildi.';
                        aiHtml = null;
                    }
                }

                tabsConfig.push({
                    id,
                    emoji: emoji || '📌',
                    label,
                    visible: true,
                    core: false,
                    adminOnly: vis.adminOnly,
                    visibleTo: vis.visibleTo,
                    content,
                    widgetType: widgetType || 'text',
                    aiHtml: aiHtml || null
                });
                document.getElementById('newTabEmoji').value = '';
                document.getElementById('newTabLabel').value = '';
                document.getElementById('newTabContent').value = '';
                await saveTabsConfig();
                applyRoleAndTabs();
                renderTabsList();
                if (status && aiHtml) status.textContent = 'AI içerik eklendi. Sekmeye tıklayarak açın.';
                logActivity('Sekme', 'Özel sekme eklendi', label + (aiHtml ? ' (AI)' : ''));
            } catch (err) {
                alert('Kayıt hatası: ' + (err.message || err));
            }
            if (btn) { btn.disabled = false; btn.textContent = 'Sekme Ekle'; }
            if (status && !status.textContent) status.classList.add('hidden');
        };


        window.toggleActivityPanel = () => {
            const panel = document.getElementById('activityPanel');
            const icon = document.getElementById('activityToggleIcon');
            if (!panel) return;
            const opening = panel.classList.contains('hidden');
            panel.classList.toggle('hidden');
            if (icon) icon.style.transform = opening ? 'rotate(180deg)' : 'rotate(0deg)';
            if (opening) renderActivityTable();
        };

        window.applyActivityFilters = () => {
            activityFilter.user = document.getElementById('activityFilterUser').value;
            activityFilter.action = document.getElementById('activityFilterAction').value;
            activityFilter.start = document.getElementById('activityFilterStart').value;
            activityFilter.end = document.getElementById('activityFilterEnd').value;
            renderActivityTable();
        };

        window.resetActivityFilters = () => {
            activityFilter = { user: 'Tümü', action: 'Tümü', start: '', end: '' };
            document.getElementById('activityFilterUser').value = 'Tümü';
            document.getElementById('activityFilterAction').value = 'Tümü';
            document.getElementById('activityFilterStart').value = '';
            document.getElementById('activityFilterEnd').value = '';
            renderActivityTable();
        };

        window.clearActivityLog = async () => {
            if (!isAdmin()) return;
            if (!confirm('Tüm kullanıcı hareket kayıtları silinsin mi? Bu işlem geri alınamaz.')) return;
            try {
                const snap = await db.collection('activityLog').limit(400).get();
                const batchSize = snap.docs.length;
                for (const d of snap.docs) {
                    await d.ref.delete();
                }
                logActivity('Diğer', 'Aktivite kaydı temizlendi', batchSize + ' kayıt silindi');
                alert('Kayıtlar temizlendi' + (batchSize >= 400 ? ' (ilk 400; gerekirse tekrar çalıştırın)' : ''));
            } catch (err) {
                alert('Temizlenemedi: ' + (err.message || err));
            }
        };

        function formatActivityTime(iso) {
            if (!iso) return '-';
            try {
                return new Date(iso).toLocaleString('tr-TR', {
                    day: '2-digit', month: '2-digit', year: 'numeric',
                    hour: '2-digit', minute: '2-digit', second: '2-digit'
                });
            } catch { return iso; }
        }

        window.renderActivityTable = () => {
            const tbody = document.getElementById('activityTableBody');
            const countLabel = document.getElementById('activityCountLabel');
            if (!tbody) return;

            let rows = [...activityLog];
            if (activityFilter.user && activityFilter.user !== 'Tümü') {
                rows = rows.filter(r => r.user === activityFilter.user);
            }
            if (activityFilter.action && activityFilter.action !== 'Tümü') {
                rows = rows.filter(r => r.actionType === activityFilter.action);
            }
            if (activityFilter.start) {
                rows = rows.filter(r => (r.at || '').slice(0, 10) >= activityFilter.start);
            }
            if (activityFilter.end) {
                rows = rows.filter(r => (r.at || '').slice(0, 10) <= activityFilter.end);
            }
            rows.sort((a, b) => String(b.at || '').localeCompare(String(a.at || '')));

            if (countLabel) countLabel.textContent = rows.length + ' kayıt gösteriliyor';

            if (!rows.length) {
                tbody.innerHTML = '<tr><td colspan="5" class="px-4 py-8 text-center text-slate-400 text-sm">Kayıt yok</td></tr>';
                return;
            }

            const typeColor = {
                'Giriş': 'bg-emerald-50 text-emerald-700',
                'Çıkış': 'bg-slate-100 text-slate-600',
                'Harcama': 'bg-rose-50 text-rose-700',
                'Gelir': 'bg-green-50 text-green-700',
                'Kategori': 'bg-amber-50 text-amber-700',
                'Sekme': 'bg-violet-50 text-violet-700',
                'Not': 'bg-blue-50 text-blue-700',
                'Diğer': 'bg-slate-50 text-slate-600'
            };

            tbody.innerHTML = rows.map(r => `
                <tr class="hover:bg-slate-50/80">
                    <td class="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">${escapeHtml(formatActivityTime(r.at))}</td>
                    <td class="px-4 py-3">
                        <span class="text-[10px] font-black uppercase px-2 py-1 rounded-lg ${r.user === 'Bekir' ? 'bg-blue-50 text-blue-600' : (r.user === 'Duygu' ? 'bg-pink-50 text-pink-600' : 'bg-slate-100 text-slate-500')}">${escapeHtml(r.user || '-')}</span>
                    </td>
                    <td class="px-4 py-3">
                        <span class="text-[10px] font-black uppercase px-2 py-1 rounded-lg ${typeColor[r.actionType] || typeColor['Diğer']}">${escapeHtml(r.actionType || 'Diğer')}</span>
                    </td>
                    <td class="px-4 py-3 text-xs font-bold text-slate-800">${escapeHtml(r.action || '-')}</td>
                    <td class="px-4 py-3 text-xs text-slate-500 max-w-xs truncate" title="${escapeHtml(r.detail || '')}">${escapeHtml(r.detail || '-')}</td>
                </tr>
            `).join('');
        };

        window.toggleCategoryPanel = () => {
            const panel = document.getElementById('categoryPanel');
            const icon = document.getElementById('categoryToggleIcon');
            if (!panel) return;
            const opening = panel.classList.contains('hidden');
            panel.classList.toggle('hidden');
            if (icon) {
                icon.style.transform = opening ? 'rotate(180deg)' : 'rotate(0deg)';
            }
            if (opening) {
                renderCategoriesList();
            }
        };

        window.saveCategoryOrder = async () => {
            try {
                // Tam listeyi yaz (merge ile sadece list alanı güncellenir)
                await db.collection("settings").doc("categories").set({ list: categories }, { merge: true });
            } catch (err) {
                console.error("Kategori kayıt hatası:", err);
                alert("Kategoriler kaydedilemedi: " + (err.message || err) + "\n\nFirebase güvenlik kurallarını kontrol edin (settings koleksiyonuna yazma izni).");
                throw err;
            }
        };


        async function saveCategorySubtypes() {
            // Firebase: settings/categorySubtypes { map: { Kategori: [alt...] } }
            const map = {};
            Object.keys(categorySubtypes || {}).forEach(function(k) {
                if (Array.isArray(categorySubtypes[k]) && categorySubtypes[k].length) {
                    map[k] = categorySubtypes[k].slice();
                }
            });
            await db.collection('settings').doc('categorySubtypes').set({ map: map });
        }

        function getSubtypesForCategory(cat) {
            const c = cat === 'Ulaşım' ? 'Araç' : cat;
            const list = (categorySubtypes && categorySubtypes[c]) || (DEFAULT_CATEGORY_SUBTYPES && DEFAULT_CATEGORY_SUBTYPES[c]) || [];
            return Array.isArray(list) ? list.slice() : [];
        }

        function fillSubtypeSelects() {
            const bill = document.getElementById('billSubtype');
            const veh = document.getElementById('vehicleSubtype');
            if (bill) {
                const opts = getSubtypesForCategory('Faturalar');
                const cur = bill.value;
                bill.innerHTML = opts.map(function(o) {
                    return '<option value="' + o.replace(/"/g, '&quot;') + '">' + o + '</option>';
                }).join('') || '<option value="">—</option>';
                if (cur && opts.indexOf(cur) >= 0) bill.value = cur;
            }
            if (veh) {
                const opts = getSubtypesForCategory('Araç');
                const cur = veh.value;
                veh.innerHTML = opts.map(function(o) {
                    return '<option value="' + o.replace(/"/g, '&quot;') + '">' + o + '</option>';
                }).join('') || '<option value="">—</option>';
                if (cur && opts.indexOf(cur) >= 0) veh.value = cur;
            }
        }

        window.toggleCategorySubtypes = function(index) {
            const el = document.getElementById('catSubPanel_' + index);
            if (el) el.classList.toggle('hidden');
        };

        window.addCategorySubtype = async function(catIndex) {
            const cat = categories[catIndex];
            if (!cat) return;
            const name = prompt('Yeni alt seçenek adı (ör. Elektrik):');
            if (!name || !name.trim()) return;
            const n = name.trim();
            if (!categorySubtypes[cat]) categorySubtypes[cat] = [];
            if (categorySubtypes[cat].indexOf(n) >= 0) {
                alert('Bu alt seçenek zaten var');
                return;
            }
            categorySubtypes[cat].push(n);
            await saveCategorySubtypes();
            fillSubtypeSelects();
            renderCategoriesList();
            logActivity('Kategori', 'Alt seçenek eklendi', cat + ' → ' + n);
        };

        window.renameCategorySubtype = async function(catIndex, subIndex) {
            const cat = categories[catIndex];
            const list = getSubtypesForCategory(cat);
            if (!list[subIndex]) return;
            const old = list[subIndex];
            const name = prompt('Yeni ad:', old);
            if (!name || !name.trim() || name.trim() === old) return;
            const n = name.trim();
            if (!categorySubtypes[cat]) categorySubtypes[cat] = list;
            if (categorySubtypes[cat].indexOf(n) >= 0) {
                alert('Bu ad zaten kullanılıyor');
                return;
            }
            categorySubtypes[cat][subIndex] = n;
            await saveCategorySubtypes();
            fillSubtypeSelects();
            renderCategoriesList();
            logActivity('Kategori', 'Alt seçenek yeniden adlandırıldı', cat + ': ' + old + ' → ' + n);
        };

        window.removeCategorySubtype = async function(catIndex, subIndex) {
            const cat = categories[catIndex];
            const list = getSubtypesForCategory(cat);
            if (!list[subIndex]) return;
            const old = list[subIndex];
            if (!confirm('"' + old + '" alt seçeneği silinsin mi?')) return;
            if (!categorySubtypes[cat]) categorySubtypes[cat] = list;
            categorySubtypes[cat].splice(subIndex, 1);
            if (!categorySubtypes[cat].length) delete categorySubtypes[cat];
            await saveCategorySubtypes();
            fillSubtypeSelects();
            renderCategoriesList();
            logActivity('Kategori', 'Alt seçenek silindi', cat + ' → ' + old);
        };


        // ========== ADMIN PANEL ==========
        window.toggleAdminPanel = function(id) {
            const el = document.getElementById('adminPanel_' + id);
            if (el) el.classList.toggle('hidden');
        };

        window.savePasswordChange = async function() {
            if (!isAdmin() && !(currentUser && currentUser.name)) {
                showToast('Giriş gerekli', 'error');
                return;
            }
            const user = (document.getElementById('pwdUser') || {}).value;
            const p1 = (document.getElementById('pwdNew') || {}).value || '';
            const p2 = (document.getElementById('pwdNew2') || {}).value || '';
            if (!user || !p1) { showToast('Kullanıcı ve şifre gerekli', 'error'); return; }
            if (p1 !== p2) { showToast('Şifreler eşleşmiyor', 'error'); return; }
            if (p1.length < 6) { showToast('Firebase şifresi en az 6 karakter olmalı', 'error'); return; }

            // Sadece kendi şifresi Auth üzerinden değiştirilebilir (güvenlik)
            if (!currentUser || currentUser.name !== user) {
                alert(
                    'Başka kullanıcının Firebase şifresi siteden değiştirilemez.\n\n' +
                    'Firebase Console → Authentication → Users → kullanıcıyı seçin → Reset password / şifre değiştir.'
                );
                return;
            }
            const fbUser = auth.currentUser;
            if (!fbUser) {
                showToast('Oturum bulunamadı, tekrar giriş yapın', 'error');
                return;
            }
            try {
                await fbUser.updatePassword(p1);
                document.getElementById('pwdNew').value = '';
                document.getElementById('pwdNew2').value = '';
                showToast('Şifreniz güncellendi. Bir sonraki girişte yeni şifreyi kullanın.', 'success');
                logActivity('Diğer', 'Şifre değiştirildi', user);
            } catch (err) {
                const code = (err && err.code) || '';
                if (code === 'auth/requires-recent-login') {
                    alert('Güvenlik için çıkış yapıp tekrar giriş yaptıktan sonra şifre değiştirin.');
                    return;
                }
                showToast(err.message || String(err), 'error');
            }
        };

        window.savePeriodConfig = async function() {
            if (!isAdmin()) return;
            let startDay = parseInt((document.getElementById('periodStartDay') || {}).value, 10);
            let endDay = parseInt((document.getElementById('periodEndDay') || {}).value, 10);
            if (isNaN(startDay) || isNaN(endDay)) { showToast('Geçerli gün girin', 'error'); return; }
            startDay = Math.min(31, Math.max(1, startDay));
            endDay = Math.min(31, Math.max(1, endDay));
            periodConfig = { startDay: startDay, endDay: endDay };
            try {
                await db.collection('settings').doc('periodConfig').set(periodConfig);
                showToast('Dönem kaydedildi: ' + startDay + '–' + endDay, 'success');
                scheduleRenderApp();
                logActivity('Diğer', 'Ekstre dönemi güncellendi', startDay + '–' + endDay);
            } catch (err) {
                showToast(friendlyFirebaseError(err), 'error');
            }
        };

        function applyPeriodConfigToForm() {
            const s = document.getElementById('periodStartDay');
            const e = document.getElementById('periodEndDay');
            if (s) s.value = (periodConfig && periodConfig.startDay) || 29;
            if (e) e.value = (periodConfig && periodConfig.endDay) || 28;
        }

        function getThemeDeviceKind() {
            try {
                return window.matchMedia('(max-width: 768px)').matches ? 'mobile' : 'desktop';
            } catch (_) {
                return 'desktop';
            }
        }

        function themeStorageKey() {
            const user = (currentUser && currentUser.name) ? currentUser.name : 'guest';
            return 'yuvam_theme_' + user + '_' + getThemeDeviceKind();
        }

        let themePalette = 'ocean';

        window.setThemePalette = function(palette, opts) {
            opts = opts || {};
            const p = (palette === 'warm' || palette === 'forest') ? palette : 'ocean';
            themePalette = p;
            document.documentElement.classList.remove('theme-ocean', 'theme-warm', 'theme-forest');
            document.documentElement.classList.add('theme-' + p);
            try { localStorage.setItem('yuvam_palette', p); } catch (_) {}
            const map = {
                ocean: 'paletteBtnOcean',
                warm: 'paletteBtnWarm',
                forest: 'paletteBtnForest'
            };
            Object.keys(map).forEach(function(k) {
                const el = document.getElementById(map[k]);
                if (!el) return;
                const on = k === p;
                el.className = on
                    ? 'py-3 rounded-xl font-bold text-xs border-2 border-sky-500 bg-sky-50 text-sky-800'
                    : 'py-3 rounded-xl font-bold text-xs border-2 border-transparent bg-slate-50 text-slate-600';
            });
            try {
                const meta = document.querySelector('meta[name="theme-color"]');
                if (meta) {
                    meta.setAttribute('content', p === 'warm' ? '#ea580c' : (p === 'forest' ? '#059669' : '#0284c7'));
                }
            } catch (_) {}
        };

        window.setAppTheme = function(theme, opts) {
            opts = opts || {};
            appTheme = theme === 'dark' ? 'dark' : 'light';
            document.documentElement.classList.toggle('theme-dark', appTheme === 'dark');
            if (!document.documentElement.classList.contains('theme-warm') &&
                !document.documentElement.classList.contains('theme-forest') &&
                !document.documentElement.classList.contains('theme-ocean')) {
                document.documentElement.classList.add('theme-' + (themePalette || 'ocean'));
            }
            try {
                localStorage.setItem(themeStorageKey(), appTheme);
            } catch (_) {}
            const bl = document.getElementById('themeBtnLight');
            const bd = document.getElementById('themeBtnDark');
            const device = getThemeDeviceKind();
            if (bl) {
                bl.className = appTheme === 'light'
                    ? 'flex-1 py-3 rounded-xl font-bold border-2 border-sky-500 bg-sky-50 text-sky-800'
                    : 'flex-1 py-3 rounded-xl font-bold border-2 border-transparent bg-slate-100 text-slate-600';
            }
            if (bd) {
                bd.className = appTheme === 'dark'
                    ? 'flex-1 py-3 rounded-xl font-bold border-2 border-sky-500 bg-sky-50 text-sky-800'
                    : 'flex-1 py-3 rounded-xl font-bold border-2 border-transparent bg-slate-100 text-slate-600';
            }
            const hint = document.getElementById('themeDeviceHint');
            if (hint) {
                const uname = (currentUser && currentUser.name) || 'bu hesap';
                hint.textContent = uname + ' · ' + (device === 'mobile' ? 'mobil' : 'web') + ' · ' + (themePalette || 'ocean');
            }
            if (!opts.skipRemote && currentUser && currentUser.uid && typeof db !== 'undefined') {
                const patch = {};
                if (device === 'mobile') patch.themeMobile = appTheme;
                else patch.themeDesktop = appTheme;
                patch.themePalette = themePalette || 'ocean';
                db.collection('users').doc(currentUser.uid).set(patch, { merge: true }).catch(function() {});
            }
            try {
                const icon = document.getElementById('userThemeBtnIcon');
                if (icon) icon.textContent = (appTheme === 'dark') ? '☀️' : '🌙';
            } catch (_) {}
        };

        function loadThemeFromStorage() {
            try {
                let pal = localStorage.getItem('yuvam_palette');
                if (pal === 'warm' || pal === 'forest' || pal === 'ocean') setThemePalette(pal, { skipRemote: true });
                else setThemePalette('ocean', { skipRemote: true });
                let t = localStorage.getItem(themeStorageKey());
                if (!t) {
                    const legacy = localStorage.getItem('yuvam_theme');
                    if (legacy === 'dark' || legacy === 'light') t = legacy;
                }
                if (t === 'dark' || t === 'light') setAppTheme(t, { skipRemote: true });
                else {
                    appTheme = 'light';
                    document.documentElement.classList.remove('theme-dark');
                }
            } catch (_) {
                setThemePalette('ocean', { skipRemote: true });
            }
        }

        // Ekran boyutu değişince (telefon yatay / masaüstü) o cihazın kaydını yükle
        (function bindThemeMedia() {
            try {
                const mq = window.matchMedia('(max-width: 768px)');
                const onChange = function() { loadThemeFromStorage(); };
                if (mq.addEventListener) mq.addEventListener('change', onChange);
                else if (mq.addListener) mq.addListener(onChange);
            } catch (_) {}
        })();

        window.saveDashboardCards = async function() {
            dashboardCards = {
                total: !!(document.getElementById('cardVis_total') || {}).checked,
                bekir: !!(document.getElementById('cardVis_bekir') || {}).checked,
                duygu: !!(document.getElementById('cardVis_duygu') || {}).checked,
                debt: !!(document.getElementById('cardVis_debt') || {}).checked
            };
            applyDashboardCards();
            try { localStorage.setItem('yuvam_dash_cards', JSON.stringify(dashboardCards)); } catch (_) {}
            if (isAdmin()) {
                try {
                    await db.collection('settings').doc('uiPrefs').set({ dashboardCards: dashboardCards }, { merge: true });
                    showToast('Kart görünürlüğü kaydedildi', 'success');
                } catch (err) {
                    showToast(friendlyFirebaseError(err), 'error');
                }
            }
        };

        function applyDashboardCards() {
            ['total', 'bekir', 'duygu', 'debt'].forEach(function(k) {
                const el = document.querySelector('[data-dash-card="' + k + '"]');
                if (el) el.classList.toggle('hidden', !dashboardCards[k]);
                const cb = document.getElementById('cardVis_' + k);
                if (cb) cb.checked = !!dashboardCards[k];
            });
        }

        function loadDashboardCardsLocal() {
            try {
                const raw = localStorage.getItem('yuvam_dash_cards');
                if (raw) dashboardCards = Object.assign(dashboardCards, JSON.parse(raw));
            } catch (_) {}
            applyDashboardCards();
        }

        function parseCsvLine(line) {
            const out = [];
            let cur = '', inQ = false;
            for (let i = 0; i < line.length; i++) {
                const c = line[i];
                if (inQ) {
                    if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
                    else if (c === '"') inQ = false;
                    else cur += c;
                } else {
                    if (c === '"') inQ = true;
                    else if (c === ';') { out.push(cur); cur = ''; }
                    else cur += c;
                }
            }
            out.push(cur);
            return out;
        }

        window.restoreFromCsvBackup = async function() {
            if (!isAdmin()) { showToast('Sadece admin', 'error'); return; }
            const input = document.getElementById('backupFileInput');
            const status = document.getElementById('backupStatus');
            if (!input || !input.files || !input.files[0]) {
                showToast('CSV dosyası seçin', 'error');
                return;
            }
            const replaceAll = !!(document.getElementById('backupReplaceAll') || {}).checked;
            if (replaceAll && !confirm('TÜM mevcut harcamalar silinip CSV yüklenecek. Emin misiniz?')) return;
            if (!replaceAll && !confirm('CSV satırları mevcut harcamalara EKLANSİN mi?')) return;

            const text = await input.files[0].text();
            const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter(function(l) { return l.trim(); });
            if (lines.length < 2) {
                showToast('CSV boş veya geçersiz', 'error');
                return;
            }
            const header = parseCsvLine(lines[0]).map(function(h) { return h.trim().toLowerCase(); });
            const idx = function(name) {
                const i = header.indexOf(name);
                return i;
            };
            // Beklenen: Tip;Tarih;Kişi;Kategori;Ödeme;Açıklama;Tutar;Taksit;Dönem
            const iDate = idx('tarih') >= 0 ? idx('tarih') : 1;
            const iPerson = idx('kişi') >= 0 ? idx('kişi') : (idx('kisi') >= 0 ? idx('kisi') : 2);
            const iCat = idx('kategori') >= 0 ? idx('kategori') : 3;
            const iPay = idx('ödeme') >= 0 ? idx('ödeme') : (idx('odeme') >= 0 ? idx('odeme') : 4);
            const iDesc = idx('açıklama') >= 0 ? idx('açıklama') : (idx('aciklama') >= 0 ? idx('aciklama') : 5);
            const iAmt = idx('tutar') >= 0 ? idx('tutar') : 6;

            const rows = [];
            for (let li = 1; li < lines.length; li++) {
                const cols = parseCsvLine(lines[li]);
                if (cols.length < 5) continue;
                const tip = (cols[0] || '').toLowerCase();
                if (tip && tip.indexOf('harcama') < 0 && tip !== '') continue;
                let amount = String(cols[iAmt] || '0').replace(/\s/g, '').replace(',', '.');
                amount = parseFloat(amount);
                if (!amount || isNaN(amount)) continue;
                const date = String(cols[iDate] || '').slice(0, 10);
                if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) continue;
                rows.push({
                    date: date,
                    person: cols[iPerson] || 'Bekir',
                    category: cols[iCat] || 'Diğer',
                    paymentType: cols[iPay] || 'Nakit',
                    description: cols[iDesc] || '',
                    amount: amount,
                    installmentCount: 1,
                    createdAt: new Date().toISOString()
                });
            }
            if (!rows.length) {
                showToast('İçe aktarılacak satır bulunamadı', 'error');
                if (status) status.textContent = '0 satır';
                return;
            }
            if (status) status.textContent = rows.length + ' satır işleniyor…';
            try {
                if (replaceAll) {
                    const snap = await db.collection('expenses').get();
                    const batchSize = 400;
                    let batch = db.batch();
                    let n = 0;
                    for (const d of snap.docs) {
                        batch.delete(d.ref);
                        n++;
                        if (n % batchSize === 0) {
                            await batch.commit();
                            batch = db.batch();
                        }
                    }
                    if (n % batchSize !== 0) await batch.commit();
                }
                let batch = db.batch();
                let n = 0;
                for (const row of rows) {
                    const ref = db.collection('expenses').doc();
                    batch.set(ref, row);
                    n++;
                    if (n % 400 === 0) {
                        await batch.commit();
                        batch = db.batch();
                    }
                }
                if (n % 400 !== 0) await batch.commit();
                if (status) status.textContent = n + ' harcama içe aktarıldı';
                showToast(n + ' harcama yüklendi', 'success');
                logActivity('Diğer', 'CSV geri yükleme', n + ' kayıt');
            } catch (err) {
                console.error(err);
                showToast(friendlyFirebaseError(err), 'error');
                if (status) status.textContent = 'Hata: ' + (err.message || err);
            }
        };


        window.addCategory = async () => {
            const input = document.getElementById('newCategoryInput');
            const newCat = input.value.trim();
            if (!newCat) {
                alert('Kategori adı boş olamaz');
                return;
            }
            if (categories.includes(newCat)) {
                alert('Bu kategori zaten var');
                return;
            }
            categories.push(newCat);
            input.value = '';
            await saveCategoryOrder();
            updateCategorySelects();
            renderCategoriesList();
            logActivity('Kategori', 'Kategori eklendi', newCat);
        };

        window.removeCategory = async (index) => {
            const catName = categories[index];
            if (!confirm(`"${catName}" kategorisini silmek istediğinize emin misiniz?`)) return;
            categories.splice(index, 1);
            if (categorySubtypes && categorySubtypes[catName]) {
                delete categorySubtypes[catName];
                await saveCategorySubtypes();
            }
            await saveCategoryOrder();
            updateCategorySelects();
            renderCategoriesList();
            logActivity('Kategori', 'Kategori silindi', catName);
        };

        window.moveCategoryUp = async (index) => {
            if (index === 0) return;
            [categories[index], categories[index - 1]] = [categories[index - 1], categories[index]];
            await saveCategoryOrder();
            updateCategorySelects();
            renderCategoriesList();
        };

        window.moveCategoryDown = async (index) => {
            if (index === categories.length - 1) return;
            [categories[index], categories[index + 1]] = [categories[index + 1], categories[index]];
            await saveCategoryOrder();
            updateCategorySelects();
            renderCategoriesList();
        };

        window.renderCategoriesList = () => {
            const container = document.getElementById('categoriesList');
            if (!container) return;
            if (!categories || categories.length === 0) {
                container.innerHTML = '<div class="text-center text-slate-400 py-8"><p class="text-sm">Henüz kategori yok. Yukarıdan ekleyebilirsiniz.</p></div>';
                return;
            }
            container.innerHTML = categories.map((cat, idx) => {
                const subs = getSubtypesForCategory(cat);
                const subHtml = subs.map((s, si) =>
                    '<div class="flex items-center justify-between gap-2 py-1.5 px-2 rounded-lg bg-white border border-slate-100">' +
                      '<span class="text-xs font-bold text-slate-700 truncate">' + escapeHtml(s) + '</span>' +
                      '<span class="flex gap-0.5 shrink-0">' +
                        '<button type="button" onclick="renameCategorySubtype(' + idx + ',' + si + ')" class="text-[11px] text-slate-400 hover:text-indigo-600 p-1" title="Adı değiştir">✏️</button>' +
                        '<button type="button" onclick="removeCategorySubtype(' + idx + ',' + si + ')" class="text-[11px] text-slate-400 hover:text-rose-600 p-1" title="Sil">🗑️</button>' +
                      '</span>' +
                    '</div>'
                ).join('');
                return (
                    '<div class="bg-slate-50 rounded-xl border border-slate-100 overflow-hidden hover:border-indigo-200 transition">' +
                      '<div class="p-3.5 flex justify-between items-center group">' +
                        '<div class="flex items-center gap-3 flex-1 min-w-0">' +
                          '<span class="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center text-sm shrink-0 shadow-sm">' + (idx + 1) + '</span>' +
                          '<div class="min-w-0">' +
                            '<span class="font-bold text-slate-800 truncate text-sm block">' + escapeHtml(cat) + '</span>' +
                            (subs.length ? '<span class="text-[10px] text-slate-400 font-semibold">' + subs.length + ' alt seçenek</span>' : '<span class="text-[10px] text-slate-300 font-semibold">Alt seçenek yok</span>') +
                          '</div>' +
                        '</div>' +
                        '<div class="flex gap-0.5 shrink-0">' +
                          '<button type="button" onclick="toggleCategorySubtypes(' + idx + ')" class="text-slate-400 hover:text-violet-600 transition p-2 rounded-lg hover:bg-violet-50" title="Alt seçenekler">⋮</button>' +
                          '<button type="button" onclick="renameCategory(' + idx + ')" class="text-slate-400 hover:text-indigo-600 transition p-2 rounded-lg hover:bg-indigo-50" title="Yeniden Adlandır">✏️</button>' +
                          '<button type="button" onclick="moveCategoryUp(' + idx + ')" class="text-slate-400 hover:text-indigo-600 transition p-2 rounded-lg hover:bg-indigo-50" title="Yukarı" ' + (idx === 0 ? 'disabled style="opacity:0.3"' : '') + '>⬆️</button>' +
                          '<button type="button" onclick="moveCategoryDown(' + idx + ')" class="text-slate-400 hover:text-indigo-600 transition p-2 rounded-lg hover:bg-indigo-50" title="Aşağı" ' + (idx === categories.length - 1 ? 'disabled style="opacity:0.3"' : '') + '>⬇️</button>' +
                          '<button type="button" onclick="removeCategory(' + idx + ')" class="text-slate-400 hover:text-rose-600 transition p-2 rounded-lg hover:bg-rose-50" title="Sil">🗑️</button>' +
                        '</div>' +
                      '</div>' +
                      '<div id="catSubPanel_' + idx + '" class="hidden border-t border-slate-100 bg-white/80 px-3.5 py-3 space-y-2">' +
                        '<p class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Alt seçenekler (harcama formunda çıkar)</p>' +
                        (subHtml || '<p class="text-[11px] text-slate-400">Henüz alt seçenek yok</p>') +
                        '<button type="button" onclick="addCategorySubtype(' + idx + ')" class="w-full mt-1 text-xs font-bold text-violet-600 bg-violet-50 hover:bg-violet-100 py-2 rounded-xl transition">+ Alt seçenek ekle</button>' +
                      '</div>' +
                    '</div>'
                );
            }).join('');
        };

        window.renameCategory = async (index) => {
            const oldName = categories[index];
            const name = prompt('Yeni kategori adı:', oldName);
            if (!name || !name.trim() || name.trim() === oldName) return;
            const newName = name.trim();
            if (categories.includes(newName)) {
                alert('Bu kategori adı zaten var');
                return;
            }
            categories[index] = newName;
            if (categorySubtypes && categorySubtypes[oldName]) {
                categorySubtypes[newName] = categorySubtypes[oldName];
                delete categorySubtypes[oldName];
                await saveCategorySubtypes();
            }
            await saveCategoryOrder();
            updateCategorySelects();
            fillSubtypeSelects();
            renderCategoriesList();
            logActivity('Kategori', 'Kategori yeniden adlandırıldı', oldName + ' → ' + newName);
        };

        // IBAN İŞLEMLERİ
        window.copyIban = (ibanNumber) => {
            navigator.clipboard.writeText(ibanNumber).then(() => {
                alert('IBAN kopyalandı!');
            }).catch(() => {
                alert('Kopyalama başarısız oldu');
            });
        };

        window.editIban = (id) => {
            const iban = ibans.find(i => i.id === id);
            if (!iban) return;
            document.getElementById('editIbanId').value = id;
            document.getElementById('ibanOwnerName').value = iban.ownerName;
            document.getElementById('ibanNumber').value = iban.ibanNumber;
            document.getElementById('ibanBank').value = iban.bank;
            document.getElementById('ibanModal').classList.remove('hidden');
            document.getElementById('ibanModal').classList.add('flex');
        };

        window.renderIbans = () => {
            const container = document.getElementById('ibanListContainer');
            if (!container) return;
            if (ibans.length === 0) {
                container.innerHTML = `<div class="text-center text-slate-400 py-8 col-span-full"><p class="text-sm">Henüz IBAN kaydı yok</p></div>`;
                return;
            }
            container.innerHTML = ibans.map(i => `
                <div class="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex justify-between items-center group">
                    <div class="flex-1">
                        <p class="font-black text-slate-900">${escapeHtml(i.ownerName)}</p>
                        <p class="text-xs text-indigo-600 font-bold mt-1">${escapeHtml(i.bank)}</p>
                        <p class="text-xs font-mono text-slate-500 mt-2 break-all">${escapeHtml(i.ibanNumber)}</p>
                    </div>
                    <div class="flex gap-2 ml-4">
                        <button onclick="copyIban('${escapeHtml(i.ibanNumber)}')" class="text-slate-400 hover:text-indigo-600 transition text-lg" title="Kopyala">📋</button>
                        <button onclick="editIban('${escapeHtml(i.id)}')" class="text-slate-400 hover:text-blue-600 transition text-lg" title="Düzenle">✏️</button>
                        <button onclick="deleteIban('${escapeHtml(i.id)}')" class="text-slate-400 hover:text-rose-600 transition text-lg" title="Sil">🗑️</button>
                    </div>
                </div>
            `).join('');
        };

        // NOT YÖNETIMI
        window.handleNoteSubmit = async (e) => {
            e.preventDefault();
            const id = document.getElementById('editNoteId').value;
            const person = document.getElementById('notePerson').value;
            const content = document.getElementById('noteContent').value;
            const data = { person, content, date: new Date().toISOString() };
            if (id) {
                await db.collection("notes").doc(id).update(data);
            } else {
                await db.collection("notes").add(data);
            }
            document.getElementById('editNoteId').value = '';
            document.getElementById('noteContent').value = '';
            document.getElementById('noteSubmitBtn').innerText = 'Kaydet';
            const nt = document.getElementById('noteFormTitle');
            if (nt) nt.textContent = 'Not Paylaş';
            logActivity('Not', id ? 'Not güncellendi' : 'Not eklendi', person);
        };

        window.deleteNote = async (id) => {
            if (confirm("Notu silmek istediğinize emin misiniz?")) {
                await db.collection("notes").doc(id).delete();
            }
        };

        function formatNoteDateTime(iso) {
            if (!iso) return '';
            try {
                const d = new Date(iso);
                if (isNaN(d.getTime())) return '';
                return d.toLocaleString('tr-TR', {
                    day: '2-digit', month: '2-digit', year: 'numeric',
                    hour: '2-digit', minute: '2-digit'
                });
            } catch { return ''; }
        }

        window.renderNotesList = () => {
            const container = document.getElementById('notesContainer');
            if (!container) return;
            const sorted = [...notes].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
            container.innerHTML = sorted.map(n => `
                <div class="bg-white p-6 rounded-3xl card-shadow border border-slate-100 relative">
                    <div class="flex justify-between items-center mb-2 gap-2">
                        <span class="text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full ${n.person === 'Bekir' ? 'bg-blue-50 text-blue-600' : 'bg-pink-50 text-pink-600'}">${escapeHtml(n.person)}</span>
                        <div class="flex gap-2 shrink-0">
                            <button type="button" onclick="editNote('${escapeHtml(n.id)}')" class="text-xs text-sky-600 font-bold">Düzenle</button>
                            <button type="button" onclick="deleteNote('${escapeHtml(n.id)}')" class="text-xs text-rose-500 font-bold">Sil</button>
                        </div>
                    </div>
                    <p class="text-[11px] text-slate-400 font-semibold mb-3">${escapeHtml(formatNoteDateTime(n.date))}</p>
                    <p class="text-sm font-medium text-slate-700 whitespace-pre-wrap">${escapeHtml(n.content)}</p>
                </div>
            `).join('');
        };

        window.editNote = function(id) {
            const n = (notes || []).find(function(x) { return x.id === id; });
            if (!n) return;
            const eid = document.getElementById('editNoteId');
            if (eid) eid.value = id;
            const person = document.getElementById('notePerson');
            if (person) person.value = n.person || 'Bekir';
            const content = document.getElementById('noteContent');
            if (content) content.value = n.content || '';
            const btn = document.getElementById('noteSubmitBtn');
            if (btn) btn.innerText = 'Güncelle';
            const title = document.getElementById('noteFormTitle');
            if (title) title.textContent = 'Notu düzenle';
            if (content) {
                content.focus();
                try { content.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) {}
            }
        };

        // HESAPLAMA TAB

        // Filtreler & Sıralama
        window.toggleFilterPanel = () => document.getElementById('filterPanel').classList.toggle('hidden');
        window.resetFilters = () => {
            currentPersonFilter = 'Tümü'; currentCategoryFilter = 'Tümü'; currentPaymentFilter = 'Tümü';
            currentStartDateFilter = ''; currentEndDateFilter = ''; currentShowInstallments = false;
            currentSearchFilter = '';
            document.getElementById('filterPerson').value = 'Tümü';
            document.getElementById('filterCategory').value = 'Tümü';
            document.getElementById('filterPayment').value = 'Tümü';
            const fs = document.getElementById('filterSearch');
            if (fs) fs.value = '';
            document.getElementById('filterStartDate').value = '';
            document.getElementById('filterEndDate').value = '';
            document.getElementById('filterShowInstallments').checked = false;
            renderTable();
        };
        window.applyFilters = () => {
            currentPersonFilter = document.getElementById('filterPerson').value;
            currentCategoryFilter = document.getElementById('filterCategory').value;
            const fse = document.getElementById('filterSearch');
            currentSearchFilter = fse ? fse.value.trim() : '';
            currentPaymentFilter = document.getElementById('filterPayment').value;
            currentStartDateFilter = document.getElementById('filterStartDate').value;
            currentEndDateFilter = document.getElementById('filterEndDate').value;
            currentShowInstallments = document.getElementById('filterShowInstallments').checked;
            renderTable();
        };
        window.sortTable = (col) => {
            if (sortColumn === col) sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            else { sortColumn = col; sortDirection = (col === 'date' || col === 'amount') ? 'desc' : 'asc'; }
            renderTable();
        };

        window.openInstallmentsModal = () => {
            const modal = document.getElementById('installmentsModal');
            if (!modal) {
                alert('Taksit penceresi yüklenemedi. Ctrl+F5 ile yenileyin.');
                return;
            }
            const processed = getProcessedExpenses().filter(e => e.installmentLabel !== 'Peşin');
            const total = processed.reduce((s, e) => s + e.displayAmount, 0);
            const totalEl = document.getElementById('totalInstallmentAmount');
            if (totalEl) totalEl.innerText = total.toLocaleString('tr-TR') + ' TL';
            
            const currentPeriod = getCurrentPeriod();
            const currentTotal = processed.filter(e => e.effectiveMonth === currentPeriod).reduce((s, e) => s + e.displayAmount, 0);
            const selEl = document.getElementById('selectedMonthAmount');
            if (selEl) selEl.innerText = currentTotal.toLocaleString('tr-TR') + ' TL';

            const container = document.getElementById('installmentsContainer');
            if (!container) return;
            const grouped = {};
            processed.forEach(e => {
                grouped[e.effectiveMonth] = grouped[e.effectiveMonth] || [];
                grouped[e.effectiveMonth].push(e);
            });

            container.innerHTML = Object.entries(grouped).sort((a, b) => a[0].localeCompare(b[0])).map(([m, items]) => `
                <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    <div class="flex justify-between items-center mb-2">
                        <span class="font-black text-slate-700">${formatPeriodLabel(m)} <span class="text-[10px] text-slate-400 font-bold">(${m})</span></span>
                        <span class="font-bold text-indigo-600">${items.reduce((s, i) => s + i.displayAmount, 0).toLocaleString('tr-TR')} TL</span>
                    </div>
                    <div class="space-y-1">
                        ${items.map(i => `<div class="flex justify-between text-xs text-slate-500"><span>${escapeHtml(i.description)} (${escapeHtml(i.person)})</span><span>${i.displayAmount.toLocaleString('tr-TR')} TL</span></div>`).join('')}
                    </div>
                </div>
            `).join('');

            document.getElementById('installmentsModal').classList.remove('hidden');
            document.getElementById('installmentsModal').classList.add('flex');
        };
        window.closeInstallmentsModal = () => {
            document.getElementById('installmentsModal').classList.add('hidden');
            document.getElementById('installmentsModal').classList.remove('flex');
        };

        window.downloadExcel = function() {
            try {
                const rows = [];
                rows.push(['Tip', 'Tarih', 'Kişi', 'Kategori', 'Ödeme', 'Açıklama', 'Tutar', 'Taksit', 'Dönem']);
                const processed = (typeof getProcessedExpenses === 'function') ? getProcessedExpenses() : expenses;
                processed.forEach(e => {
                    rows.push([
                        'Harcama',
                        e.date || '',
                        e.person || '',
                        e.category || '',
                        e.paymentType || '',
                        e.description || '',
                        String(e.displayAmount != null ? e.displayAmount : e.amount || 0).replace('.', ','),
                        e.installmentLabel || '',
                        e.effectiveMonth || ''
                    ]);
                });
                const escapeCsv = (v) => {
                    const s = String(v == null ? '' : v);
                    if (/[;"\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
                    return s;
                };
                const csv = '\uFEFF' + rows.map(r => r.map(escapeCsv).join(';')).join('\r\n');
                const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                const d = new Date();
                const stamp = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
                a.href = url;
                a.download = 'yuvam-yedek-' + stamp + '.csv';
                document.body.appendChild(a);
                a.click();
                a.remove();
                URL.revokeObjectURL(url);
                showToast('Yedek indirildi (CSV — Excel ile açılır)', 'success');
                logActivity('Diğer', 'CSV yedek indirildi', rows.length - 1 + ' satır');
            } catch (err) {
                console.error(err);
                showToast('Yedek indirilemedi: ' + (err.message || err), 'error');
            }
        };

        window.maybeShowOnboarding = function() {
            try {
                if (localStorage.getItem('yuvam_onboarded_v1') === '1') return;
            } catch (_) {}
            const modal = document.getElementById('onboardingModal');
            if (!modal) return;
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        };

        window.closeOnboarding = function(permanent) {
            const modal = document.getElementById('onboardingModal');
            if (modal) {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            }
            if (permanent) {
                try { localStorage.setItem('yuvam_onboarded_v1', '1'); } catch (_) {}
            }
        };

        window.showHelp = function() {
            try { localStorage.removeItem('yuvam_onboarded_v1'); } catch (_) {}
            maybeShowOnboarding();
        };


        // Sayfa açılışında oturum varsa geri yükle ve veriyi çek
        // Firebase Auth oturum dinleyicisi (sayfa yenilenince de giriş kalır)
        let authBootDone = false;
        // Mobil hizli giris: oturum varsa login'i aninda gizle + iskelet uygulamayi goster
        try {
            if (auth.currentUser) {
                const loginEl = document.getElementById('errorContainer') || document.getElementById('loginScreen');
                const appEl = document.getElementById('appContainer') || document.getElementById('app');
                if (loginEl) { loginEl.classList.add('hidden'); loginEl.style.display = 'none'; }
                if (appEl) { appEl.classList.remove('hidden'); appEl.style.display = ''; }
                // Profili senkron beklemeden hizli yaz
                try {
                    currentUser = loadUserProfileFast(auth.currentUser);
                    const label = document.getElementById('loggedInUserLabel') || document.getElementById('currentUserLabel');
                    if (label && currentUser) {
                        label.textContent = currentUser.role === 'admin' ? (currentUser.name + ' · Admin') : currentUser.name;
                    }
                } catch (_) {}
            }
        } catch (_) {}
        auth.onAuthStateChanged(async function(fbUser) {
            if (authBootDone && !fbUser) return;
            try {
                if (fbUser) {
                    if (currentUser && currentUser.uid === fbUser.uid) return;
                    const profile = await loadUserProfile(fbUser);
                    await enterAppAsUser(profile, { silent: true });
                } else if (!authBootDone) {
                    // ilk yüklemede oturum yok → login ekranı
                    currentUser = null;
                }
            } catch (err) {
                console.warn('onAuthStateChanged', err);
            } finally {
                authBootDone = true;
            }
        });

